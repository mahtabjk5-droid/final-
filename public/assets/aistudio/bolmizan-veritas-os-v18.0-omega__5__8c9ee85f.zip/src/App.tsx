import { useEffect, useRef, useState } from 'react';
import {
  BookOpenCheck,
  Calculator,
  ChevronDown,
  CloudOff,
  Command,
  CreditCard,
  Crown,
  Eye,
  EyeOff,
  GitCompareArrows,
  LayoutDashboard,
  LogOut,
  Menu,
  Mic,
  Moon,
  RefreshCw,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Sun,
  TrendingUp,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import type { NavSection, UiDisplayMode, UiLanguage, WorkspaceRole } from '../shared/types';
import { AuthGate } from './components/AuthGate';
import { BhaliKareAayaWelcome } from './components/BhaliKareAayaWelcome';
import { CommandDashboardView } from './components/CommandDashboardView';
import { FounderTreasuryAndEscrowView } from './components/FounderTreasuryAndEscrowView';
import { GlobalRailsCheckoutView } from './components/GlobalRailsCheckoutView';
import { IndusFlowParallaxLayer } from './components/IndusFlowParallaxLayer';
import { InvestorPitchHudModal } from './components/InvestorPitchHudModal';
import { MukasaAndMaalGuardView } from './components/MukasaAndMaalGuardView';
import { OsCommandDock } from './components/OsCommandDock';
import { SabziWalaMode } from './components/SabziWalaMode';
import { SecurityShieldsView } from './components/SecurityShieldsView';
import { ShariahLedgerView } from './components/ShariahLedgerView';
import { SindhMizanEmblem } from './components/SindhMizanEmblem';
import { VoiceCaptureModal } from './components/VoiceCaptureModal';
import { ZakatAndUshrView } from './components/ZakatAndUshrView';
import { useVeritasSocket } from './hooks/useVeritasSocket';
import {
  CULTURAL_MOTIFS,
  getActiveCulturalEvent,
  type CulturalMotifId,
} from './utils/culturalCalendar';
import { UI_STRINGS } from './utils/i18n';
import { sufiSoundscape } from './utils/sufiSoundscape';
import { flushOfflineQueue, readOfflineQueue } from './utils/ttsAndOffline';

export default function App() {
  const {
    authChecking,
    user,
    data,
    error,
    lockedReason,
    wsState,
    refresh,
    logout,
    onAuthenticated,
  } = useVeritasSocket();

  const [language, setLanguage] = useState<UiLanguage>('en');
  const [displayMode, setDisplayMode] = useState<UiDisplayMode>('command');
  const [activeSection, setActiveSection] = useState<NavSection>('overview');
  const [activeRole, setActiveRole] = useState<WorkspaceRole>('founder');
  const [activeMotif, setActiveMotif] = useState<CulturalMotifId>(() => {
    if (typeof window === 'undefined') return 'kashi';
    const saved = window.localStorage.getItem('sindh_mizan_motif_v2');
    return saved === 'ajrak' || saved === 'thar' || saved === 'indus' ? saved : 'kashi';
  });
  const [pardaActive, setPardaActive] = useState(false);
  const [simulateOffline, setSimulateOffline] = useState(false);
  const [offlineCount, setOfflineCount] = useState(() => readOfflineQueue().length);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [studioMenuOpen, setStudioMenuOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [pitchHudOpen, setPitchHudOpen] = useState(false);
  const [voiceModalOpen, setVoiceModalOpen] = useState(false);
  const [welcomeOpen, setWelcomeOpen] = useState(false);
  const [soundMuted, setSoundMuted] = useState(() => sufiSoundscape.isMuted());
  const [avatarFailed, setAvatarFailed] = useState(false);
  const [syncNotice, setSyncNotice] = useState<string | null>(null);
  const [mizanPulseKey, setMizanPulseKey] = useState(0);
  const [mizanKickDeg, setMizanKickDeg] = useState(0);
  const prevLedgerStateRef = useRef<{ signature: string; netBalance: number } | null>(null);
  const studioMenuRef = useRef<HTMLDivElement | null>(null);

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const saved = window.localStorage.getItem('veritas_theme_v2');
    return saved === 'dark';
  });

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
      window.localStorage.setItem('veritas_theme_v2', 'dark');
    } else {
      root.classList.remove('dark');
      window.localStorage.setItem('veritas_theme_v2', 'light');
    }
  }, [darkMode]);

  useEffect(() => {
    document.documentElement.dataset.culturalMotif = activeMotif;
    window.localStorage.setItem('sindh_mizan_motif_v2', activeMotif);
  }, [activeMotif]);

  useEffect(() => {
    if (user) {
      setActiveRole(user.defaultRole);
      setDisplayMode(user.subscriptionTier === 'mazdoor_free' ? 'sabziwala' : 'command');
    } else {
      setWelcomeOpen(false);
      setStudioMenuOpen(false);
      setPaletteOpen(false);
      setDisplayMode('command');
      setMizanPulseKey(0);
      prevLedgerStateRef.current = null;
      sufiSoundscape.stopDrone();
    }
  }, [user?.id]);

  useEffect(() => {
    const onOpenPalette = () => setPaletteOpen(true);
    const onOutside = (e: MouseEvent) => {
      if (studioMenuRef.current && !studioMenuRef.current.contains(e.target as Node)) {
        setStudioMenuOpen(false);
      }
    };
    window.addEventListener('sindh-mizan-open-palette', onOpenPalette);
    window.addEventListener('mousedown', onOutside);
    return () => {
      window.removeEventListener('sindh-mizan-open-palette', onOpenPalette);
      window.removeEventListener('mousedown', onOutside);
    };
  }, []);

  const receivablesPkr = data?.metrics.openReceivablesPkr ?? 0;
  const payablesPkr = data?.metrics.openPayablesPkr ?? 0;
  const mizanTiltDeg = data
    ? Number(
        Math.max(
          -12,
          Math.min(
            12,
            ((receivablesPkr - payablesPkr) / Math.max(1, receivablesPkr + payablesPkr)) * 12
          )
        ).toFixed(2)
      )
    : 0;

  useEffect(() => {
    if (!data) return;
    const signature = [
      data.ledgerEntries.length,
      data.ledgerEntries[0]?.id ?? '',
      data.transactions.length,
      data.transactions[0]?.id ?? '',
      receivablesPkr,
      payablesPkr,
    ].join(':');
    const netBalance = receivablesPkr - payablesPkr;

    if (!prevLedgerStateRef.current) {
      prevLedgerStateRef.current = { signature, netBalance };
      return;
    }

    if (prevLedgerStateRef.current.signature !== signature) {
      const delta = netBalance - prevLedgerStateRef.current.netBalance;
      const sign = delta >= 0 ? 1 : -1;
      const magnitude = Math.min(9.5, Math.max(5.5, 5.5 + Math.log10(Math.max(100, Math.abs(delta)))));
      setMizanKickDeg((prevKick) => {
        const nextVal = Number((sign * magnitude).toFixed(2));
        return Math.abs(nextVal - prevKick) < 0.25 ? Number((nextVal + sign * 0.75).toFixed(2)) : nextVal;
      });
      setMizanPulseKey((k) => k + 1);
      prevLedgerStateRef.current = { signature, netBalance };
    }
  }, [data, receivablesPkr, payablesPkr]);

  function handleToggleSound() {
    const nextMuted = sufiSoundscape.toggleMute();
    setSoundMuted(nextMuted);
    if (!nextMuted) {
      sufiSoundscape.startDrone();
    }
  }

  async function handleSyncOfflineQueue() {
    setSimulateOffline(false);
    const res = await flushOfflineQueue();
    setOfflineCount(res.remaining.length);
    if (res.flushed > 0) {
      setSyncNotice(`Synced ${res.flushed} offline action${res.flushed > 1 ? 's' : ''} cleanly.`);
      await refresh();
    }
  }

  useEffect(() => {
    const onOnline = () => {
      void handleSyncOfflineQueue();
    };
    window.addEventListener('online', onOnline);
    return () => window.removeEventListener('online', onOnline);
  }, []);

  if (authChecking) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-[#F8F7F3] text-sm text-slate-600 dark:bg-[#0B1117] dark:text-slate-300">
        <SindhMizanEmblem size={48} />
        <span>Verifying SINDH-MIZAN Zero-Trust session...</span>
      </div>
    );
  }

  if (!user) {
    return (
      <AuthGate
        language={language}
        lockedReason={lockedReason}
        onChangeLanguage={setLanguage}
        onAuthenticated={onAuthenticated}
      />
    );
  }

  const strings = UI_STRINGS[language];
  const culturalEvent = getActiveCulturalEvent();
  const navItems: Array<{ id: NavSection; shortLabel: string; label: string; icon: typeof LayoutDashboard }> = [
    { id: 'overview', shortLabel: 'Overview', label: strings.navOverview, icon: LayoutDashboard },
    { id: 'ledger', shortLabel: 'Shariah Ledger', label: strings.navLedger, icon: BookOpenCheck },
    { id: 'payments', shortLabel: '21 Global Rails', label: strings.navPayments, icon: CreditCard },
    { id: 'treasury', shortLabel: 'Treasury & Wages', label: strings.navTreasury, icon: Crown },
    { id: 'mukasa', shortLabel: 'Mukasa & Stock', label: strings.navMukasa, icon: GitCompareArrows },
    { id: 'zakat', shortLabel: 'Zakat & Ushr', label: strings.navZakat, icon: Calculator },
    { id: 'security', shortLabel: 'Truth & Security', label: strings.navSecurity, icon: ShieldCheck },
  ];

  const activeNavMeta = navItems.find((n) => n.id === activeSection) ?? navItems[0];
  const viewKey = displayMode === 'sabziwala' ? 'sabziwala' : activeSection;

  const sidebarContent = (
    <div className="flex h-full flex-col justify-between p-4">
      <div className="space-y-6">
        <button
          type="button"
          onClick={() => {
            setActiveSection('overview');
            setDisplayMode('command');
            setMobileMenuOpen(false);
          }}
          className="flex w-full items-center gap-3 px-2 py-1 text-left"
        >
          <SindhMizanEmblem
            size={36}
            tiltDeg={mizanTiltDeg}
            animatePulseKey={mizanPulseKey}
            tiltKickDeg={mizanKickDeg}
            className="shrink-0"
          />
          <div className="min-w-0">
            <div className="truncate font-editorial text-lg font-bold tracking-tight text-slate-900 dark:text-white">
              {strings.brandTitle}
            </div>
            <div className="truncate font-mono text-[10px] text-teal-700 dark:text-teal-400">
              Sakrand, Sindh HQ
            </div>
          </div>
        </button>

        <nav aria-label="Primary Workspace Navigation" className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = displayMode === 'command' && activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveSection(item.id);
                  setDisplayMode('command');
                  setMobileMenuOpen(false);
                }}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                  active
                    ? 'bg-teal-700 text-white dark:bg-teal-500 dark:text-slate-950'
                    : 'text-slate-600 hover:bg-stone-200/70 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800/70 dark:hover:text-white'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="truncate">{language === 'en' ? item.shortLabel : item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-stone-200 pt-4 dark:border-slate-800">
          <button
            type="button"
            onClick={() => {
              setDisplayMode((m) => (m === 'command' ? 'sabziwala' : 'command'));
              setMobileMenuOpen(false);
            }}
            className={`flex w-full items-center justify-between rounded-lg border px-3 py-2.5 text-xs font-semibold transition-colors ${
              displayMode === 'sabziwala'
                ? 'border-[#9B1C2E] bg-[#9B1C2E] text-white'
                : 'border-stone-300 bg-[#F8F7F3] text-slate-800 hover:border-teal-700 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-200'
            }`}
          >
            <span className="truncate">
              {displayMode === 'sabziwala' ? strings.commandModeLabel : strings.sabziModeLabel}
            </span>
            <span className="font-mono text-[10px] opacity-80">
              {displayMode === 'sabziwala' ? 'POS' : '3-Tap'}
            </span>
          </button>
        </div>
      </div>

      <div className="space-y-3 border-t border-stone-200 pt-4 text-xs dark:border-slate-800">
        <div className="rounded-lg bg-[#F8F7F3] px-3 py-2.5 dark:bg-[#0B1117]">
          <div className="truncate font-semibold text-slate-900 dark:text-white">
            {user.businessName}
          </div>
          <div className="mt-0.5 truncate font-mono text-[10px] text-slate-500 dark:text-slate-400">
            {culturalEvent.badge} · {wsState === 'connected' ? 'Live Sync' : 'Syncing'}
          </div>
        </div>

        <button
          type="button"
          onClick={logout}
          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-rose-700 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/30"
        >
          <LogOut className="h-3.5 w-3.5 shrink-0" />
          <span>Lock &amp; Sign Out</span>
        </button>
      </div>
    </div>
  );

  return (
    <div
      dir={strings.dir}
      className="ajrak-lattice relative flex min-h-screen bg-[#F8F7F3] text-slate-900 dark:bg-[#0B1117] dark:text-slate-100"
    >
      <IndusFlowParallaxLayer motif={activeMotif} />

      {/* Fixed Desktop Sidebar Rail */}
      <aside className="no-print sticky top-0 z-30 hidden h-screen w-[252px] shrink-0 border-r border-stone-200 bg-white lg:block dark:border-slate-800 dark:bg-[#111922]">
        {sidebarContent}
      </aside>

      {/* Main Fluid Shell */}
      <div className="relative z-10 flex min-w-0 flex-1 flex-col">
        {/* Clean 3-Zone Top Command Bar */}
        <header className="no-print sticky top-0 z-30 border-b border-stone-200 bg-white/90 backdrop-blur-md dark:border-slate-800 dark:bg-[#111922]/90">
          <div className="mx-auto flex h-16 max-w-[1360px] items-center justify-between gap-6 px-4 sm:px-8">
            {/* Zone 1: Mobile Menu + Breadcrumb */}
            <div className="flex min-w-0 items-center gap-3">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                aria-label="Open Navigation Drawer"
                className="rounded-lg p-1.5 text-slate-600 hover:bg-stone-100 lg:hidden dark:text-slate-300 dark:hover:bg-slate-800"
              >
                <Menu className="h-5 w-5" />
              </button>

              <div className="flex min-w-0 items-center gap-2 text-sm whitespace-nowrap">
                <span className="font-semibold text-slate-900 dark:text-white">
                  {displayMode === 'sabziwala'
                    ? '3-Tap Mazdoor Counter'
                    : language === 'en'
                      ? activeNavMeta.shortLabel
                      : activeNavMeta.label}
                </span>
                <span className="hidden text-slate-300 sm:inline dark:text-slate-700">/</span>
                <span className="hidden truncate text-xs text-slate-500 sm:inline dark:text-slate-400">
                  {culturalEvent.title[language]}
                </span>
              </div>
            </div>

            {/* Zone 2: Clean Command Palette Trigger */}
            <button
              type="button"
              onClick={() => setPaletteOpen(true)}
              className="hidden items-center gap-2 rounded-lg border border-stone-200 bg-[#F8F7F3] px-3 py-1.5 text-xs text-slate-500 transition-colors hover:border-teal-700/50 hover:text-slate-800 md:inline-flex dark:border-slate-800 dark:bg-[#0B1117] dark:text-slate-400 dark:hover:text-slate-200"
            >
              <Command className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
              <span>Quick Search</span>
              <span className="font-mono text-[10px] opacity-75">⌘K</span>
            </button>

            {/* Zone 3: Primary Action + Controls Popover */}
            <div className="flex shrink-0 items-center gap-2.5">
              {data && (
                <button
                  type="button"
                  onClick={() => setVoiceModalOpen(true)}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-teal-700 px-3.5 py-2 text-xs font-semibold text-white whitespace-nowrap transition-colors hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                >
                  <Mic className="h-3.5 w-3.5" />
                  <span>Speak Entry</span>
                </button>
              )}

              <div ref={studioMenuRef} className="relative">
                <button
                  type="button"
                  onClick={() => setStudioMenuOpen((o) => !o)}
                  aria-expanded={studioMenuOpen}
                  aria-label="Workspace Settings & Controls"
                  className="inline-flex shrink-0 items-center gap-2 rounded-lg border border-stone-200 bg-[#F8F7F3] px-2.5 py-1.5 text-xs font-medium text-slate-800 whitespace-nowrap transition-colors hover:bg-stone-200/70 dark:border-slate-800 dark:bg-[#0B1117] dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  {!avatarFailed ? (
                    <img
                      src="/src/assets/images/avatar_founder_1794551163913.jpg"
                      alt={user.fullName}
                      referrerPolicy="no-referrer"
                      onError={() => setAvatarFailed(true)}
                      className="h-5 w-5 rounded-sm object-cover"
                    />
                  ) : (
                    <SlidersHorizontal className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
                  )}
                  <span className="hidden sm:inline">{user.fullName.split(' ')[0]}</span>
                  <ChevronDown className="h-3.5 w-3.5 opacity-60" />
                </button>

                {studioMenuOpen && (
                  <div className="absolute right-0 mt-2 w-72 overflow-hidden rounded-xl border border-stone-200 bg-white shadow-xl dark:border-slate-800 dark:bg-[#111922]">
                    <div className="border-b border-stone-200 px-4 py-3 dark:border-slate-800">
                      <div className="truncate text-xs font-bold text-slate-900 dark:text-white">
                        {user.fullName}
                      </div>
                      <div className="truncate font-mono text-[11px] text-slate-500 dark:text-slate-400">
                        {user.location}
                      </div>
                    </div>

                    <div className="space-y-1 p-2 text-xs">
                      <button
                        type="button"
                        onClick={() => setDarkMode((d) => !d)}
                        className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-slate-700 hover:bg-stone-100 dark:text-slate-200 dark:hover:bg-slate-800"
                      >
                        <span className="inline-flex items-center gap-2">
                          {darkMode ? (
                            <Sun className="h-3.5 w-3.5 text-amber-400" />
                          ) : (
                            <Moon className="h-3.5 w-3.5 text-teal-700" />
                          )}
                          <span>{darkMode ? 'Daylight Porcelain Theme' : 'Indigo Night Vault'}</span>
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPardaActive((p) => !p)}
                        className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-slate-700 hover:bg-stone-100 dark:text-slate-200 dark:hover:bg-slate-800"
                      >
                        <span className="inline-flex items-center gap-2">
                          {pardaActive ? (
                            <EyeOff className="h-3.5 w-3.5 text-teal-600" />
                          ) : (
                            <Eye className="h-3.5 w-3.5" />
                          )}
                          <span>{strings.pardaLabel} Privacy Blur</span>
                        </span>
                        <span className="font-mono text-[10px]">{pardaActive ? 'ON' : 'OFF'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleToggleSound}
                        className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-slate-700 hover:bg-stone-100 dark:text-slate-200 dark:hover:bg-slate-800"
                      >
                        <span className="inline-flex items-center gap-2">
                          {soundMuted ? (
                            <VolumeX className="h-3.5 w-3.5" />
                          ) : (
                            <Volume2 className="h-3.5 w-3.5 text-teal-600" />
                          )}
                          <span>Bhitai Acoustic Drone</span>
                        </span>
                        <span className="font-mono text-[10px]">{soundMuted ? 'MUTED' : 'LIVE'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setSimulateOffline((o) => !o)}
                        className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-slate-700 hover:bg-stone-100 dark:text-slate-200 dark:hover:bg-slate-800"
                      >
                        <span className="inline-flex items-center gap-2">
                          <CloudOff className="h-3.5 w-3.5" />
                          <span>Offline Queue Mode</span>
                        </span>
                        <span className="font-mono text-[10px]">
                          {simulateOffline ? 'OFFLINE' : 'ONLINE'}
                        </span>
                      </button>

                      <div className="flex items-center justify-between px-3 py-2">
                        <span className="text-slate-500 dark:text-slate-400">Indus Tile Motif</span>
                        <select
                          value={activeMotif}
                          onChange={(e) => setActiveMotif(e.target.value as CulturalMotifId)}
                          aria-label="Cultural Motif"
                          className="rounded-md border border-stone-300 bg-[#F8F7F3] px-2 py-1 text-xs font-medium text-slate-800 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-200"
                        >
                          {CULTURAL_MOTIFS.map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="flex items-center justify-between px-3 py-2">
                        <span className="text-slate-500 dark:text-slate-400">Language</span>
                        <select
                          value={language}
                          onChange={(e) => setLanguage(e.target.value as UiLanguage)}
                          aria-label="Language"
                          className="rounded-md border border-stone-300 bg-[#F8F7F3] px-2 py-1 text-xs font-medium text-slate-800 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-200"
                        >
                          <option value="en">English</option>
                          <option value="ur">اردو</option>
                          <option value="sd">سنڌي</option>
                          <option value="ar">العربية</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1 border-t border-stone-200 p-2 text-xs dark:border-slate-800">
                      {data && (
                        <button
                          type="button"
                          onClick={() => {
                            setPitchHudOpen(true);
                            setStudioMenuOpen(false);
                          }}
                          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 font-medium text-teal-800 hover:bg-teal-50 dark:text-teal-300 dark:hover:bg-teal-950/30"
                        >
                          <TrendingUp className="h-3.5 w-3.5" />
                          <span>Executive Investor HUD</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          setWelcomeOpen(true);
                          setStudioMenuOpen(false);
                        }}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 font-medium text-[#9B1C2E] hover:bg-rose-50 dark:text-rose-300 dark:hover:bg-rose-950/30"
                      >
                        <Sparkles className="h-3.5 w-3.5" />
                        <span>Indus Heritage Briefing</span>
                      </button>

                      <button
                        type="button"
                        onClick={logout}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 font-medium text-rose-700 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/30"
                      >
                        <LogOut className="h-3.5 w-3.5" />
                        <span>Lock Session &amp; Sign Out</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Mobile Drawer Overlay */}
        {mobileMenuOpen && (
          <div
            className="fixed inset-0 z-50 flex bg-slate-950/60 backdrop-blur-xs lg:hidden"
            onClick={() => setMobileMenuOpen(false)}
          >
            <div
              className="relative h-full w-72 border-r border-stone-200 bg-white dark:border-slate-800 dark:bg-[#111922]"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close drawer"
                className="absolute right-3 top-4 rounded-lg p-1.5 text-slate-500 hover:bg-stone-100 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
              {sidebarContent}
            </div>
          </div>
        )}

        {/* Main Workspace Viewport */}
        <main className="mx-auto w-full max-w-[1360px] flex-1 px-4 py-7 sm:px-8">
          {syncNotice && (
            <div className="no-print mb-5 flex items-center justify-between rounded-lg border border-teal-200 bg-teal-50 px-4 py-2.5 text-xs font-medium text-teal-900 dark:border-teal-800 dark:bg-teal-950/40 dark:text-teal-200">
              <span>{syncNotice}</span>
              <button
                type="button"
                onClick={() => setSyncNotice(null)}
                className="p-0.5 hover:bg-teal-100 dark:hover:bg-teal-900/50"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {(simulateOffline || offlineCount > 0) && (
            <div className="no-print mb-5 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-amber-300 bg-amber-50 px-4 py-2.5 text-xs text-amber-950 dark:border-amber-700/50 dark:bg-amber-950/40 dark:text-amber-200">
              <span>
                {simulateOffline
                  ? 'Offline Simulation Active — ledger actions are queued cleanly for auto-sync.'
                  : `${offlineCount} offline transaction(s) ready to sync with the WAL ledger.`}
              </span>
              <button
                type="button"
                onClick={handleSyncOfflineQueue}
                className="inline-flex items-center gap-1 rounded-md bg-amber-800 px-3 py-1 font-semibold text-white hover:bg-amber-700 dark:bg-amber-500 dark:text-slate-950"
              >
                <RefreshCw className="h-3 w-3" />
                <span>Sync Now</span>
              </button>
            </div>
          )}

          {error && !data ? (
            <div className="rounded-xl border border-rose-200 bg-white p-6 text-sm text-rose-700 dark:border-rose-900 dark:bg-[#111922] dark:text-rose-300">
              {error}
            </div>
          ) : !data ? (
            <div className="h-80 animate-pulse rounded-xl border border-stone-200 bg-white dark:border-slate-800 dark:bg-[#111922]" />
          ) : (
            <div key={viewKey} className="veritas-enter">
              {displayMode === 'sabziwala' ? (
                <SabziWalaMode
                  data={data}
                  language={language}
                  pardaActive={pardaActive}
                  simulateOffline={simulateOffline}
                  onQueuedOffline={() => setOfflineCount(readOfflineQueue().length)}
                  onOpenVoiceCapture={() => setVoiceModalOpen(true)}
                />
              ) : (
                <>
                  {activeSection === 'overview' && (
                    <CommandDashboardView
                      data={data}
                      activeRole={activeRole}
                      language={language}
                      pardaActive={pardaActive}
                      mizanTiltDeg={mizanTiltDeg}
                      mizanPulseKey={mizanPulseKey}
                      mizanKickDeg={mizanKickDeg}
                      activeMotif={activeMotif}
                      soundMuted={soundMuted}
                      onSelectMotif={setActiveMotif}
                      onToggleSound={handleToggleSound}
                      onSelectRole={setActiveRole}
                      onNavigate={setActiveSection}
                      onOpenWelcomeModal={() => setWelcomeOpen(true)}
                      onOpenVoiceModal={() => setVoiceModalOpen(true)}
                      onRefresh={refresh}
                    />
                  )}
                  {activeSection === 'ledger' && (
                    <ShariahLedgerView
                      entries={data.ledgerEntries}
                      chainVerification={data.chainVerification}
                      businessName={data.user.businessName}
                      language={language}
                      pardaActive={pardaActive}
                      simulateOffline={simulateOffline}
                      onQueuedOffline={() => setOfflineCount(readOfflineQueue().length)}
                      onOpenVoiceCapture={() => setVoiceModalOpen(true)}
                    />
                  )}
                  {activeSection === 'payments' && (
                    <GlobalRailsCheckoutView
                      fx={data.fx}
                      transactions={data.transactions}
                      paymentLinks={data.paymentLinks}
                      killSwitchFrozen={data.killSwitchFrozen}
                      simulateOffline={simulateOffline}
                      onQueuedOffline={() => setOfflineCount(readOfflineQueue().length)}
                    />
                  )}
                  {activeSection === 'treasury' && (
                    <FounderTreasuryAndEscrowView
                      user={data.user}
                      treasury={data.treasury}
                      escrows={data.mazdoorEscrows}
                      grossVolumeUsd={data.metrics.grossVolumeUsd}
                      pardaActive={pardaActive}
                      language={language}
                      onRefresh={refresh}
                    />
                  )}
                  {activeSection === 'mukasa' && (
                    <MukasaAndMaalGuardView
                      debtCycles={data.debtCycles}
                      inventory={data.inventory}
                    />
                  )}
                  {activeSection === 'zakat' && (
                    <ZakatAndUshrView
                      openReceivablesPkr={data.metrics.openReceivablesPkr}
                      ledgerEntries={data.ledgerEntries}
                      inventory={data.inventory}
                      pardaActive={pardaActive}
                    />
                  )}
                  {activeSection === 'security' && (
                    <SecurityShieldsView
                      user={data.user}
                      webhooks={data.webhooks}
                      killSwitchFrozen={data.killSwitchFrozen}
                      language={language}
                      onPasskeyAdded={refresh}
                    />
                  )}
                </>
              )}
            </div>
          )}
        </main>
      </div>

      <OsCommandDock
        open={paletteOpen}
        onClose={() => setPaletteOpen(false)}
        displayMode={displayMode}
        soundMuted={soundMuted}
        onNavigate={(section) => {
          setActiveSection(section);
          setDisplayMode('command');
        }}
        onToggleDisplayMode={() =>
          setDisplayMode((m) => (m === 'command' ? 'sabziwala' : 'command'))
        }
        onOpenVoice={() => setVoiceModalOpen(true)}
        onReplayWelcome={() => setWelcomeOpen(true)}
        onToggleSound={handleToggleSound}
      />

      {welcomeOpen && (
        <BhaliKareAayaWelcome
          userName={user.fullName}
          businessName={user.businessName}
          language={language}
          onDismiss={() => setWelcomeOpen(false)}
        />
      )}

      {pitchHudOpen && data && (
        <InvestorPitchHudModal data={data} onClose={() => setPitchHudOpen(false)} />
      )}

      {voiceModalOpen && data && (
        <VoiceCaptureModal
          language={language}
          businessName={data.user.businessName}
          simulateOffline={simulateOffline}
          onQueuedOffline={() => setOfflineCount(readOfflineQueue().length)}
          onCompleted={refresh}
          onClose={() => setVoiceModalOpen(false)}
        />
      )}
    </div>
  );
}
