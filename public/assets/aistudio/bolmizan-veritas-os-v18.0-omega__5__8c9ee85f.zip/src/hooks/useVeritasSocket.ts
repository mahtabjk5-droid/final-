import { useCallback, useEffect, useRef, useState } from 'react';
import type { UserPublicProfile, VeritasBootstrapPayload, WsServerMessage } from '../../shared/types';
import {
  apiFetch,
  getSessionToken,
  isExternalAuthFlowActive,
  setSessionToken,
} from '../utils/sessionClient';

export type WsConnectionState = 'connecting' | 'connected' | 'reconnecting';

export function useVeritasSocket() {
  const [authChecking, setAuthChecking] = useState(true);
  const [user, setUser] = useState<UserPublicProfile | null>(null);
  const [data, setData] = useState<VeritasBootstrapPayload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [lockedReason, setLockedReason] = useState<string | null>(null);
  const [wsState, setWsState] = useState<WsConnectionState>('connecting');
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);

  const loadBootstrap = useCallback(async (): Promise<boolean> => {
    try {
      const res = await apiFetch('/api/bootstrap');
      if (res.status === 401) {
        setSessionToken(null);
        setUser(null);
        setData(null);
        setAuthChecking(false);
        return false;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const payload = (await res.json()) as VeritasBootstrapPayload;
      setUser(payload.user);
      setData(payload);
      setError(null);
      setLockedReason(null);
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach SINDH-MIZAN OS server');
      return false;
    } finally {
      setAuthChecking(false);
    }
  }, []);

  useEffect(() => {
    // Only auto-check if an active in-tab sessionStorage/memory token exists;
    // cold visits always enforce fresh authentication.
    if (!getSessionToken()) {
      setAuthChecking(false);
      return;
    }
    void loadBootstrap();
  }, [loadBootstrap]);

  useEffect(() => {
    if (!user) return;
    let disposed = false;
    let attempt = 0;

    function connect() {
      if (disposed) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const token = getSessionToken();
      const wsUrl = token
        ? `${protocol}//${window.location.host}/ws?token=${encodeURIComponent(token)}`
        : `${protocol}//${window.location.host}/ws`;
      setWsState(attempt === 0 ? 'connecting' : 'reconnecting');

      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        attempt = 0;
        setWsState('connected');
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data as string) as WsServerMessage;
          if (msg.type === 'snapshot:init') {
            setData(msg.payload);
            setUser(msg.payload.user);
            return;
          }
          setData((prev) => {
            if (!prev) return prev;
            if (msg.type === 'state:sync') {
              return { ...prev, ...msg.payload };
            }
            if (msg.type === 'fx:tick') {
              return { ...prev, fx: msg.payload };
            }
            return prev;
          });
        } catch {
          // Ignore malformed ws payload
        }
      };

      ws.onclose = () => {
        if (disposed) return;
        setWsState('reconnecting');
        attempt += 1;
        const delay = Math.min(8000, 1000 * Math.pow(1.5, attempt));
        reconnectTimerRef.current = window.setTimeout(connect, delay);
      };
    }

    connect();

    return () => {
      disposed = true;
      if (reconnectTimerRef.current !== null) {
        window.clearTimeout(reconnectTimerRef.current);
      }
      wsRef.current?.close();
    };
  }, [user?.id]);

  // Strict Zero-Trust Re-Login on Every Exit (pagehide, beforeunload, visibility hidden)
  const lockSessionImmediately = useCallback((reason?: string) => {
    setSessionToken(null);
    if (reconnectTimerRef.current !== null) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
    try {
      wsRef.current?.close();
    } catch {
      // Ignore WS close error
    }
    try {
      if (typeof navigator !== 'undefined' && typeof navigator.sendBeacon === 'function') {
        navigator.sendBeacon('/api/auth/logout');
      } else {
        void window.fetch('/api/auth/logout', {
          method: 'POST',
          credentials: 'include',
          keepalive: true,
        });
      }
    } catch {
      // Ignore exit beacon network errors
    }
    setUser(null);
    setData(null);
    if (reason) {
      setLockedReason(reason);
    }
  }, []);

  useEffect(() => {
    if (!user) return;

    const handlePageHide = () => {
      lockSessionImmediately('Session locked on exit for Zero-Trust Amanat protection. Please sign in again.');
    };

    const handleBeforeUnload = () => {
      lockSessionImmediately();
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && !isExternalAuthFlowActive()) {
        lockSessionImmediately(
          'Session automatically locked when you left the workspace. Verify identity to resume.'
        );
      }
    };

    window.addEventListener('pagehide', handlePageHide);
    window.addEventListener('beforeunload', handleBeforeUnload);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      window.removeEventListener('pagehide', handlePageHide);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [user?.id, lockSessionImmediately]);

  const logout = useCallback(async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // Ignore network errors on logout
    }
    setSessionToken(null);
    wsRef.current?.close();
    setUser(null);
    setData(null);
    setLockedReason(null);
  }, []);

  const refresh = useCallback(async (): Promise<void> => {
    await loadBootstrap();
  }, [loadBootstrap]);

  return {
    authChecking,
    user,
    data,
    error,
    lockedReason,
    wsState,
    refresh,
    logout,
    lockSessionImmediately,
    onAuthenticated: loadBootstrap,
  };
}
