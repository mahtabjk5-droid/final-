import type { NavSection, UiLanguage } from '../../shared/types';

export type CulturalMotifId = 'ajrak' | 'kashi' | 'thar' | 'indus';

export interface CulturalEventBanner {
  id: string;
  badge: string;
  title: Record<UiLanguage, string>;
  subtitle: Record<UiLanguage, string>;
  accent: 'ajrak' | 'emerald' | 'gold';
}

export interface LivingSindhMilestone {
  id: string;
  season: string;
  title: Record<UiLanguage, string>;
  poeticLine: Record<UiLanguage, string>;
  halalActionLabel: string;
  targetSection: NavSection;
  motif: CulturalMotifId;
}

export interface HalalIdeaBlueprint {
  id: string;
  title: string;
  traditionLink: string;
  summary: string;
  targetSection: NavSection;
  ctaLabel: string;
}

export const CULTURAL_MOTIFS: Array<{
  id: CulturalMotifId;
  name: string;
  sindhiName: string;
  swatchHex: string;
  note: string;
}> = [
  {
    id: 'ajrak',
    name: 'Sakrand Ajrak',
    sindhiName: 'سڪرنڊ اجرڪ',
    swatchHex: '#9F1239',
    note: 'Madder Crimson & Indigo',
  },
  {
    id: 'kashi',
    name: 'Hala Kashi',
    sindhiName: 'هالا ڪاشي',
    swatchHex: '#0D9488',
    note: 'Cobalt & Turquoise Glaze',
  },
  {
    id: 'thar',
    name: 'Thar Gold',
    sindhiName: 'ٿر سون',
    swatchHex: '#D97706',
    note: 'Desert Amber & Sandstone',
  },
  {
    id: 'indus',
    name: 'Sindhu Emerald',
    sindhiName: 'سنڌو درياھ',
    swatchHex: '#059669',
    note: 'River Jade & Horizon',
  },
];

export const LIVING_SINDH_MILESTONES: LivingSindhMilestone[] = [
  {
    id: 'topi_ajrak_day',
    season: 'Sindhi Culture Day',
    title: {
      en: 'Sindhi Topi & Ajrak — Crown of Trust',
      ur: 'سندھی ٹوپی اور اجرک — امانت کا تاج',
      sd: 'سنڌي ٽوپي ۽ اجرڪ — امانت ۽ وقار جو تاج',
      ar: 'الطاقية السندية والأجرك — تاج الأمانة',
    },
    poeticLine: {
      en: 'Just as every mirror-work stitch on a Sindhi Topi reflects light, every ledger entry reflects 0% Riba truth.',
      ur: 'سندھی ٹوپی کے شیشوں کی طرح ہر کھاتہ سچائی اور سود سے پاک روشنی بکھیرتا ہے۔',
      sd: 'سنڌي ٽوپيءَ جي شيشن جيان هر حساب وياج کان پاڪ سچائيءَ جو عڪس آهي.',
      ar: 'كما تعكس مرايا الطاقية النور، يعكس كل قيد أمانة خالية من الربا.',
    },
    halalActionLabel: 'Open Otaq Ledger',
    targetSection: 'ledger',
    motif: 'ajrak',
  },
  {
    id: 'bhitai_sur',
    season: 'Bhit Shah Heritage',
    title: {
      en: 'Shah Abdul Latif Bhittai — Sur Samundi & Trade',
      ur: 'شاہ عبداللطیف بھٹائیؒ — سُر سمونڈی اور حلال رزق',
      sd: 'شاهه عبداللطيف ڀٽائيؒ — سُر سامونڊي ۽ حلال روزي',
      ar: 'شاه عبد اللطيف بهتائي — سُر المحيط والتجارة النظيفة',
    },
    poeticLine: {
      en: 'From Keti Bunder sails to Karachi Port & Dubai Marina: honor every sailor and daily laborer before their sweat dries.',
      ur: 'کیٹی بندر سے کراچی پورٹ اور دبئی تک: مزدور کا پسینہ خشک ہونے سے پہلے اُس کی اجرت ادا کریں۔',
      sd: 'ڪيٽي بندر کان ڪراچي پورٽ ۽ دبئي تائين: پورهيت جو پگهر سُڪڻ کان اڳ حق ادا ڪريو.',
      ar: 'من ميناء كراتشي إلى دبي والرياض: أعطِ الأجير أجره قبل أن يجف عرقه.',
    },
    halalActionLabel: 'Open Wage Vault',
    targetSection: 'treasury',
    motif: 'kashi',
  },
  {
    id: 'sakrand_harvest',
    season: 'Indus Harvest & Ushr',
    title: {
      en: 'Sakrand & Nawabshah Agro Belt — Salam & Ushr',
      ur: 'سکرنڈ اور سندھ کی زراعت — بیعِ سلم اور عشر',
      sd: 'سڪرنڊ ۽ سنڌ جي زراعت — بيع سلم ۽ عشر',
      ar: 'زراعة سكرند ووادي السند — عقد السلم والعشر',
    },
    poeticLine: {
      en: 'Wheat, dates, mangoes, and cotton priced honestly through Bay Salam forward contracts and irrigated 5% Ushr charity.',
      ur: 'گندم، کھجور، آم اور کپاس کے لیے بیعِ سلم معاہدے اور ۵ فیصد عشر کا خودکار حساب۔',
      sd: 'ڪڻڪ، کجور، انبن ۽ ڪپهه لاءِ بيع سلم معاهدا ۽ ۵ سيڪڙو عشر جو خودڪار حساب.',
      ar: 'التمور والقمح والقطن بعقود السلم الشرعية وحساب العشر الدقيق.',
    },
    halalActionLabel: 'Open Zakat & Ushr',
    targetSection: 'zakat',
    motif: 'indus',
  },
  {
    id: 'hala_craft_export',
    season: '21-Rail Export Corridor',
    title: {
      en: 'Hala Pottery & Tharparkar Artisans Worldwide',
      ur: 'ہالا کاشی اور تھرپارکر کے ہنرمند عالمی منڈی میں',
      sd: 'هالا ڪاشي ۽ ٿرپارڪر جا هنرمند عالمي منڊيءَ ۾',
      ar: 'حرفيو هالا وتهارباركار إلى الأسواق العالمية',
    },
    poeticLine: {
      en: 'Sell Hala Kashi ceramics and Rilli quilts to London, Riyadh, and New York with instant Raast, ZATCA TLV, and ISO-20022.',
      ur: 'ہالا کی کاشی اور رِلی دستکاری لندن، ریاض اور نیویارک میں فوری راست اور ZATCA بلنگ کے ساتھ فروخت کریں۔',
      sd: 'هالا جي ڪاشي ۽ رليون لنڊن، رياض ۽ نيويارڪ ڏانهن فوري راست ۽ ZATCA ذريعي پهچايو.',
      ar: 'تصدير خزف هالا والحرف التراثية عبر ٢١ مسار دفع فوري وحلال.',
    },
    halalActionLabel: 'Open 21-Rail Checkout',
    targetSection: 'payments',
    motif: 'thar',
  },
];

export const HALAL_IDEAS_BLUEPRINTS: HalalIdeaBlueprint[] = [
  {
    id: 'idea_mukasa',
    title: 'Zero-Cash Bazaar Debt Clearing (Mukasa)',
    traditionLink: 'Al-Maqasah · Mutual Offset',
    summary: 'Resolve A → B → C → A mandi credit loops dynamically via DFS graph discovery without moving cash or charging interest.',
    targetSection: 'mukasa',
    ctaLabel: 'Launch Mukasa Engine',
  },
  {
    id: 'idea_mazdoor',
    title: 'Direct Non-Custodial Worker Raast Vault',
    traditionLink: 'Haq-e-Mazdoor · 0% Deduction',
    summary: 'Contractors generate instant SBP Raast / JazzCash QR milestones so daily workers receive 100% of wages with zero middleman cut.',
    targetSection: 'treasury',
    ctaLabel: 'Open Wage Milestones',
  },
  {
    id: 'idea_maalguard',
    title: '30% Pre-Expiry Rescue & NGO Donations',
    traditionLink: 'Hazrat Usman (RA) Endowment Spirit',
    summary: 'Turn expiring grain, dairy, and medicine inventory into discounted B2B rescues or printable tax-exempt NGO pledges.',
    targetSection: 'mukasa',
    ctaLabel: 'Inspect Stock Radar',
  },
  {
    id: 'idea_truthfilter',
    title: 'BISP / 8171 & OTP Scam Shield',
    traditionLink: 'Hifz al-Mal · Protection of Wealth',
    summary: 'Protect families from predatory WhatsApp, SMS, and fake helpline fraud with Urdu/Sindhi pattern scanning and spoken alerts.',
    targetSection: 'security',
    ctaLabel: 'Run Scam Scanner',
  },
];

export function getFormattedHijriAndGregorian(date = new Date()): {
  hijriDate: string;
  gregorianDate: string;
  localTime: string;
} {
  let hijriDate = '';
  try {
    hijriDate = new Intl.DateTimeFormat('en-TN-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(date);
  } catch {
    hijriDate = 'Hijri Calendar Active';
  }

  const gregorianDate = new Intl.DateTimeFormat('en-PK', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date);

  const localTime = new Intl.DateTimeFormat('en-PK', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  }).format(date);

  return { hijriDate, gregorianDate, localTime };
}

function getHijriMonthDay(date = new Date()): { month: number; day: number } | null {
  try {
    const parts = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
      month: 'numeric',
      day: 'numeric',
    }).formatToParts(date);
    const month = Number(parts.find((p) => p.type === 'month')?.value || 0);
    const day = Number(parts.find((p) => p.type === 'day')?.value || 0);
    if (month > 0 && day > 0) return { month, day };
  } catch {
    return null;
  }
  return null;
}

function isFirstSundayOfDecember(date: Date): boolean {
  return date.getMonth() === 11 && date.getDay() === 0 && date.getDate() <= 7;
}

export function getActiveCulturalEvent(date = new Date()): CulturalEventBanner {
  const gMonth = date.getMonth() + 1;
  const gDay = date.getDate();
  const hijri = getHijriMonthDay(date);

  if (isFirstSundayOfDecember(date)) {
    return {
      id: 'sindhi_cultural_day',
      badge: 'Topi & Ajrak Day',
      accent: 'ajrak',
      title: {
        en: 'Happy Sindhi Cultural Day — Ekta, Ajrak & Sindhi Topi',
        ur: 'سندھی ثقافتی دن مبارک — اجرک، ٹوپی اور امانت کا عہد',
        sd: 'سنڌي ثقافتي ڏهاڙو مبارڪ — ٽوپي، اجرڪ ۽ امانت جو عهد',
        ar: 'يوم الثقافة السندية المبارك — الأمانة والعدل والتراث',
      },
      subtitle: {
        en: '0% Fee Haq-e-Mazdoor & Sakrand Bazaar Otaq Celebrations Active',
        ur: 'سکرنڈ تا عالمی منڈی — مزدور کے حق میں صفر فیس اور اوطاق میثاق جاری',
        sd: 'سڪرنڊ کان عالمي منڊي تائين — مزدور جي حق لاءِ صفر فيس ۽ اوطاق شاهدي',
        ar: 'رسوم 0% لأجور العمال وتوثيق المجالس عبر شبكة ميزان سندھ',
      },
    };
  }

  if (gMonth === 8 && gDay === 14) {
    return {
      id: 'pakistan_14_aug',
      badge: '14 August · Azadi',
      accent: 'emerald',
      title: {
        en: '14 August Jashn-e-Azadi — Economic Sovereignty from Sakrand',
        ur: 'یومِ آزادی مبارک — سکرنڈ سندھ سے خود مختار حلال معیشت',
        sd: '۱۴ آگسٽ آزادي جو ڏهاڙو مبارڪ — سڪرنڊ کان عالمي معاشي خودمختياري',
        ar: 'عيد الاستقلال المبارك — سيادة مالية حلال بلا ربا',
      },
      subtitle: {
        en: 'Zero-Riba SBP Raast & ETO-2002 Sovereign Ledger Protecting Workers & Exporters',
        ur: 'اسٹیٹ بینک راست اور ETO-2002 قانونی رسیدوں کے ساتھ سود سے پاک تجارت',
        sd: 'اسٽيٽ بئنڪ راست ۽ ETO-2002 قانوني رسيدن سان وياج کان پاڪ واپار',
        ar: 'مدفوعات راست الفورية وسجلات التصدير الشرعية',
      },
    };
  }

  if (hijri?.month === 9) {
    return {
      id: 'ramadan_kareem',
      badge: 'Ramadan Kareem · Zakat Active',
      accent: 'gold',
      title: {
        en: 'Ramadan Mubarak — Quran 2:280 Grace & AAOIFI Zakat Engine Ready',
        ur: 'رمضان مبارک — قرآن ۲:۲۸۰ کی مہلت اور زکوٰۃ و عشر کی ادائیگی',
        sd: 'رمضان مبارڪ — قرآن ۲:۲۸۰ مهلت ۽ زڪوات و عشر جو حساب تيار',
        ar: 'رمضان مبارك — تفعيل ميثاق الإمهال القرآني وحاسبة الزكاة الشرعية',
      },
      subtitle: {
        en: 'Instant Sadqah/Maafi forgiveness & 15-day grace window highlighted across ledger',
        ur: 'ادھار میں ۱۵ دن کی مہلت، صدقہ معافی اور مزدور اجرت کا فوری تحفظ',
        sd: 'اڌار ۾ ۱۵ ڏينهن جي مهلت، صدقو معافي ۽ مزدور جي اجرت جو فوري تحفظ',
        ar: 'تيسير الإمهال ١٥ يوماً وحماية أجور العمال دون أي رسوم ربوية',
      },
    };
  }

  if ((hijri?.month === 10 && hijri.day <= 3) || (hijri?.month === 12 && hijri.day >= 10 && hijri.day <= 12)) {
    return {
      id: 'eid_mubarak',
      badge: 'Eid Mubarak',
      accent: 'emerald',
      title: {
        en: 'Eid Mubarak from Sakrand HQ — Instant Mazdoor & Bazaar Settlements',
        ur: 'عید مبارک — سکرنڈ ہیڈکوارٹر سے مزدوروں اور تاجروں کو فوری ادائیگی',
        sd: 'عيد مبارڪ — سڪرنڊ هيڊڪوارٽر پاران مزدورن ۽ واپارين کي فوري ادائيگي',
        ar: 'عيد مبارك من المقر العالمي — تسويات فورية ومجانية لأجور العمال',
      },
      subtitle: {
        en: 'Zero-fee Raast payouts & Maal-Guard B2B surplus rescue unlocked',
        ur: 'مزدور کی اجرت پر صفر فیس اور فوری راست ٹرانسفر فعال',
        sd: 'مزدور جي اجرت تي صفر فيس ۽ فوري راست ادائيگي جاري',
        ar: 'تحويلات فورية بدون فوائد وتضامن تجاري كامل',
      },
    };
  }

  if (hijri?.month === 2 && hijri.day >= 13 && hijri.day <= 15) {
    return {
      id: 'bhittai_urs',
      badge: 'Bhit Shah · Bhittai Urs',
      accent: 'ajrak',
      title: {
        en: 'Urs Mubarak Hazrat Shah Abdul Latif Bhittai — Peace, Truth & Adl',
        ur: 'عرس حضرت شاہ عبداللطیف بھٹائیؒ — سچائی، امن اور عدل کا پیغام',
        sd: 'عرس مبارڪ حضرت شاهه عبداللطيف ڀٽائيؒ — سچائي، امانت ۽ عدل جو پيغام',
        ar: 'ذكرى الشاعر الصوفي شاه عبد اللطيف بهتائي — رسالة السلم والعدل',
      },
      subtitle: {
        en: 'Live Tambura drone & Otaq community witness ledger honoring Bhit Shah heritage',
        ur: 'بھٹ شاہ کی روایات کے مطابق اوطاق گواہی اور تانبورہ ساز فعال',
        sd: 'ڀٽ شاهه جي روايت موجب اوطاق شاهدي ۽ تانبوري جي ڌن فعال',
        ar: 'توثيق المجالس التجارية على نهج الأمانة والوفاء',
      },
    };
  }

  return {
    id: 'sakrand_daily_heritage',
    badge: 'Mohenjo-Daro → Silicon 2030',
    accent: 'ajrak',
    title: {
      en: '5,000 Years of Indus Valley Seals · Powered by Sakrand, Sindh HQ',
      ur: 'وادیِ سندھ کی ۵۰۰۰ سالہ امانت — سکرنڈ سندھ سے عالمی تجارت تک',
      sd: 'سنڌو ماٿريءَ جي ۵۰۰۰ سالن جي امانت — سڪرنڊ سنڌ کان عالمي منڊي تائين',
      ar: '٥٠٠٠ عام من أختام وادي السند — من سكرند إلى أسواق العالم',
    },
    subtitle: {
      en: 'Every voice note, Otaq witness & Raast transfer carries 0% Riba mathematical truth',
      ur: 'ہر آواز کا کھاتہ، اوطاق کی گواہی اور راست ٹرانسفر ۱۰۰٪ سود سے پاک ہے',
      sd: 'هر آواز جو کاتو، اوطاق جي شاهدي ۽ راست ادائيگي ۱۰۰٪ وياج کان پاڪ آهي',
      ar: 'كل قيد صوتي وشهادة مجلس وتحويل فوري محمي بالتشفير الشرعي',
    },
  };
}
