import { useCallback, useRef, useState } from 'react';
import QRCode from 'qrcode';
import type { UiLanguage } from '../../shared/types';
import { apiFetch } from './sessionClient';

export function speakMultilingual(text: string, lang: UiLanguage = 'en'): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang =
      lang === 'ur' ? 'ur-PK' : lang === 'ar' ? 'ar-SA' : lang === 'sd' ? 'ur-PK' : 'en-US';
    utterance.rate = 0.96;
    window.speechSynthesis.speak(utterance);
  } catch {
    // Gracefully skip if browser speech engine is unavailable
  }
}

export async function renderQrDataUrl(payload: string): Promise<string> {
  return QRCode.toDataURL(payload, {
    width: 220,
    margin: 1,
    color: { dark: '#0f172a', light: '#ffffff' },
  });
}

// Offline-first mutation queue backed by localStorage
export interface OfflineQueuedAction {
  id: string;
  endpoint: string;
  method: 'POST';
  body: Record<string, unknown>;
  idempotencyKey: string;
  label: string;
  queuedAt: string;
}

const OFFLINE_QUEUE_KEY = 'bolmizan_veritas_offline_queue_v1';

export function readOfflineQueue(): OfflineQueuedAction[] {
  try {
    const raw = window.localStorage.getItem(OFFLINE_QUEUE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function enqueueOfflineAction(action: Omit<OfflineQueuedAction, 'id' | 'queuedAt'>): OfflineQueuedAction[] {
  const next: OfflineQueuedAction[] = [
    ...readOfflineQueue(),
    {
      ...action,
      id: `off_${Math.random().toString(36).slice(2, 9)}`,
      queuedAt: new Date().toISOString(),
    },
  ];
  try {
    window.localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(next));
  } catch {
    // Ignore quota errors
  }
  return next;
}

export async function flushOfflineQueue(): Promise<{ flushed: number; remaining: OfflineQueuedAction[] }> {
  const queue = readOfflineQueue();
  if (queue.length === 0) return { flushed: 0, remaining: [] };

  const remaining: OfflineQueuedAction[] = [];
  let flushed = 0;

  for (const item of queue) {
    try {
      const res = await apiFetch(item.endpoint, {
        method: item.method,
        headers: {
          'Content-Type': 'application/json',
          'Idempotency-Key': item.idempotencyKey,
        },
        body: JSON.stringify(item.body),
      });
      if (res.ok) {
        flushed += 1;
      } else {
        remaining.push(item);
      }
    } catch {
      remaining.push(item);
    }
  }

  try {
    window.localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(remaining));
  } catch {
    // Ignore storage error
  }

  return { flushed, remaining };
}

// Cognitive Proof-of-Intent cadence analyzer
export function useCognitiveIntent() {
  const timestampsRef = useRef<number[]>([]);
  const [humanScore, setHumanScore] = useState<number>(92);

  const recordKeystrokeOrTap = useCallback(() => {
    const now = performance.now();
    const list = timestampsRef.current;
    list.push(now);
    if (list.length > 24) list.shift();

    if (list.length < 3) {
      setHumanScore(88);
      return;
    }

    const intervals: number[] = [];
    for (let i = 1; i < list.length; i++) {
      intervals.push(list[i] - list[i - 1]);
    }
    const mean = intervals.reduce((a, b) => a + b, 0) / intervals.length;
    const variance =
      intervals.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / intervals.length;
    const stdDev = Math.sqrt(variance);

    // Human typing shows natural variance (>15ms stdDev & >45ms average interval)
    if (mean < 18 && stdDev < 5) {
      setHumanScore(28); // Automated burst/bot paste signal
    } else if (stdDev >= 14 && mean >= 40) {
      setHumanScore(97);
    } else {
      setHumanScore(84);
    }
  }, []);

  const resetCadence = useCallback(() => {
    timestampsRef.current = [];
    setHumanScore(92);
  }, []);

  return { humanScore, recordKeystrokeOrTap, resetCadence };
}
