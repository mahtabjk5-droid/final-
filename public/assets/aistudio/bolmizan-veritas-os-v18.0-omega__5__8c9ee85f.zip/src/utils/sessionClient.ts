const TOKEN_KEY = 'sindh_mizan_session_token_v1';
const LEGACY_TOKEN_KEY = 'bolmizan_veritas_session_token_v1';

let memoryToken: string | null = null;
let externalAuthGraceUntil = 0;

export function beginExternalAuthFlow(durationMs = 15_000): void {
  externalAuthGraceUntil = Date.now() + durationMs;
}

export function clearExternalAuthFlow(): void {
  externalAuthGraceUntil = 0;
}

export function isExternalAuthFlowActive(): boolean {
  return Date.now() < externalAuthGraceUntil;
}

export function getSessionToken(): string | null {
  if (memoryToken) return memoryToken;
  try {
    // Purge legacy localStorage token so closed browsers/tabs never auto-login
    window.localStorage.removeItem(LEGACY_TOKEN_KEY);
    window.localStorage.removeItem(TOKEN_KEY);
    const stored = window.sessionStorage.getItem(TOKEN_KEY);
    if (stored) {
      memoryToken = stored;
      return stored;
    }
  } catch {
    // Storage may be blocked in strict third-party iframe modes; keep in memory
  }
  return null;
}

export function setSessionToken(token: string | null | undefined): void {
  const clean = token?.trim() || null;
  memoryToken = clean;
  try {
    window.localStorage.removeItem(LEGACY_TOKEN_KEY);
    window.localStorage.removeItem(TOKEN_KEY);
    if (clean) {
      window.sessionStorage.setItem(TOKEN_KEY, clean);
    } else {
      window.sessionStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    // Ignore iframe storage restrictions
  }
}

export function apiFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const token = getSessionToken();
  const nextHeaders = new Headers(
    init?.headers ?? (input instanceof Request ? input.headers : undefined)
  );
  if (token && !nextHeaders.has('Authorization')) {
    nextHeaders.set('Authorization', `Bearer ${token}`);
  }
  return window.fetch(input, {
    ...init,
    credentials: init?.credentials ?? 'include',
    headers: nextHeaders,
  });
}
