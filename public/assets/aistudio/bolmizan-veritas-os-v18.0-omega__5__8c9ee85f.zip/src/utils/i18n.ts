import type { UiLanguage } from '../../shared/types';

export interface UiStrings {
  brandTitle: string;
  tagline: string;
  navOverview: string;
  navLedger: string;
  navPayments: string;
  navTreasury: string;
  navMukasa: string;
  navZakat: string;
  navSecurity: string;
  sabziModeLabel: string;
  commandModeLabel: string;
  pardaLabel: string;
  voicePromptPlaceholder: string;
  parseVoiceBtn: string;
  readAloudBtn: string;
  dir: 'ltr' | 'rtl';
}

export const UI_STRINGS: Record<UiLanguage, UiStrings> = {
  en: {
    brandTitle: 'SINDH-MIZAN OS™',
    tagline: 'Adl Jo Tarazu, Amanat Jo Khazano',
    navOverview: 'Astrolabe Command',
    navLedger: 'Shariah Ledger & Otaq',
    navPayments: '21-Rail Clearing & QR',
    navTreasury: 'Founder Treasury & Escrow',
    navMukasa: 'Mukasa & Maal-Guard',
    navZakat: 'Zakat & Ushr',
    navSecurity: 'Security Shields',
    sabziModeLabel: 'Mazdoor / Mochi 3-Tap POS',
    commandModeLabel: 'Enterprise Astrolabe',
    pardaLabel: 'Parda',
    voicePromptPlaceholder: 'Speak or type: "Mahboob Ali ko 14,500 ka chini aur ghee udhaar diya"',
    parseVoiceBtn: 'Parse Hisab',
    readAloudBtn: 'Read Aloud',
    dir: 'ltr',
  },
  ur: {
    brandTitle: 'سندھ میزان او ایس',
    tagline: 'عدل جو ترازو، امانت جو خزانو',
    navOverview: 'ایسٹرولیب کمانڈ',
    navLedger: 'شرعی کھاتہ اور اوطاق',
    navPayments: '۲۱ ادائیگی ریلز اور QR',
    navTreasury: 'فاؤنڈر خزانہ اور مزدور والٹ',
    navMukasa: 'مقاصہ اور مال گارڈ',
    navZakat: 'زکوٰۃ اور عشر',
    navSecurity: 'سکیورٹی اور فراڈ شیلڈ',
    sabziModeLabel: 'مزدور / موچی آسان موڈ',
    commandModeLabel: 'انٹرپرائز ایسٹرولیب',
    pardaLabel: 'پردہ',
    voicePromptPlaceholder: 'بولیں یا لکھیں: محمد علی کو 14,500 روپے کی چینی اور گھی ادھار دیا',
    parseVoiceBtn: 'حساب نکالیں',
    readAloudBtn: 'آواز میں سنیں',
    dir: 'rtl',
  },
  sd: {
    brandTitle: 'سنڌ ميزان او ايس',
    tagline: 'عدل جو ترازو، امانت جو خزانو',
    navOverview: 'ايسٽروليب ڪمانڊ',
    navLedger: 'شرعي کاتو ۽ اوطاق',
    navPayments: '۲۱ ادائيگي ريلز ۽ QR',
    navTreasury: 'فائونڊر خزانو ۽ مزدور والٽ',
    navMukasa: 'مقاصو ۽ مال گارڊ',
    navZakat: 'زڪوات ۽ عشر',
    navSecurity: 'سيڪيورٽي ۽ فراڊ شيلڊ',
    sabziModeLabel: 'مزدور / موچي آسان موڊ',
    commandModeLabel: 'انٽرپرائز ايسٽروليب',
    pardaLabel: 'پردو',
    voicePromptPlaceholder: 'ڳالهايو يا لکو: محبوب علي کي 14,500 جو اڌار ڏنو',
    parseVoiceBtn: 'حساب سمجهو',
    readAloudBtn: 'آواز ۾ ٻڌو',
    dir: 'rtl',
  },
  ar: {
    brandTitle: 'سندھ ميزان أو إس',
    tagline: 'الأمانة في كل كلمة والعدل في كل حساب',
    navOverview: 'لوحة الأسطرلاب',
    navLedger: 'السجل الشرعي والمجالس',
    navPayments: '٢١ قناة دفع و QR',
    navTreasury: 'خزينة المؤسس وضمان الأجور',
    navMukasa: 'المقاصة وحارس المال',
    navZakat: 'الزكاة والعشر',
    navSecurity: 'درع الأمان',
    sabziModeLabel: 'وضع العامل والتاجر',
    commandModeLabel: 'لوحة القيادة المؤسسية',
    pardaLabel: 'الخصوصية',
    voicePromptPlaceholder: 'تحدث أو اكتب: عقد مرابحة ٤٦٠٠ ريال تمور تصدير',
    parseVoiceBtn: 'تحليل القيد',
    readAloudBtn: 'قراءة صوتية',
    dir: 'rtl',
  },
};
