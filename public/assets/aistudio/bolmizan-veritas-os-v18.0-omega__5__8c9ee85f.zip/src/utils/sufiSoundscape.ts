// Pure Web Audio API synthesis for Bhitai Tambura, Indus Alghoza & Surando harmonic soundscape
// Zero external audio dependencies; exposes real-time AnalyserNode FFT spectrum for Canvas visualizers.

export type AcousticInstrumentMode = 'tambura' | 'alghoza' | 'surando';

const SOUND_PREF_KEY = 'sindh_mizan_sound_muted_v1';
const INSTRUMENT_PREF_KEY = 'sindh_mizan_instrument_v1';

class SufiSoundscapeEngine {
  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private droneMaster: GainNode | null = null;
  private droneOscs: OscillatorNode[] = [];
  private droneActive = false;
  private muted = false;
  private instrument: AcousticInstrumentMode = 'tambura';

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        this.muted = window.localStorage.getItem(SOUND_PREF_KEY) === 'true';
        const savedInst = window.localStorage.getItem(INSTRUMENT_PREF_KEY);
        if (savedInst === 'tambura' || savedInst === 'alghoza' || savedInst === 'surando') {
          this.instrument = savedInst;
        }
      } catch {
        this.muted = false;
      }
    }
  }

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return null;
    if (!this.ctx) {
      this.ctx = new AudioCtx();
    }
    if (!this.analyser) {
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 128;
      this.analyser.smoothingTimeConstant = 0.82;
      this.analyser.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  getInstrument(): AcousticInstrumentMode {
    return this.instrument;
  }

  setInstrument(mode: AcousticInstrumentMode): void {
    this.instrument = mode;
    try {
      window.localStorage.setItem(INSTRUMENT_PREF_KEY, mode);
    } catch {
      // Ignore storage error
    }
    if (this.droneActive && !this.muted) {
      this.stopDrone();
      window.setTimeout(() => this.startDrone(), 120);
    } else if (!this.muted) {
      this.playWelcomeChord();
    }
  }

  sampleSpectrum(target: Uint8Array<ArrayBuffer>): boolean {
    if (!this.analyser || this.muted || !this.droneActive) return false;
    this.analyser.getByteFrequencyData(target);
    return true;
  }

  isMuted(): boolean {
    return this.muted;
  }

  isDronePlaying(): boolean {
    return this.droneActive && !this.muted;
  }

  setMuted(nextMuted: boolean): void {
    this.muted = nextMuted;
    try {
      window.localStorage.setItem(SOUND_PREF_KEY, nextMuted ? 'true' : 'false');
    } catch {
      // Ignore storage error
    }
    if (nextMuted) {
      this.stopDrone();
    }
  }

  toggleMute(): boolean {
    const next = !this.muted;
    this.setMuted(next);
    if (!next) {
      this.playWelcomeChord();
    }
    return next;
  }

  // Synthesized harmonic drone tuned to Raag Bhairavi / Bhitai Sur
  startDrone(): void {
    if (this.muted || this.droneActive) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.analyser) return;

    const master = ctx.createGain();
    master.gain.setValueAtTime(0.0001, ctx.currentTime);
    master.gain.exponentialRampToValueAtTime(0.036, ctx.currentTime + 1.2);

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(
      this.instrument === 'alghoza' ? 920 : this.instrument === 'surando' ? 760 : 620,
      ctx.currentTime
    );
    filter.Q.setValueAtTime(1.8, ctx.currentTime);

    filter.connect(master);
    master.connect(this.analyser);

    const profileFreqs: Record<AcousticInstrumentMode, number[]> = {
      tambura: [146.83, 220.0, 293.66, 294.4],
      alghoza: [293.66, 329.63, 440.0, 587.33],
      surando: [146.83, 196.0, 293.66, 440.0],
    };
    const freqs = profileFreqs[this.instrument];

    const oscs: OscillatorNode[] = freqs.map((hz, i) => {
      const osc = ctx.createOscillator();
      if (this.instrument === 'alghoza') {
        osc.type = i % 2 === 0 ? 'sine' : 'triangle';
      } else if (this.instrument === 'surando') {
        osc.type = i === 0 ? 'sawtooth' : 'triangle';
      } else {
        osc.type = i % 2 === 0 ? 'triangle' : 'sine';
      }
      osc.frequency.setValueAtTime(hz, ctx.currentTime);

      const g = ctx.createGain();
      g.gain.setValueAtTime(i === 0 ? 0.42 : i === 1 ? 0.32 : 0.16, ctx.currentTime);
      osc.connect(g);
      g.connect(filter);
      osc.start();
      return osc;
    });

    this.droneMaster = master;
    this.droneOscs = oscs;
    this.droneActive = true;
  }

  stopDrone(): void {
    if (!this.droneActive || !this.ctx || !this.droneMaster) {
      this.droneActive = false;
      return;
    }
    const now = this.ctx.currentTime;
    try {
      this.droneMaster.gain.setValueAtTime(Math.max(0.001, this.droneMaster.gain.value), now);
      this.droneMaster.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);
      const oldOscs = this.droneOscs;
      window.setTimeout(() => {
        oldOscs.forEach((o) => {
          try {
            o.stop();
            o.disconnect();
          } catch {
            // Ignore already stopped
          }
        });
      }, 380);
    } catch {
      // Ignore teardown errors
    }
    this.droneOscs = [];
    this.droneMaster = null;
    this.droneActive = false;
  }

  // Warm Raag Bhairavi / Alghoza welcome arpeggio
  playWelcomeChord(): void {
    if (this.muted) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.analyser) return;

    const notes =
      this.instrument === 'alghoza'
        ? [329.63, 440.0, 523.25, 659.25]
        : [293.66, 369.99, 440.0, 587.33];
    const now = ctx.currentTime;

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = idx === 3 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.11);

      gain.gain.setValueAtTime(0.0001, now + idx * 0.11);
      gain.gain.exponentialRampToValueAtTime(0.055, now + idx * 0.11 + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.11 + 1.35);

      osc.connect(gain);
      gain.connect(this.analyser!);
      osc.start(now + idx * 0.11);
      osc.stop(now + idx * 0.11 + 1.4);
    });
  }

  // Crisp golden seal chime when a SHA-256 block or Otaq witness is sealed
  playSealChime(): void {
    if (this.muted) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.analyser) return;
    const now = ctx.currentTime;

    [587.33, 880.0].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);
      gain.gain.setValueAtTime(0.0001, now + idx * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.045, now + idx * 0.08 + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 0.7);
      osc.connect(gain);
      gain.connect(this.analyser!);
      osc.start(now + idx * 0.08);
      osc.stop(now + idx * 0.08 + 0.75);
    });
  }
}

export const sufiSoundscape = new SufiSoundscapeEngine();
