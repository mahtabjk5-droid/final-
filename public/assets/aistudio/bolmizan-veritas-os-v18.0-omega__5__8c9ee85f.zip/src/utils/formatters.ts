import type { CurrencyCode, PaymentTransaction } from '../../shared/types';
import { CURRENCY_METADATA } from '../../shared/rails';

export function formatCurrency(amount: number, currency: CurrencyCode = 'USD'): string {
  const meta = CURRENCY_METADATA[currency];
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
      minimumFractionDigits: meta.decimals,
      maximumFractionDigits: meta.decimals,
    }).format(amount);
  } catch {
    return `${meta.symbol}${amount.toFixed(meta.decimals)}`;
  }
}

export function formatCompactUsd(amount: number): string {
  if (amount >= 1_000_000) return `$${(amount / 1_000_000).toFixed(2)}M`;
  if (amount >= 10_000) return `$${(amount / 1_000).toFixed(1)}K`;
  return formatCurrency(amount, 'USD');
}

export function formatTimestamp(iso: string): string {
  const date = new Date(iso);
  return date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
}

export function formatRelativeTime(iso: string): string {
  const diffSec = Math.max(0, Math.floor((Date.now() - Date.parse(iso)) / 1000));
  if (diffSec < 10) return 'Just now';
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function downloadTransactionsCsv(rows: PaymentTransaction[]): void {
  const headers = [
    'Reference',
    'CreatedAt',
    'Status',
    'Rail',
    'Amount',
    'Currency',
    'USDAmount',
    'FeeUSD',
    'NetUSD',
    'Customer',
    'Country',
    'UTM_Source',
    'IdempotencyKey',
  ];
  const escape = (val: string | number | null) => {
    const str = val === null ? '' : String(val);
    return `"${str.replace(/"/g, '""')}"`;
  };
  const csvLines = [
    headers.join(','),
    ...rows.map((r) =>
      [
        r.reference,
        r.createdAt,
        r.status,
        r.railName,
        r.amount,
        r.currency,
        r.usdAmount,
        r.feeUsd,
        r.netUsd,
        r.customerName,
        r.customerCountry,
        r.utmSource,
        r.idempotencyKey,
      ]
        .map(escape)
        .join(',')
    ),
  ];
  const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `meridianpay-ledger-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
