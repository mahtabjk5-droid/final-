import { useEffect, useState } from 'react';
import { ArrowRight, MapPin, Music2, Sparkles, Volume2, X } from 'lucide-react';
import type { UiLanguage } from '../../shared/types';
import { sufiSoundscape } from '../utils/sufiSoundscape';
import { speakMultilingual } from '../utils/ttsAndOffline';
import { PoorySindhMap } from './PoorySindhMap';
import { SindhMizanEmblem } from './SindhMizanEmblem';

interface BhaliKareAayaWelcomeProps {
  userName: string;
  businessName: string;
  language: UiLanguage;
  onDismiss: () => void;
}

export function BhaliKareAayaWelcome({
  userName,
  businessName,
  language,
  onDismiss,
}: BhaliKareAayaWelcomeProps) {
  const [audioStarted, setAudioStarted] = useState(false);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Enter') {
        onDismiss();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onDismiss]);

  function handleActivateSoundAndVoice() {
    setAudioStarted(true);
    sufiSoundscape.setMuted(false);
    sufiSoundscape.playWelcomeChord();
    sufiSoundscape.startDrone();
    const spokenLine =
      language === 'ur'
        ? `بھلی کرے آیا ${userName}! سندھ میزان او ایس میں خوش آمدید`
        : language === 'ar'
          ? `مرحباً ${userName} في نظام سندھ ميزان من سكرند`
          : `Bhali Kare Aaya ${userName}! Sindh Mizan OS mein Khush Amdeed.`;
    speakMultilingual(spokenLine, language === 'en' ? 'ur' : language);
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Indus Heritage Corridor & Bhali Kare Aaya"
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/75 p-4 backdrop-blur-sm dark:bg-[#0B1117]/85"
      onClick={onDismiss}
    >
      <div
        className="relative max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-2xl border border-teal-500/35 bg-gradient-to-br from-[#0D2327] via-[#0B191D] to-[#1A1015] p-6 text-white shadow-2xl sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="ajrak-lattice pointer-events-none absolute inset-0 opacity-45" />

        <svg
          viewBox="0 0 800 120"
          preserveAspectRatio="none"
          className="pointer-events-none absolute inset-x-0 bottom-0 h-28 w-full opacity-35"
        >
          <path
            d="M0 70 Q 140 20 280 65 T 560 60 T 800 50 L 800 120 L 0 120 Z"
            fill="#14B8A6"
            fillOpacity="0.24"
            className="indus-wave-slow"
          />
          <path
            d="M0 84 Q 180 45 360 80 T 720 72 L 800 84 L 800 120 L 0 120 Z"
            fill="#F59E0B"
            fillOpacity="0.16"
          />
        </svg>

        <div className="relative z-10 space-y-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <SindhMizanEmblem size={64} tiltDeg={0} />
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold text-teal-300">
                  <MapPin className="h-3.5 w-3.5" />
                  <span>Sakrand, Sindh, Pakistan · SINDH-MIZAN OS™</span>
                </div>
                <h2 className="mt-1 font-editorial text-3xl font-bold tracking-tight text-white">
                  Bhali Kare Aaya — ڀلي ڪري آيا
                </h2>
                <p className="text-sm text-teal-200">
                  Welcome, {userName} · {businessName}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleActivateSoundAndVoice}
                className="inline-flex items-center gap-2 rounded-xl border border-teal-400/40 bg-teal-500/15 px-3.5 py-2 text-xs font-semibold text-teal-100 transition-colors hover:bg-teal-500/25"
              >
                {audioStarted ? <Music2 className="h-4 w-4 text-teal-300" /> : <Volume2 className="h-4 w-4" />}
                <span>{audioStarted ? 'Tambura & Voice Active' : 'Play Bhitai Tambura'}</span>
              </button>
              <button
                type="button"
                onClick={onDismiss}
                aria-label="Close Heritage Modal"
                className="rounded-xl border border-white/20 p-2 text-stone-300 hover:bg-white/10"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="rounded-xl border border-white/10 bg-black/30 p-4 text-sm leading-relaxed text-stone-200">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
              <Sparkles className="h-3.5 w-3.5" />
              <span>Adl Jo Tarazu, Amanat Jo Khazano (سنڌ ميزان | سندھ میزان)</span>
            </div>
            <p className="mt-1.5 text-xs text-stone-300 sm:text-sm">
              Every block in your ledger honors 5,000 years of Indus Valley seal integrity — 0% Riba mathematical enforcement, Quran 2:280 grace protection, and instant Raast clearing from Sakrand Bazaar to Riyadh, Dubai, London, and New York.
            </p>
          </div>

          <PoorySindhMap language={language} compact />

          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/15 pt-4">
            <div className="text-xs text-stone-300">
              Zero-Trust Active · Session locks automatically whenever you exit
            </div>
            <button
              type="button"
              onClick={onDismiss}
              className="inline-flex items-center gap-2 rounded-xl bg-teal-500 px-5 py-2.5 text-sm font-bold text-slate-950 transition-colors hover:bg-teal-400"
            >
              <span>Return to Astrolabe Workspace</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
