import { useId, type CSSProperties } from 'react';

interface SindhMizanEmblemProps {
  size?: number;
  tiltDeg?: number;
  animatePulseKey?: number;
  tiltKickDeg?: number;
  className?: string;
}

export function SindhMizanEmblem({
  size = 44,
  tiltDeg = 0,
  animatePulseKey = 0,
  tiltKickDeg = 0,
  className = '',
}: SindhMizanEmblemProps) {
  const uid = useId().replace(/:/g, '');
  const outerGradId = `kashiOuterGrad_${uid}`;
  const brassGradId = `brassGrad_${uid}`;
  const clampedTilt = Math.max(-14, Math.min(14, tiltDeg));
  const shouldSpringAnimate = animatePulseKey > 0 || tiltKickDeg !== 0;

  const beamStyle: CSSProperties = shouldSpringAnimate
    ? ({
        '--mizan-tilt': `${clampedTilt}deg`,
        '--mizan-kick': `${tiltKickDeg || 6}deg`,
      } as CSSProperties)
    : {
        transform: `rotate(${clampedTilt}deg)`,
        transformOrigin: '48px 35px',
        transition: 'transform 450ms cubic-bezier(0.16, 1, 0.3, 1)',
      };

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 96 96"
      role="img"
      aria-label="SINDH-MIZAN OS Emblem"
      className={className}
    >
      <defs>
        <linearGradient id={outerGradId} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0F766E" />
          <stop offset="55%" stopColor="#134E4A" />
          <stop offset="100%" stopColor="#0D1B22" />
        </linearGradient>
        <linearGradient id={brassGradId} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FDE68A" />
          <stop offset="50%" stopColor="#F59E0B" />
          <stop offset="100%" stopColor="#B45309" />
        </linearGradient>
      </defs>

      {/* Octagonal Hala Kashi Ceramic & Brass Seal Frame */}
      <polygon
        points="30,6 66,6 90,30 90,66 66,90 30,90 6,66 6,30"
        fill={`url(#${outerGradId})`}
        stroke={`url(#${brassGradId})`}
        strokeWidth="2.4"
      />
      <polygon
        points="33,12 63,12 84,33 84,63 63,84 33,84 12,63 12,33"
        fill="none"
        stroke="#5EEAD4"
        strokeOpacity="0.45"
        strokeWidth="1"
        strokeDasharray="3 2"
      />

      {/* Geometric Sindhi Topi Arch Crown in Ajrak Crimson + Brass */}
      <path
        d="M32 27 Q48 16 64 27 L61 32 Q48 25 35 32 Z"
        fill={`url(#${brassGradId})`}
        stroke="#9B1C2E"
        strokeWidth="1"
      />
      <path d="M44 26 L48 21 L52 26 L48 29 Z" fill="#9B1C2E" />

      {/* Center Pillar & Base of the Precision Mizan Scale */}
      <path d="M35 74 L61 74 L56 69 L40 69 Z" fill={`url(#${brassGradId})`} />
      <rect x="46.5" y="34" width="3" height="36" rx="1.5" fill={`url(#${brassGradId})`} />
      <circle cx="48" cy="35" r="3.5" fill="#2DD4BF" stroke="#FDE68A" strokeWidth="1.2" />

      {/* Tilting Brass Mizan Balance Beam & Pans */}
      <g
        key={`${animatePulseKey}_${tiltKickDeg}`}
        className={shouldSpringAnimate ? 'mizan-beam-tilt' : undefined}
        style={beamStyle}
      >
        <rect x="23" y="33.5" width="50" height="3" rx="1.5" fill="#FDE68A" />
        {/* Left Pan (Indus Teal) */}
        <line x1="27" y1="36.5" x2="21" y2="54" stroke="#FDE68A" strokeWidth="1" />
        <line x1="27" y1="36.5" x2="33" y2="54" stroke="#FDE68A" strokeWidth="1" />
        <path d="M19 54 Q27 61 35 54 Z" fill="#2DD4BF" />
        {/* Right Pan (Ajrak Crimson) */}
        <line x1="69" y1="36.5" x2="63" y2="54" stroke="#FDE68A" strokeWidth="1" />
        <line x1="69" y1="36.5" x2="75" y2="54" stroke="#FDE68A" strokeWidth="1" />
        <path d="M61 54 Q69 61 77 54 Z" fill="#FB7185" />
      </g>

      {/* 4 Twinkling Shisha Mirror Diamonds */}
      <polygon points="48,11 50.5,14 48,17 45.5,14" fill="#FDE68A" className="shisha-glint" />
      <polygon points="48,79 50.5,82 48,85 45.5,82" fill="#FDE68A" className="shisha-glint" />
      <polygon points="14,48 17,45.5 20,48 17,50.5" fill="#5EEAD4" className="shisha-glint" />
      <polygon points="76,48 79,45.5 82,48 79,50.5" fill="#5EEAD4" className="shisha-glint" />
    </svg>
  );
}
