import { useState } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  CheckCircle2,
  Crown,
  Lock,
  QrCode,
  ShieldCheck,
  Unlock,
  Volume2,
  Wallet,
  X,
} from 'lucide-react';
import type {
  BranchId,
  FounderTreasuryState,
  MazdoorEscrowRecord,
  PaymentRailId,
  SaasTierId,
  UiLanguage,
  UserPublicProfile,
} from '../../shared/types';
import { formatCurrency } from '../utils/formatters';
import { apiFetch } from '../utils/sessionClient';
import { renderQrDataUrl, speakMultilingual } from '../utils/ttsAndOffline';

interface FounderTreasuryAndEscrowViewProps {
  user: UserPublicProfile;
  treasury: FounderTreasuryState;
  escrows: MazdoorEscrowRecord[];
  grossVolumeUsd: number;
  pardaActive: boolean;
  language: UiLanguage;
  onRefresh: () => Promise<void>;
}

const SAAS_TIERS: Array<{
  id: SaasTierId;
  name: string;
  audience: string;
  priceLabel: string;
  pkrLabel: string;
  limits: string[];
}> = [
  {
    id: 'mazdoor_free',
    name: 'Mazdoor & Sabzi-Wala',
    audience: 'For daily-wage workers & street vendors',
    priceLabel: '$0 / Free Forever',
    pkrLabel: 'PKR 0 · 0% Fee on Wages',
    limits: [
      'Voice-to-Hisab in Urdu, Sindhi & English',
      'Zero-fee Haq-e-Mazdoor Daily-Wage Vault',
      'Dynamic SBP Raast EMVCo QR Checkout',
    ],
  },
  {
    id: 'pro_trader',
    name: 'Pro Trader & Wholesaler',
    audience: 'For mandi brokers & multi-shop retailers',
    priceLabel: '$15 / month',
    pkrLabel: 'PKR 2,900 / month',
    limits: [
      'Unlimited Gemini 4 Hydrogen parsing',
      'Maal-Guard expiry & shrinkage radar',
      'Automated Urdu/Sindhi WhatsApp reminders',
    ],
  },
  {
    id: 'enterprise_exporter',
    name: 'Enterprise & Global Exporter',
    audience: 'For GCC/EU/US cross-border trade houses',
    priceLabel: '$79 / month',
    pkrLabel: 'SAR 299 / month',
    limits: [
      'Murabaha & Salam trade smart contracts',
      'ZATCA Phase-2 TLV & ISO-20022 XML exports',
      'Multi-Hop Mukasa Clearing & HMAC Webhooks',
    ],
  },
];

export function FounderTreasuryAndEscrowView({
  user,
  treasury,
  escrows,
  grossVolumeUsd,
  pardaActive,
  language,
  onRefresh,
}: FounderTreasuryAndEscrowViewProps) {
  const [tilt, setTilt] = useState({ rx: 0, ry: 0 });
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('250');
  const [withdrawRail, setWithdrawRail] = useState<
    'sbp_raast' | 'jazzcash' | 'wise_corridor' | 'stripe_card' | 'usdc_base'
  >('sbp_raast');
  const [withdrawDest, setWithdrawDest] = useState('PK36SCBL0000001123456702');
  const [withdrawPin, setWithdrawPin] = useState('7860');
  const [treasuryMsg, setTreasuryMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [upgradingTier, setUpgradingTier] = useState<SaasTierId | null>(null);

  const [workerName, setWorkerName] = useState('سرفراز جمالي (Sarfaraz Jamali)');
  const [workerPhone, setWorkerPhone] = useState('03019988776');
  const [employerName, setEmployerName] = useState('Sakrand Rice Husking Mill');
  const [workDesc, setWorkDesc] = useState('Full-day solar dryer installation & wiring');
  const [dailyWage, setDailyWage] = useState('2800');
  const [escrowRail, setEscrowRail] = useState<'sbp_raast' | 'jazzcash' | 'easypaisa'>('sbp_raast');
  const [escrowBranch, setEscrowBranch] = useState<Exclude<BranchId, 'all'>>('sakrand_hq');
  const [escrowBusy, setEscrowBusy] = useState(false);
  const [payoutQrModal, setPayoutQrModal] = useState<{
    escrow: MazdoorEscrowRecord;
    qrDataUrl: string;
    raastUri: string;
  } | null>(null);

  function handleCardMove(e: React.MouseEvent<HTMLDivElement>) {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ rx: Number((-py * 10).toFixed(2)), ry: Number((px * 12).toFixed(2)) });
  }

  async function handleWithdraw(e: React.FormEvent) {
    e.preventDefault();
    setTreasuryMsg(null);
    const res = await apiFetch('/api/treasury/withdraw', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        amountUsd: Number(withdrawAmount),
        railId: withdrawRail,
        destinationInput: withdrawDest,
        pin: withdrawPin,
      }),
    });
    const json = (await res.json()) as { error?: string };
    if (!res.ok) {
      setTreasuryMsg({ ok: false, text: json.error || 'Withdrawal failed.' });
      return;
    }
    setTreasuryMsg({
      ok: true,
      text: `Instant payout of $${withdrawAmount} dispatched to Mahtab Ali Jamali via ${withdrawRail}.`,
    });
    setWithdrawOpen(false);
    await onRefresh();
  }

  async function handleUpgradeTier(tierId: SaasTierId) {
    setUpgradingTier(tierId);
    setTreasuryMsg(null);
    try {
      const res = await apiFetch('/api/saas/upgrade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tierId, railId: 'sbp_raast' as PaymentRailId }),
      });
      if (res.ok) {
        setTreasuryMsg({
          ok: true,
          text: `Subscription updated cleanly to ${tierId.replace('_', ' ')} — Ujrah ledger synced.`,
        });
        await onRefresh();
      }
    } finally {
      setUpgradingTier(null);
    }
  }

  async function handleLockEscrow(e: React.FormEvent) {
    e.preventDefault();
    setEscrowBusy(true);
    try {
      const res = await apiFetch('/api/escrow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workerName,
          workerPhone,
          employerName,
          workDescription: workDesc,
          dailyWagePkr: Number(dailyWage),
          payoutRail: escrowRail,
          branchId: escrowBranch,
          language,
        }),
      });
      if (res.ok) {
        await onRefresh();
      }
    } finally {
      setEscrowBusy(false);
    }
  }

  async function handleReleaseEscrow(escrow: MazdoorEscrowRecord) {
    const res = await apiFetch(`/api/escrow/${escrow.id}/release`, { method: 'POST' });
    if (res.ok) {
      speakMultilingual(
        `${escrow.workerName}, ${escrow.dailyWagePkr} rupees Haq-e-Mazdoor settled directly via ${escrow.payoutRail}`,
        escrow.language
      );
      await onRefresh();
    }
  }

  async function handleOpenDirectPayoutQr(escrow: MazdoorEscrowRecord) {
    const raastUri = `raast://pay?pa=${encodeURIComponent(escrow.workerPhone)}&pn=${encodeURIComponent(escrow.workerName)}&am=${escrow.dailyWagePkr}&cu=PKR&tn=${encodeURIComponent(escrow.id)}`;
    const qrDataUrl = await renderQrDataUrl(raastUri);
    setPayoutQrModal({ escrow, qrDataUrl, raastUri });
  }

  const inputCls =
    'w-full rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 text-xs text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100 dark:focus:border-teal-400';

  return (
    <div className="space-y-6 veritas-enter">
      {/* Row 1: 3D-Tilt Founder Sovereign Card & Live Revenue Telemetry */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <div
            onMouseMove={handleCardMove}
            onMouseLeave={() => setTilt({ rx: 0, ry: 0 })}
            style={{
              transform: `perspective(950px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)`,
              transition: 'transform 160ms cubic-bezier(0.16, 1, 0.3, 1)',
            }}
            className="relative overflow-hidden rounded-2xl border border-teal-500/35 bg-gradient-to-br from-[#0D2327] via-[#0F2A2E] to-[#1A1015] p-6 text-white shadow-xl"
          >
            <div className="ajrak-lattice pointer-events-none absolute inset-0 opacity-45" />
            <div className="relative z-10 flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
                  <Crown className="h-4 w-4" />
                  <span>Founder Sovereign Treasury</span>
                </div>
                <div className="mt-1 font-display text-lg font-bold tracking-tight">
                  {treasury.founderName}
                </div>
                <div className="font-mono text-xs text-teal-100/80">{treasury.founderEmail}</div>
              </div>
              <span className="rounded-md border border-teal-400/30 bg-teal-500/15 px-2 py-0.5 font-mono text-[11px] font-semibold text-teal-200">
                24K HALAL
              </span>
            </div>

            <div className="relative z-10 mt-6">
              <div className="text-xs text-teal-100/70">Available Treasury Balance</div>
              <div
                className={`mt-1 font-mono text-3xl font-bold tracking-tight text-amber-300 tabular-nums ${
                  pardaActive ? 'parda-blur' : ''
                }`}
              >
                {formatCurrency(treasury.availableBalanceUsd, 'USD')}
              </div>
            </div>

            <div className="relative z-10 mt-6 grid grid-cols-3 gap-3 border-t border-white/10 pt-4 text-xs">
              <div>
                <div className="text-teal-100/70">Monthly MRR</div>
                <div className={`font-mono font-semibold text-teal-300 tabular-nums ${pardaActive ? 'parda-blur' : ''}`}>
                  {formatCurrency(treasury.mrrUsd, 'USD')}
                </div>
              </div>
              <div>
                <div className="text-teal-100/70">Flat Ujrah</div>
                <div className="font-mono font-semibold text-white tabular-nums">
                  {formatCurrency(treasury.cumulativeUjrahUsd, 'USD')}
                </div>
              </div>
              <div>
                <div className="text-teal-100/70">HQ Node</div>
                <div className="truncate font-medium text-amber-200">Sakrand, PK</div>
              </div>
            </div>

            <div className="relative z-10 mt-5 flex flex-wrap items-center justify-between gap-2">
              <div className="text-[11px] text-teal-100/70">
                Cleared Network Vol: <span className="font-mono text-white">{formatCurrency(grossVolumeUsd, 'USD')}</span>
              </div>
              <button
                type="button"
                onClick={() => setWithdrawOpen((w) => !w)}
                className="inline-flex items-center gap-1.5 rounded-xl bg-teal-500 px-3.5 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-teal-400"
              >
                <Wallet className="h-3.5 w-3.5" />
                <span>{withdrawOpen ? 'Close Payout' : 'Instant Withdraw'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right: Instant Withdrawal Drawer + Live Treasury Ujrah Feed */}
        <div className="space-y-4 rounded-xl border border-stone-200 bg-white p-6 lg:col-span-7 dark:border-slate-800 dark:bg-[#111922]">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
                Non-Custodial Software Ujrah &amp; SaaS Ledger
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                100% Non-Custodial SBP/SAMA Orchestration: flat $0.30 / PKR 25 software Ujrah invoicing per export or rescue — zero custody of customer funds
              </p>
            </div>
            <div className="font-mono text-xs font-semibold text-teal-700 tabular-nums dark:text-teal-400">
              {treasury.activeEnterpriseSubscribers} Ent · {treasury.activeProSubscribers} Pro
            </div>
          </div>

          {treasuryMsg && (
            <div
              className={`rounded-xl border px-3.5 py-2.5 text-xs font-medium ${
                treasuryMsg.ok
                  ? 'border-teal-600/30 bg-teal-700/10 text-teal-800 dark:text-teal-300'
                  : 'border-[#9B1C2E]/30 bg-[#9B1C2E]/10 text-[#9B1C2E] dark:text-rose-300'
              }`}
            >
              {treasuryMsg.text}
            </div>
          )}

          {withdrawOpen && (
            <form
              onSubmit={handleWithdraw}
              className="grid grid-cols-1 gap-3 rounded-xl border border-teal-600/30 bg-teal-700/5 p-4 sm:grid-cols-4 dark:bg-teal-500/10"
            >
              <div>
                <label className="block text-[11px] font-medium text-stone-700 dark:text-stone-300">
                  Amount (USD)
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  step="any"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 font-mono text-xs dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-stone-700 dark:text-stone-300">
                  Payout Rail
                </label>
                <select
                  value={withdrawRail}
                  onChange={(e) => setWithdrawRail(e.target.value as typeof withdrawRail)}
                  className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 text-xs dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
                >
                  <option value="sbp_raast">SBP Raast IBAN</option>
                  <option value="jazzcash">JazzCash</option>
                  <option value="wise_corridor">Wise Global</option>
                  <option value="stripe_card">Stripe Payout</option>
                  <option value="usdc_base">USDC Base</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-medium text-stone-700 dark:text-stone-300">
                  Destination ID / IBAN
                </label>
                <input
                  type="text"
                  required
                  value={withdrawDest}
                  onChange={(e) => setWithdrawDest(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 font-mono text-xs dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
                />
              </div>
              <div className="flex items-end gap-2">
                <div className="flex-1">
                  <label className="block text-[11px] font-medium text-stone-700 dark:text-stone-300">
                    PIN
                  </label>
                  <input
                    type="password"
                    required
                    value={withdrawPin}
                    onChange={(e) => setWithdrawPin(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 font-mono text-xs dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
                  />
                </div>
                <button
                  type="submit"
                  className="rounded-xl bg-teal-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                >
                  Send
                </button>
              </div>
            </form>
          )}

          <div className="max-h-56 divide-y divide-stone-200 overflow-y-auto dark:divide-slate-800">
            {treasury.entries.slice(0, 8).map((entry) => {
              const isOut = entry.amountUsd < 0;
              return (
                <div key={entry.id} className="flex items-center justify-between gap-3 py-2.5 text-xs">
                  <div className="flex min-w-0 items-center gap-2.5">
                    {isOut ? (
                      <ArrowUpRight className="h-4 w-4 shrink-0 text-[#9B1C2E] dark:text-rose-400" />
                    ) : (
                      <ArrowDownLeft className="h-4 w-4 shrink-0 text-teal-700 dark:text-teal-400" />
                    )}
                    <div className="min-w-0">
                      <div className="truncate font-medium text-stone-900 dark:text-stone-100">
                        {entry.description}
                      </div>
                      <div className="font-mono text-[11px] text-stone-500 dark:text-stone-400">
                        {entry.reference} · {entry.railUsed}
                      </div>
                    </div>
                  </div>
                  <div
                    className={`shrink-0 text-right font-mono font-semibold tabular-nums ${
                      isOut ? 'text-[#9B1C2E] dark:text-rose-400' : 'text-teal-700 dark:text-teal-400'
                    } ${pardaActive ? 'parda-blur' : ''}`}
                  >
                    {isOut ? '-' : '+'}${Math.abs(entry.amountUsd).toFixed(2)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Row 2: 3-Tier Halal SaaS Plans */}
      <section className="rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
              Shariah SaaS Plans &amp; Instant Tier Activation
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              Current active tier:{' '}
              <span className="font-semibold text-teal-700 dark:text-teal-400">
                {user.subscriptionTier.replace('_', ' ')}
              </span>
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {SAAS_TIERS.map((plan) => {
            const active = user.subscriptionTier === plan.id;
            return (
              <div
                key={plan.id}
                className={`flex flex-col justify-between rounded-xl border p-5 transition-colors ${
                  active
                    ? 'border-teal-600 bg-teal-700/6 dark:border-teal-400 dark:bg-teal-500/10'
                    : 'border-stone-200 bg-[#F8F7F3] dark:border-slate-800 dark:bg-[#0B1117]'
                }`}
              >
                <div>
                  <div className="text-xs text-stone-500 dark:text-stone-400">{plan.audience}</div>
                  <div className="mt-1 font-display text-base font-bold text-stone-900 dark:text-stone-100">
                    {plan.name}
                  </div>
                  <div className="mt-3 font-mono text-xl font-bold text-stone-900 tabular-nums dark:text-teal-300">
                    {plan.priceLabel}
                  </div>
                  <div className="font-mono text-xs text-stone-500 dark:text-stone-400">
                    {plan.pkrLabel}
                  </div>
                  <ul className="mt-4 space-y-2 text-xs text-stone-700 dark:text-stone-300">
                    {plan.limits.map((l) => (
                      <li key={l} className="flex items-start gap-2">
                        <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-teal-700 dark:text-teal-400" />
                        <span>{l}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  type="button"
                  disabled={active || upgradingTier !== null}
                  onClick={() => handleUpgradeTier(plan.id)}
                  className={`mt-5 w-full rounded-xl py-2.5 text-xs font-semibold transition-colors ${
                    active
                      ? 'bg-teal-700/15 text-teal-800 dark:bg-teal-500/20 dark:text-teal-300'
                      : 'bg-teal-700 text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400'
                  }`}
                >
                  {active
                    ? 'Current Active Plan'
                    : upgradingTier === plan.id
                      ? 'Activating...'
                      : `Activate ${plan.name}`}
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Row 3: Haq-e-Mazdoor Verified Wage Milestones */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <form
          onSubmit={handleLockEscrow}
          className="space-y-3 rounded-xl border border-stone-200 bg-white p-6 lg:col-span-5 dark:border-slate-800 dark:bg-[#111922]"
        >
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-teal-700 dark:text-teal-400" />
            <h3 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
              Haq-e-Mazdoor Non-Custodial Wage Tracker
            </h3>
          </div>
          <p className="text-xs text-stone-500 dark:text-stone-400">
            Create verified daily-wage milestones (0% fee, non-custodial). Generate direct SBP Raast / JazzCash / Easypaisa payout QR links so funds settle straight from contractor to worker.
          </p>

          <input
            type="text"
            required
            value={workerName}
            onChange={(e) => setWorkerName(e.target.value)}
            placeholder="Worker Name (Urdu/Sindhi/English)"
            className={inputCls}
          />
          <div className="grid grid-cols-2 gap-2">
            <input
              type="text"
              required
              value={workerPhone}
              onChange={(e) => setWorkerPhone(e.target.value)}
              placeholder="03001234567"
              className={`${inputCls} font-mono`}
            />
            <input
              type="number"
              required
              min="200"
              value={dailyWage}
              onChange={(e) => setDailyWage(e.target.value)}
              placeholder="Wage PKR"
              className={`${inputCls} font-mono`}
            />
          </div>
          <input
            type="text"
            required
            value={employerName}
            onChange={(e) => setEmployerName(e.target.value)}
            placeholder="Employer / Farm / Mill Name"
            className={inputCls}
          />
          <input
            type="text"
            required
            value={workDesc}
            onChange={(e) => setWorkDesc(e.target.value)}
            placeholder="Shift or harvest work scope"
            className={inputCls}
          />
          <div className="grid grid-cols-2 gap-2">
            <select
              value={escrowRail}
              onChange={(e) => setEscrowRail(e.target.value as typeof escrowRail)}
              className={inputCls}
            >
              <option value="sbp_raast">SBP Raast (0% Fee)</option>
              <option value="jazzcash">JazzCash Wallet</option>
              <option value="easypaisa">Easypaisa Wallet</option>
            </select>
            <select
              value={escrowBranch}
              onChange={(e) => setEscrowBranch(e.target.value as Exclude<BranchId, 'all'>)}
              className={inputCls}
            >
              <option value="sakrand_hq">Sakrand Main HQ</option>
              <option value="karachi_port">Karachi Port</option>
              <option value="riyadh_hub">Riyadh Hub</option>
              <option value="dubai_marina">Dubai Marina</option>
            </select>
          </div>
          <button
            type="submit"
            disabled={escrowBusy}
            className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-teal-700 px-4 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
          >
            <Lock className="h-3.5 w-3.5" />
            <span>{escrowBusy ? 'Creating Milestone...' : 'Create Verified Wage Milestone'}</span>
          </button>
        </form>

        <div className="space-y-3 rounded-xl border border-stone-200 bg-white p-6 lg:col-span-7 dark:border-slate-800 dark:bg-[#111922]">
          <div className="flex items-center justify-between">
            <h3 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
              Verified Wage Milestones &amp; Direct Payout Links ({escrows.length})
            </h3>
            <span className="text-xs font-medium text-teal-700 dark:text-teal-400">
              Non-Custodial · Zero Deduction
            </span>
          </div>

          <div className="space-y-3">
            {escrows.map((esc) => {
              const pending = esc.status === 'locked';
              return (
                <div
                  key={esc.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-stone-200 bg-[#F8F7F3] p-4 dark:border-slate-800 dark:bg-[#0B1117]"
                >
                  <div>
                    <div className="text-sm font-semibold text-stone-900 dark:text-stone-100">
                      {esc.workerName}
                    </div>
                    <div className="mt-0.5 text-xs text-stone-500 dark:text-stone-400">
                      {esc.employerName} · {esc.workDescription}
                    </div>
                    <div className="mt-1 font-mono text-[11px] text-stone-500 dark:text-slate-400">
                      {esc.payoutRail.toUpperCase()} ({esc.workerPhone}) · {esc.releaseRef || 'Awaiting Direct Raast Settlement'}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`font-mono text-sm font-bold tabular-nums text-stone-900 dark:text-teal-300 ${
                        pardaActive ? 'parda-blur' : ''
                      }`}
                    >
                      {formatCurrency(esc.dailyWagePkr, 'PKR')}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleOpenDirectPayoutQr(esc)}
                      title="Direct Non-Custodial Raast Payout QR"
                      className="inline-flex items-center gap-1 rounded-xl border border-stone-200 bg-white px-2.5 py-2 text-xs font-medium text-stone-700 hover:bg-stone-100 dark:border-slate-800 dark:bg-[#111922] dark:text-stone-200 dark:hover:bg-slate-800"
                    >
                      <QrCode className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
                      <span>Pay Link</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        speakMultilingual(
                          `${esc.workerName}, ${esc.dailyWagePkr} rupees ${esc.status}`,
                          esc.language
                        )
                      }
                      title="Audio Confirmation"
                      className="rounded-xl border border-stone-200 bg-white p-2 text-stone-600 hover:bg-stone-100 dark:border-slate-800 dark:bg-[#111922] dark:text-stone-300 dark:hover:bg-slate-800"
                    >
                      <Volume2 className="h-3.5 w-3.5" />
                    </button>
                    {pending ? (
                      <button
                        type="button"
                        onClick={() => handleReleaseEscrow(esc)}
                        className="inline-flex items-center gap-1 rounded-xl bg-teal-700 px-3 py-2 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                      >
                        <Unlock className="h-3.5 w-3.5" />
                        <span>Mark Paid</span>
                      </button>
                    ) : (
                      <span className="text-xs font-semibold text-teal-700 dark:text-teal-400">
                        Settled Direct
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {payoutQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/70 p-4 backdrop-blur-sm dark:bg-[#0B1117]/80">
          <div className="veritas-enter w-full max-w-md rounded-2xl border border-stone-200 bg-white p-6 text-center shadow-2xl dark:border-slate-800 dark:bg-[#111922]">
            <div className="flex items-center justify-between">
              <div className="text-left">
                <h4 className="font-display text-sm font-bold text-stone-900 dark:text-stone-100">
                  Direct Non-Custodial Raast Wage Link
                </h4>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  Contractor → {payoutQrModal.escrow.workerName} (0% platform custody)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPayoutQrModal(null)}
                className="rounded-lg p-1 text-stone-500 hover:bg-stone-100 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <img
              src={payoutQrModal.qrDataUrl}
              alt="Direct SBP Raast Payout QR"
              className="mx-auto mt-4 h-44 w-44 rounded-xl border border-stone-200 bg-white p-2"
            />
            <div className="mt-3 font-mono text-lg font-bold text-teal-700 dark:text-teal-400">
              {formatCurrency(payoutQrModal.escrow.dailyWagePkr, 'PKR')}
            </div>
            <div className="mt-1 rounded-xl bg-[#F8F7F3] p-2 font-mono text-[10px] break-all text-stone-600 dark:bg-[#0B1117] dark:text-stone-400">
              {payoutQrModal.raastUri}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
