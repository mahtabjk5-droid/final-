import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, Music2, Palette, Sparkles, Volume2, VolumeX } from 'lucide-react';
import type { NavSection, UiLanguage } from '../../shared/types';
import {
  CULTURAL_MOTIFS,
  HALAL_IDEAS_BLUEPRINTS,
  LIVING_SINDH_MILESTONES,
  type CulturalMotifId,
} from '../utils/culturalCalendar';
import { sufiSoundscape, type AcousticInstrumentMode } from '../utils/sufiSoundscape';
import { speakMultilingual } from '../utils/ttsAndOffline';

interface SindhCultureStudioProps {
  language: UiLanguage;
  activeMotif: CulturalMotifId;
  soundMuted: boolean;
  onSelectMotif: (motif: CulturalMotifId) => void;
  onToggleSound: () => void;
  onNavigate: (section: NavSection) => void;
}

const ACOUSTIC_PROFILES: Array<{
  id: AcousticInstrumentMode;
  label: string;
  sub: string;
}> = [
  { id: 'tambura', label: 'Bhitai Tambura', sub: 'D–A–D Sufi Drone' },
  { id: 'alghoza', label: 'Indus Alghoza', sub: 'Dual Reed Flute' },
  { id: 'surando', label: 'Sindhi Surando', sub: 'Bowed Strings' },
];

export function SindhCultureStudio({
  language,
  activeMotif,
  soundMuted,
  onSelectMotif,
  onToggleSound,
  onNavigate,
}: SindhCultureStudioProps) {
  const [milestoneIdx, setMilestoneIdx] = useState(0);
  const [instrument, setInstrument] = useState<AcousticInstrumentMode>(() =>
    sufiSoundscape.getInstrument()
  );
  const [craftImgMode, setCraftImgMode] = useState<'ajrak' | 'kashi'>('ajrak');
  const [imgFailed, setImgFailed] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const milestone = LIVING_SINDH_MILESTONES[milestoneIdx] ?? LIVING_SINDH_MILESTONES[0];
  const isRtlScript = language === 'ur' || language === 'sd' || language === 'ar';

  useEffect(() => {
    const id = window.setInterval(() => {
      setMilestoneIdx((prev) => (prev + 1) % LIVING_SINDH_MILESTONES.length);
    }, 11000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const spectrum = new Uint8Array(new ArrayBuffer(64));
    let rafId = 0;
    let phase = 0;

    const draw = () => {
      phase += 0.032;
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const hasAudio = sufiSoundscape.sampleSpectrum(spectrum);

      ctx.strokeStyle = 'rgba(15, 118, 110, 0.16)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, h / 2);
      ctx.lineTo(w, h / 2);
      ctx.stroke();

      ctx.beginPath();
      const bars = 48;
      for (let i = 0; i <= bars; i++) {
        const x = (i / bars) * w;
        const bin = hasAudio ? spectrum[i % spectrum.length] / 255 : 0;
        const riverWave = Math.sin(i * 0.28 + phase) * 8 + Math.cos(i * 0.14 - phase * 0.7) * 5;
        const amp = hasAudio ? bin * (h * 0.36) + riverWave * 0.45 : riverWave;
        const y = h / 2 + amp;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = hasAudio ? '#9B1C2E' : '#0F766E';
      ctx.lineWidth = 2;
      ctx.stroke();

      if (hasAudio) {
        const step = w / 24;
        for (let b = 0; b < 24; b++) {
          const val = spectrum[b] / 255;
          const barH = Math.max(2, val * (h * 0.55));
          ctx.fillStyle = b % 2 === 0 ? 'rgba(155, 28, 46, 0.35)' : 'rgba(15, 118, 110, 0.35)';
          ctx.fillRect(b * step + 2, h - barH, step - 4, barH);
        }
      }

      rafId = window.requestAnimationFrame(draw);
    };

    rafId = window.requestAnimationFrame(draw);
    return () => window.cancelAnimationFrame(rafId);
  }, [soundMuted, instrument]);

  function handleSwitchInstrument(mode: AcousticInstrumentMode) {
    setInstrument(mode);
    sufiSoundscape.setInstrument(mode);
    if (soundMuted) {
      onToggleSound();
    }
  }

  const activeCraftSrc =
    craftImgMode === 'ajrak'
      ? '/src/assets/images/ajrak_mercantile_craft_1794630302546.jpg'
      : '/src/assets/images/kashi_mizan_pavilion_1794630301954.jpg';

  return (
    <section
      aria-label="Living Sindh Cultural & Acoustic Atelier"
      className="overflow-hidden rounded-xl border border-stone-200 bg-white dark:border-slate-800 dark:bg-[#111922]"
    >
      <div className="grid grid-cols-1 divide-y divide-stone-200 lg:grid-cols-12 lg:divide-x lg:divide-y-0 dark:divide-slate-800">
        {/* Left: Curated Craft Window */}
        <div className="relative min-h-[260px] overflow-hidden bg-[#0D2327] lg:col-span-5">
          {!imgFailed ? (
            <img
              src={activeCraftSrc}
              alt={
                craftImgMode === 'ajrak'
                  ? 'Hand-printed Sindhi Ajrak textile, brass mercantile compass, and linen ledger'
                  : 'Hala turquoise glazed Kashi courtyard pavilion with brass Mizan scale'
              }
              referrerPolicy="no-referrer"
              onError={() => setImgFailed(true)}
              className="h-full w-full object-cover transition-opacity duration-300"
            />
          ) : (
            <div className="ajrak-lattice flex h-full w-full items-center justify-center bg-[#0D2327] p-6 text-center text-teal-100">
              <span className="font-editorial text-xl font-bold">
                Sindhi Ajrak · Topi · Hala Kashi Atelier
              </span>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#08171A]/95 via-[#08171A]/35 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 flex flex-wrap items-end justify-between gap-3 p-5 text-white">
            <div>
              <div className="text-[11px] font-medium text-teal-200">
                5,000-Year Living Craft · Sakrand &amp; Hala
              </div>
              <div className="mt-0.5 font-editorial text-xl font-bold leading-tight">
                {craftImgMode === 'ajrak'
                  ? 'Ajrak & Mercantile Ledger Craft'
                  : 'Hala Kashi Courtyard Architecture'}
              </div>
            </div>

            <div className="flex items-center gap-1 rounded-lg border border-white/20 bg-[#08171A]/80 p-1 backdrop-blur-sm">
              <button
                type="button"
                onClick={() => {
                  setImgFailed(false);
                  setCraftImgMode('ajrak');
                }}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold whitespace-nowrap transition-colors ${
                  craftImgMode === 'ajrak'
                    ? 'bg-white text-slate-900'
                    : 'text-teal-100 hover:text-white'
                }`}
              >
                Ajrak Craft
              </button>
              <button
                type="button"
                onClick={() => {
                  setImgFailed(false);
                  setCraftImgMode('kashi');
                }}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold whitespace-nowrap transition-colors ${
                  craftImgMode === 'kashi'
                    ? 'bg-teal-400 text-slate-950'
                    : 'text-teal-100 hover:text-white'
                }`}
              >
                Kashi Courtyard
              </button>
            </div>
          </div>
        </div>

        {/* Right: Cultural Milestone & Motif Selector */}
        <div className="flex flex-col justify-between p-6 lg:col-span-7">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <Sparkles className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {milestone.season}
                </span>
                <span aria-hidden="true">·</span>
                <span>0% Riba Living Sindh Pulse</span>
              </div>

              <div className="flex items-center gap-1">
                {LIVING_SINDH_MILESTONES.map((item, idx) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setMilestoneIdx(idx);
                      onSelectMotif(item.motif);
                    }}
                    className={`rounded-md px-2 py-1 text-[11px] font-semibold whitespace-nowrap transition-colors ${
                      milestoneIdx === idx
                        ? 'bg-teal-700 text-white dark:bg-teal-500 dark:text-slate-950'
                        : 'text-slate-500 hover:bg-stone-100 dark:text-slate-400 dark:hover:bg-slate-800'
                    }`}
                  >
                    0{idx + 1}
                  </button>
                ))}
              </div>
            </div>

            <h3
              dir={isRtlScript ? 'rtl' : 'ltr'}
              className={`mt-4 text-2xl font-bold text-slate-900 dark:text-white ${
                isRtlScript ? 'font-nastaliq' : 'font-editorial tracking-tight sm:text-3xl'
              }`}
            >
              {milestone.title[language]}
            </h3>

            <p
              dir={isRtlScript ? 'rtl' : 'ltr'}
              className={`mt-2 max-w-2xl text-sm leading-relaxed text-slate-600 dark:text-slate-300 ${
                isRtlScript ? 'font-nastaliq' : ''
              }`}
            >
              {milestone.poeticLine[language]}
            </p>

            <div className="mt-4 flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() => onNavigate(milestone.targetSection)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#9B1C2E] px-3.5 py-2 text-xs font-semibold text-white whitespace-nowrap transition-colors hover:bg-[#821626]"
              >
                <span>{milestone.halalActionLabel}</span>
                <ArrowUpRight className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={() => speakMultilingual(milestone.poeticLine[language], language)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-stone-300 px-3 py-2 text-xs font-medium text-slate-700 whitespace-nowrap hover:bg-stone-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <Volume2 className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
                <span>Speak Blessing</span>
              </button>
            </div>
          </div>

          <div className="mt-6 border-t border-stone-200 pt-4 dark:border-slate-800">
            <div className="mb-2 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span className="inline-flex items-center gap-1.5 font-medium">
                <Palette className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
                <span>Live Parallax Motif Resonance</span>
              </span>
              <span className="font-mono text-[11px]">Scroll Page to Feel Indus Flow</span>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {CULTURAL_MOTIFS.map((m) => {
                const selected = activeMotif === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onSelectMotif(m.id)}
                    className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 text-left transition-colors ${
                      selected
                        ? 'border-teal-700 bg-teal-50 dark:border-teal-400 dark:bg-teal-950/35'
                        : 'border-stone-200 bg-[#F8F7F3] hover:border-stone-300 dark:border-slate-800 dark:bg-[#0B1117]'
                    }`}
                  >
                    <span
                      className="h-3.5 w-3.5 shrink-0 rounded-sm"
                      style={{ backgroundColor: m.swatchHex }}
                    />
                    <div className="min-w-0">
                      <div className="truncate text-xs font-semibold text-slate-900 dark:text-slate-100">
                        {m.name}
                      </div>
                      <div className="truncate text-[10px] text-slate-500 dark:text-slate-400">
                        {m.sindhiName}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Acoustic Synthesizer + Halal Trade Blueprints */}
      <div className="grid grid-cols-1 divide-y divide-stone-200 border-t border-stone-200 lg:grid-cols-12 lg:divide-x lg:divide-y-0 dark:divide-slate-800 dark:border-slate-800">
        <div className="flex flex-col justify-between p-6 lg:col-span-5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-2 font-display text-sm font-bold text-slate-900 dark:text-white">
                <Music2 className="h-4 w-4 text-teal-700 dark:text-teal-400" />
                <span>Pure Halal Bhitai Acoustic Synth</span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Synthesized Raag Bhairavi harmonies · Zero external tracks
              </p>
            </div>
            <button
              type="button"
              onClick={onToggleSound}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                soundMuted
                  ? 'border border-stone-300 bg-[#F8F7F3] text-slate-700 hover:bg-stone-200/70 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-200'
                  : 'bg-teal-700 text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950'
              }`}
            >
              {soundMuted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
              <span>{soundMuted ? 'Play Audio' : 'Live Synth'}</span>
            </button>
          </div>

          <canvas
            ref={canvasRef}
            width={460}
            height={78}
            className="my-4 h-20 w-full rounded-xl border border-stone-200 bg-[#F8F7F3] dark:border-slate-800 dark:bg-[#0B1117]"
          />

          <div className="grid grid-cols-3 gap-2">
            {ACOUSTIC_PROFILES.map((prof) => {
              const active = instrument === prof.id;
              return (
                <button
                  key={prof.id}
                  type="button"
                  onClick={() => handleSwitchInstrument(prof.id)}
                  className={`rounded-lg border p-2 text-left transition-colors ${
                    active
                      ? 'border-teal-700 bg-teal-50 dark:border-teal-400 dark:bg-teal-950/35'
                      : 'border-stone-200 bg-[#F8F7F3] hover:border-stone-300 dark:border-slate-800 dark:bg-[#0B1117]'
                  }`}
                >
                  <div className="truncate text-xs font-semibold text-slate-900 dark:text-slate-100">
                    {prof.label}
                  </div>
                  <div className="truncate text-[10px] text-slate-500 dark:text-slate-400">
                    {prof.sub}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="p-6 lg:col-span-7">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
              Mehran Halal Ideas &amp; Action Blueprints
            </h3>
            <span className="text-[11px] font-medium text-teal-700 dark:text-teal-400">
              100% Riba-Free · Shariah Verified
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {HALAL_IDEAS_BLUEPRINTS.map((idea) => (
              <div
                key={idea.id}
                className="flex flex-col justify-between rounded-xl border border-stone-200 bg-[#F8F7F3] p-3.5 dark:border-slate-800 dark:bg-[#0B1117]"
              >
                <div>
                  <div className="text-[11px] font-medium text-[#9B1C2E] dark:text-rose-400">
                    {idea.traditionLink}
                  </div>
                  <div className="mt-0.5 text-xs font-bold text-slate-900 dark:text-slate-100">
                    {idea.title}
                  </div>
                  <p className="mt-1 text-[11px] leading-relaxed text-slate-600 dark:text-slate-400">
                    {idea.summary}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => onNavigate(idea.targetSection)}
                  className="mt-3 inline-flex items-center gap-1 self-start text-[11px] font-semibold text-teal-700 hover:underline dark:text-teal-400"
                >
                  <span>{idea.ctaLabel}</span>
                  <ArrowUpRight className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
