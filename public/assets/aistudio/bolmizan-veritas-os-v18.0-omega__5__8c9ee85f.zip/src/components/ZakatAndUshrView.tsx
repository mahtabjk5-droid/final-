import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, HelpCircle } from 'lucide-react';
import type { InventoryItem, LedgerEntry, ZakatCalculationOutput } from '../../shared/types';
import { formatCurrency } from '../utils/formatters';
import { apiFetch } from '../utils/sessionClient';

interface ZakatAndUshrViewProps {
  openReceivablesPkr: number;
  ledgerEntries: LedgerEntry[];
  inventory: InventoryItem[];
  pardaActive: boolean;
}

const APPROX_PKR_RATE: Record<string, number> = {
  PKR: 1,
  USD: 278.5,
  SAR: 74.26,
  AED: 75.82,
  EUR: 301.2,
  GBP: 353.5,
  INR: 3.31,
  BRL: 49.2,
  CNY: 38.6,
  JPY: 1.82,
  KES: 2.15,
};

function estimatePkr(entry: LedgerEntry): number {
  const rate = APPROX_PKR_RATE[entry.currency] ?? 278.5;
  return Math.round(entry.amount * rate);
}

export function ZakatAndUshrView({
  openReceivablesPkr,
  ledgerEntries,
  inventory,
  pardaActive,
}: ZakatAndUshrViewProps) {
  const defaultInventoryValuation = inventory.reduce(
    (sum, item) => sum + item.actualRemainingQty * item.unitCostPkr,
    0
  );

  const openReceivables = useMemo(
    () =>
      ledgerEntries.filter(
        (e) =>
          (e.entryType === 'udhaar_given' ||
            e.entryType === 'murabaha_contract' ||
            e.entryType === 'salam_contract') &&
          (e.status === 'open' || e.status === 'grace_15d')
      ),
    [ledgerEntries]
  );

  const [collectibleMap, setCollectibleMap] = useState<Record<string, boolean>>({});

  function isDaynQawi(entry: LedgerEntry): boolean {
    if (entry.id in collectibleMap) {
      return collectibleMap[entry.id];
    }
    return entry.status !== 'grace_15d';
  }

  function toggleDebtClassification(entry: LedgerEntry) {
    const current = isDaynQawi(entry);
    setCollectibleMap((prev) => ({ ...prev, [entry.id]: !current }));
  }

  const { daynQawiTotalPkr, daynDhaifTotalPkr } = useMemo(() => {
    if (openReceivables.length === 0) {
      return { daynQawiTotalPkr: openReceivablesPkr, daynDhaifTotalPkr: 0 };
    }
    let qawi = 0;
    let dhaif = 0;
    for (const entry of openReceivables) {
      const pkr = estimatePkr(entry);
      if (isDaynQawi(entry)) {
        qawi += pkr;
      } else {
        dhaif += pkr;
      }
    }
    return { daynQawiTotalPkr: qawi, daynDhaifTotalPkr: dhaif };
  }, [openReceivables, collectibleMap, openReceivablesPkr]);

  const [cashAndBankPkr, setCashAndBankPkr] = useState('450000');
  const [tradeInventoryPkr, setTradeInventoryPkr] = useState(String(defaultInventoryValuation));
  const [shortTermLiabilitiesPkr, setShortTermLiabilitiesPkr] = useState('85000');
  const [nisabThresholdPkr, setNisabThresholdPkr] = useState('179689');
  const [calendarType, setCalendarType] = useState<'hijri' | 'solar'>('hijri');
  const [agriculturalProducePkr, setAgriculturalProducePkr] = useState('120000');
  const [irrigationType, setIrrigationType] = useState<'irrigated' | 'rain_fed'>('irrigated');
  const [result, setResult] = useState<ZakatCalculationOutput | null>(null);

  useEffect(() => {
    void calculateNow();
  }, [
    cashAndBankPkr,
    tradeInventoryPkr,
    daynQawiTotalPkr,
    shortTermLiabilitiesPkr,
    nisabThresholdPkr,
    calendarType,
    agriculturalProducePkr,
    irrigationType,
  ]);

  async function calculateNow() {
    const res = await apiFetch('/api/zakat/calculate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        cashAndBankPkr: Number(cashAndBankPkr),
        tradeInventoryPkr: Number(tradeInventoryPkr),
        collectibleReceivablesPkr: daynQawiTotalPkr,
        shortTermLiabilitiesPkr: Number(shortTermLiabilitiesPkr),
        nisabThresholdPkr: Number(nisabThresholdPkr),
        calendarType,
        agriculturalProducePkr: Number(agriculturalProducePkr),
        irrigationType,
      }),
    });
    if (res.ok) {
      setResult((await res.json()) as ZakatCalculationOutput);
    }
  }

  const blur = pardaActive ? 'parda-blur' : '';
  const fieldCls =
    'mt-1 w-full rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 font-mono text-sm text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100 dark:focus:border-teal-400';

  return (
    <div className="space-y-6 veritas-enter">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="space-y-4 rounded-xl border border-stone-200 bg-white p-6 lg:col-span-7 dark:border-slate-800 dark:bg-[#111922]">
          <div>
            <h2 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
              AAOIFI Standard 35 Zakat &amp; Ushr Engine
            </h2>
            <p className="mt-0.5 text-xs text-stone-500 dark:text-stone-400">
              Live trade inventory, Hijri (2.5%) / Solar (2.577%) Zakat, Ushr (5%/10%), and Dayn Qawi vs. Dayn Dha&apos;if receivable filtering
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Cash &amp; Bank Balances (PKR)
              </label>
              <input
                type="number"
                value={cashAndBankPkr}
                onChange={(e) => setCashAndBankPkr(e.target.value)}
                className={fieldCls}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Trade Inventory Valuation (PKR)
              </label>
              <input
                type="number"
                value={tradeInventoryPkr}
                onChange={(e) => setTradeInventoryPkr(e.target.value)}
                className={fieldCls}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Included Dayn Qawi Receivables (PKR)
              </label>
              <div className="mt-1 rounded-xl border border-teal-600/30 bg-teal-700/8 px-3 py-2 font-mono text-sm font-semibold text-teal-800 dark:bg-teal-500/15 dark:text-teal-300">
                {formatCurrency(daynQawiTotalPkr, 'PKR')}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Short-Term Deductible Liabilities (PKR)
              </label>
              <input
                type="number"
                value={shortTermLiabilitiesPkr}
                onChange={(e) => setShortTermLiabilitiesPkr(e.target.value)}
                className={fieldCls}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Nisab Threshold (Silver/Gold PKR)
              </label>
              <input
                type="number"
                value={nisabThresholdPkr}
                onChange={(e) => setNisabThresholdPkr(e.target.value)}
                className={fieldCls}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Zakat Year Standard
              </label>
              <select
                value={calendarType}
                onChange={(e) => setCalendarType(e.target.value as 'hijri' | 'solar')}
                className="mt-1 w-full rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 text-sm text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
              >
                <option value="hijri">Hijri Lunar Year (2.5%)</option>
                <option value="solar">Solar Gregorian Year (2.577%)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Agricultural Produce Harvest (PKR)
              </label>
              <input
                type="number"
                value={agriculturalProducePkr}
                onChange={(e) => setAgriculturalProducePkr(e.target.value)}
                className={fieldCls}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Ushr Irrigation Type
              </label>
              <select
                value={irrigationType}
                onChange={(e) => setIrrigationType(e.target.value as 'irrigated' | 'rain_fed')}
                className="mt-1 w-full rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 text-sm text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
              >
                <option value="irrigated">Artificially Irrigated (5% Ushr)</option>
                <option value="rain_fed">Rain-Fed / Barani (10% Ushr)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Output Summary */}
        <div className="rounded-xl border border-stone-200 bg-white p-6 lg:col-span-5 dark:border-slate-800 dark:bg-[#111922]">
          <h3 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
            Computed Shariah Obligation Summary
          </h3>
          {result && (
            <div className="mt-5 space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-stone-500 dark:text-stone-400">Dayn Qawi Included</span>
                <span className={`font-mono font-semibold text-teal-700 tabular-nums dark:text-teal-400 ${blur}`}>
                  {formatCurrency(daynQawiTotalPkr, 'PKR')}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500 dark:text-stone-400">Excluded Dayn Dha&apos;if (Doubtful)</span>
                <span className={`font-mono font-semibold text-[#9B1C2E] tabular-nums dark:text-rose-400 ${blur}`}>
                  {formatCurrency(daynDhaifTotalPkr, 'PKR')}
                </span>
              </div>
              <div className="flex justify-between border-t border-stone-200 pt-3 dark:border-slate-800">
                <span className="text-stone-500 dark:text-stone-400">Net Zakatable Wealth</span>
                <span className={`font-mono font-semibold tabular-nums ${blur}`}>
                  {formatCurrency(result.netZakatableAssetsPkr, 'PKR')}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500 dark:text-stone-400">Nisab Threshold Met</span>
                <span className="font-semibold text-teal-700 dark:text-teal-400">
                  {result.nisabMet ? 'Yes (Obligatory)' : 'Below Nisab'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500 dark:text-stone-400">
                  Zakat Due ({result.zakatRatePct}%)
                </span>
                <span className={`font-mono font-semibold tabular-nums ${blur}`}>
                  {formatCurrency(result.zakatDuePkr, 'PKR')}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500 dark:text-stone-400">
                  Ushr Due ({result.ushrRatePct}%)
                </span>
                <span className={`font-mono font-semibold tabular-nums ${blur}`}>
                  {formatCurrency(result.ushrDuePkr, 'PKR')}
                </span>
              </div>
              <div className="flex justify-between border-t border-stone-200 pt-4 dark:border-slate-800">
                <span className="font-semibold text-stone-900 dark:text-stone-100">
                  Total Zakat + Ushr Payable
                </span>
                <span className={`font-mono text-xl font-bold text-teal-700 tabular-nums dark:text-teal-300 ${blur}`}>
                  {formatCurrency(result.totalObligationPkr, 'PKR')}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Per-Receivable Dayn Qawi vs. Dayn Dha'if Toggle List */}
      <section className="rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
              Receivables Classification: Dayn Qawi (Collectible) vs. Dayn Dha&apos;if (Doubtful / Overdue)
            </h3>
            <p className="mt-0.5 text-xs text-stone-500 dark:text-stone-400">
              Per AAOIFI Standard 35, toggle doubtful or overdue debts to Dayn Dha&apos;if to exclude them from Zakatable wealth until actually collected.
            </p>
          </div>
          <span className="font-mono text-xs text-stone-500 dark:text-stone-400">
            {openReceivables.length} Open Receivables
          </span>
        </div>

        <div className="mt-4 divide-y divide-stone-200 dark:divide-slate-800">
          {openReceivables.length === 0 ? (
            <div className="py-4 text-xs text-stone-500 dark:text-stone-400">
              No open ledger receivables found.
            </div>
          ) : (
            openReceivables.map((entry) => {
              const qawi = isDaynQawi(entry);
              const pkrEq = estimatePkr(entry);
              return (
                <div
                  key={entry.id}
                  className="flex flex-wrap items-center justify-between gap-3 py-3 text-xs"
                >
                  <div>
                    <div className="font-semibold text-stone-900 dark:text-stone-100">
                      {entry.debtorName}{' '}
                      <span className="font-mono text-[11px] font-normal text-stone-500">
                        ({entry.reference})
                      </span>
                    </div>
                    <div className="mt-0.5 text-stone-500 dark:text-stone-400">
                      {entry.itemsSummary} · {formatCurrency(entry.amount, entry.currency)} (≈{' '}
                      {formatCurrency(pkrEq, 'PKR')})
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => toggleDebtClassification(entry)}
                    className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 font-semibold transition-colors ${
                      qawi
                        ? 'border-teal-600/35 bg-teal-700/10 text-teal-800 hover:bg-teal-700/15 dark:text-teal-300'
                        : 'border-[#9B1C2E]/35 bg-[#9B1C2E]/10 text-[#9B1C2E] hover:bg-[#9B1C2E]/15 dark:text-rose-300'
                    }`}
                  >
                    {qawi ? (
                      <>
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>Dayn Qawi (Collectible · Included)</span>
                      </>
                    ) : (
                      <>
                        <HelpCircle className="h-3.5 w-3.5" />
                        <span>Dayn Dha&apos;if (Doubtful · Excluded)</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })
          )}
        </div>
      </section>
    </div>
  );
}
