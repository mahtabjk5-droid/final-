import { useEffect, useMemo, useRef, useState } from 'react';
import { Activity } from 'lucide-react';
import type {
  BranchId,
  FxRateSnapshot,
  LedgerEntry,
  PaymentTransaction,
} from '../../shared/types';
import { formatCurrency } from '../utils/formatters';

interface LedgerVelocityChartProps {
  ledgerEntries: LedgerEntry[];
  transactions: PaymentTransaction[];
  fx: FxRateSnapshot;
  branchFilter: BranchId;
  pardaActive: boolean;
}

type VelocityViewMode = 'combined' | 'settled_vs_credit' | 'cadence';

interface VelocityBucket {
  id: string;
  label: string;
  timestampMs: number;
  settledUsd: number;
  creditUsd: number;
  totalUsd: number;
  eventCount: number;
  avgHumanScore: number;
  hashSnippet: string;
}

function buildSmoothSvgPath(pts: Array<{ x: number; y: number }>): string {
  if (pts.length === 0) return '';
  if (pts.length === 1) return `M ${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)}`;
  let d = `M ${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i];
    const p1 = pts[i + 1];
    const cx = ((p0.x + p1.x) / 2).toFixed(1);
    d += ` C ${cx} ${p0.y.toFixed(1)}, ${cx} ${p1.y.toFixed(1)}, ${p1.x.toFixed(1)} ${p1.y.toFixed(1)}`;
  }
  return d;
}

export function RealTimeLedgerVelocityChart({
  ledgerEntries,
  transactions,
  fx,
  branchFilter,
  pardaActive,
}: LedgerVelocityChartProps) {
  const [mode, setMode] = useState<VelocityViewMode>('combined');
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const [nowMs, setNowMs] = useState(() => Date.now());
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const id = window.setInterval(() => setNowMs(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const analytics = useMemo(() => {
    const sortedLedger = [...ledgerEntries].sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );
    const validTxs = transactions
      .filter((t) => t.status !== 'declined' && t.status !== 'refunded')
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    const combinedEvents: Array<{
      id: string;
      ts: number;
      label: string;
      settledUsd: number;
      creditUsd: number;
      humanScore: number;
      hashSnippet: string;
    }> = [];

    for (const entry of sortedLedger) {
      const ts = new Date(entry.createdAt).getTime();
      const isSettledFlow =
        entry.status === 'settled' ||
        entry.entryType === 'cash_sale' ||
        entry.entryType === 'payment_received' ||
        entry.entryType === 'mukasa_settlement';
      combinedEvents.push({
        id: entry.id,
        ts: Number.isFinite(ts) ? ts : nowMs,
        label: entry.reference,
        settledUsd: isSettledFlow ? entry.usdAmount : 0,
        creditUsd: isSettledFlow ? 0 : entry.usdAmount,
        humanScore: entry.cognitiveHumanScore,
        hashSnippet: entry.hash.slice(0, 8),
      });
    }

    for (const tx of validTxs) {
      const ts = new Date(tx.createdAt).getTime();
      combinedEvents.push({
        id: tx.id,
        ts: Number.isFinite(ts) ? ts : nowMs,
        label: tx.reference,
        settledUsd: tx.usdAmount,
        creditUsd: 0,
        humanScore: 99,
        hashSnippet: tx.gatewayIntentId.slice(-8),
      });
    }

    combinedEvents.sort((a, b) => a.ts - b.ts);

    const buckets: VelocityBucket[] = [];
    const totalEvents = combinedEvents.length;
    if (totalEvents > 0) {
      const targetBuckets = Math.min(10, Math.max(4, totalEvents));
      const chunkSize = Math.max(1, Math.ceil(totalEvents / targetBuckets));

      for (let i = 0; i < totalEvents; i += chunkSize) {
        const slice = combinedEvents.slice(i, i + chunkSize);
        const settledUsd = Number(slice.reduce((s, e) => s + e.settledUsd, 0).toFixed(2));
        const creditUsd = Number(slice.reduce((s, e) => s + e.creditUsd, 0).toFixed(2));
        const avgHumanScore = Math.round(
          slice.reduce((s, e) => s + e.humanScore, 0) / slice.length
        );
        const last = slice[slice.length - 1];
        const dt = new Date(last.ts);
        const hhmm = Number.isNaN(dt.getTime())
          ? last.label.slice(-6)
          : `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;

        buckets.push({
          id: `${last.id}_${i}`,
          label: slice.length === 1 ? last.label : hhmm,
          timestampMs: last.ts,
          settledUsd,
          creditUsd,
          totalUsd: Number((settledUsd + creditUsd).toFixed(2)),
          eventCount: slice.length,
          avgHumanScore,
          hashSnippet: last.hashSnippet,
        });
      }
    }

    const totalSettledUsd = combinedEvents.reduce((s, e) => s + e.settledUsd, 0);
    const totalCreditUsd = combinedEvents.reduce((s, e) => s + e.creditUsd, 0);
    const totalLedgerUsd = totalSettledUsd + totalCreditUsd;

    const firstTs = combinedEvents[0]?.ts ?? nowMs - 3_600_000;
    const spanHours = Math.max(0.25, (nowMs - firstTs) / 3_600_000);
    const throughputUsdPerHour = Number((totalLedgerUsd / spanHours).toFixed(2));
    const entriesPerHour = Number((combinedEvents.length / spanHours).toFixed(1));

    const latestTs = combinedEvents[combinedEvents.length - 1]?.ts ?? nowMs;
    const secondsSinceLastSeal = Math.max(0, Math.round((nowMs - latestTs) / 1000));

    const velocityEnergy = Math.min(
      2.6,
      Math.max(0.45, Math.log10(Math.max(10, throughputUsdPerHour)) * 0.42 + combinedEvents.length * 0.04)
    );

    return {
      buckets,
      totalSettledUsd,
      totalCreditUsd,
      totalLedgerUsd,
      throughputUsdPerHour,
      entriesPerHour,
      secondsSinceLastSeal,
      velocityEnergy,
      totalCount: combinedEvents.length,
    };
  }, [ledgerEntries, transactions, nowMs]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let frameId = 0;
    let phase = 0;

    const particles = Array.from({ length: 24 }, (_, idx) => ({
      x: (idx / 24) * 760,
      speed: 0.65 + (idx % 5) * 0.25,
      amp: 5 + (idx % 4) * 3,
      phaseOffset: idx * 0.65,
      gold: idx % 3 === 0,
    }));

    const render = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      const w = Math.max(280, Math.floor(rect.width || 680));
      const h = 44;

      if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
        canvas.width = w * dpr;
        canvas.height = h * dpr;
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, w, h);

      const energy = analytics.velocityEnergy;
      const midY = h / 2;

      ctx.beginPath();
      for (let x = 0; x <= w; x += 6) {
        const y =
          midY +
          Math.sin(x * 0.018 + phase) * (5 * energy) +
          Math.cos(x * 0.041 - phase * 1.4) * (2.5 * energy);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.72)';
      ctx.lineWidth = 1.6;
      ctx.stroke();

      ctx.beginPath();
      for (let x = 0; x <= w; x += 6) {
        const y =
          midY +
          Math.sin(x * 0.023 - phase * 0.85 + 1.2) * (4 * energy);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.55)';
      ctx.lineWidth = 1.2;
      ctx.stroke();

      for (const p of particles) {
        if (!reduceMotion) {
          p.x = (p.x + p.speed * energy * 1.25) % w;
        }
        const px = p.x % w;
        const py = midY + Math.sin(px * 0.02 + phase + p.phaseOffset) * (p.amp * Math.min(1.5, energy));
        ctx.beginPath();
        ctx.arc(px, py, p.gold ? 2 : 1.7, 0, Math.PI * 2);
        ctx.fillStyle = p.gold ? 'rgba(251, 191, 36, 0.9)' : 'rgba(52, 211, 153, 0.9)';
        ctx.fill();
      }

      ctx.restore();

      if (!reduceMotion) {
        phase += 0.042 * energy;
        frameId = window.requestAnimationFrame(render);
      }
    };

    render();
    return () => {
      if (frameId) window.cancelAnimationFrame(frameId);
    };
  }, [analytics.velocityEnergy]);

  const svgChart = useMemo(() => {
    const width = 760;
    const height = 235;
    const padLeft = 58;
    const padRight = 18;
    const padTop = 20;
    const padBottom = 30;
    const plotW = width - padLeft - padRight;
    const plotH = height - padTop - padBottom;

    const maxMetric = Math.max(
      25,
      ...analytics.buckets.map((b) =>
        mode === 'cadence'
          ? b.eventCount * 10
          : mode === 'settled_vs_credit'
            ? Math.max(b.settledUsd, b.creditUsd)
            : b.totalUsd
      )
    ) * 1.15;

    const nodes = analytics.buckets.map((b, idx) => {
      const x =
        analytics.buckets.length <= 1
          ? padLeft + plotW / 2
          : padLeft + (idx / (analytics.buckets.length - 1)) * plotW;

      const primaryVal = mode === 'cadence' ? b.eventCount * 10 : mode === 'settled_vs_credit' ? b.settledUsd : b.totalUsd;
      const secondaryVal = mode === 'cadence' ? b.avgHumanScore : b.creditUsd;

      const yPrimary = padTop + plotH - (primaryVal / maxMetric) * plotH;
      const ySecondary =
        mode === 'cadence'
          ? padTop + plotH - (secondaryVal / 100) * plotH
          : padTop + plotH - (secondaryVal / maxMetric) * plotH;

      return {
        x,
        yPrimary,
        ySecondary,
        barHeightPrimary: Math.max(3, (primaryVal / maxMetric) * plotH),
        barHeightSecondary:
          mode === 'cadence'
            ? Math.max(3, (b.eventCount * 10 / maxMetric) * plotH)
            : Math.max(2, (b.creditUsd / maxMetric) * plotH),
        bucket: b,
      };
    });

    const primaryPath = buildSmoothSvgPath(nodes.map((n) => ({ x: n.x, y: n.yPrimary })));
    const secondaryPath = buildSmoothSvgPath(nodes.map((n) => ({ x: n.x, y: n.ySecondary })));
    const areaPath =
      nodes.length > 0
        ? `${primaryPath} L ${nodes[nodes.length - 1].x.toFixed(1)} ${(padTop + plotH).toFixed(1)} L ${nodes[0].x.toFixed(1)} ${(padTop + plotH).toFixed(1)} Z`
        : '';

    const yTicks = [0, 0.33, 0.66, 1].map((ratio) => ({
      y: padTop + plotH - ratio * plotH,
      value: maxMetric * ratio,
    }));

    return { width, height, padLeft, padRight, padTop, padBottom, plotH, nodes, primaryPath, secondaryPath, areaPath, yTicks };
  }, [analytics.buckets, mode]);

  const activeNode =
    hoverIdx !== null && svgChart.nodes[hoverIdx]
      ? svgChart.nodes[hoverIdx]
      : svgChart.nodes[svgChart.nodes.length - 1];

  const pkrRate = fx.rates.PKR || 278.5;
  const maskClass = pardaActive ? 'parda-blur' : '';

  return (
    <div className="rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4 text-teal-700 dark:text-teal-400" />
            <h2 className="font-editorial text-xl font-bold text-slate-900 dark:text-white">
              Real-Time Ledger Velocity Engine
            </h2>
          </div>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            Live throughput ({branchFilter === 'all' ? 'All 4 Hubs' : branchFilter}):{' '}
            <span className={`font-mono font-semibold text-teal-700 dark:text-teal-400 ${maskClass}`}>
              {formatCurrency(analytics.throughputUsdPerHour, 'USD')}/hr
            </span>{' '}
            · {analytics.entriesPerHour} blocks/hr · Last seal {analytics.secondsSinceLastSeal}s ago
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {activeNode && (
            <div className="text-right">
              <div className={`font-mono text-sm font-bold text-slate-900 tabular-nums dark:text-teal-300 ${maskClass}`}>
                {mode === 'cadence'
                  ? `${activeNode.bucket.eventCount} blocks · ${activeNode.bucket.avgHumanScore}% human cadence`
                  : formatCurrency(activeNode.bucket.totalUsd, 'USD')}
              </div>
              <div className="font-mono text-[11px] text-slate-500 tabular-nums dark:text-slate-400">
                {activeNode.bucket.label} · #{activeNode.bucket.hashSnippet} ·{' '}
                <span className={maskClass}>
                  {formatCurrency(Math.round(activeNode.bucket.totalUsd * pkrRate), 'PKR')}
                </span>
              </div>
            </div>
          )}

          <div className="flex items-center rounded-lg border border-stone-200 bg-[#F8F7F3] p-0.5 dark:border-slate-800 dark:bg-[#0B1117]">
            {(
              [
                { id: 'combined', label: 'Net Velocity' },
                { id: 'settled_vs_credit', label: 'Settled vs Udhaar' },
                { id: 'cadence', label: 'Seal Cadence' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setMode(tab.id)}
                className={`rounded-md px-2.5 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                  mode === tab.id
                    ? 'bg-teal-700 text-white dark:bg-teal-500 dark:text-slate-950'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Browser-Native HTML5 Canvas Oscilloscope */}
      <div className="mt-4 overflow-hidden rounded-xl border border-stone-200 bg-[#0D2327] px-3.5 py-2.5 dark:border-slate-800">
        <div className="mb-0.5 flex items-center justify-between font-mono text-[10px] text-teal-200/80">
          <span>CANVAS TELEMETRY STREAM · VELOCITY INDEX {analytics.velocityEnergy.toFixed(2)}x</span>
          <span className={maskClass}>
            SETTLED {formatCurrency(analytics.totalSettledUsd, 'USD')} · UDHAAR {formatCurrency(analytics.totalCreditUsd, 'USD')}
          </span>
        </div>
        <canvas ref={canvasRef} className="block h-11 w-full" aria-label="Real-time canvas ledger velocity stream" />
      </div>

      {/* Dynamic SVG Chart */}
      <div className="relative mt-3 w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${svgChart.width} ${svgChart.height}`}
          className="h-56 w-full select-none"
          role="img"
          aria-label="Real-time ledger velocity SVG chart"
        >
          <defs>
            <linearGradient id="veritasVelocityFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10B981" stopOpacity="0.32" />
              <stop offset="100%" stopColor="#10B981" stopOpacity="0.01" />
            </linearGradient>
          </defs>

          {svgChart.yTicks.map((tick, idx) => (
            <g key={idx}>
              <line
                x1={svgChart.padLeft}
                x2={svgChart.width - svgChart.padRight}
                y1={tick.y}
                y2={tick.y}
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeDasharray="3 3"
              />
              <text
                x={svgChart.padLeft - 8}
                y={tick.y + 4}
                textAnchor="end"
                className="fill-slate-400 font-mono text-[10px] dark:fill-slate-500"
              >
                {mode === 'cadence'
                  ? `${Math.round(tick.value / 10)} tx`
                  : `$${Math.round(tick.value).toLocaleString()}`}
              </text>
            </g>
          ))}

          {svgChart.nodes.map((node, idx) => (
            <rect
              key={`bar_${node.bucket.id}`}
              x={node.x - 8}
              y={svgChart.padTop + svgChart.plotH - node.barHeightSecondary}
              width="16"
              height={node.barHeightSecondary}
              rx="3"
              fill="#F59E0B"
              fillOpacity={mode === 'combined' ? 0.25 : 0.45}
              className="velocity-bar-rise"
              style={{ animationDelay: `${idx * 30}ms` }}
            />
          ))}

          {svgChart.areaPath && <path d={svgChart.areaPath} fill="url(#veritasVelocityFill)" />}

          {svgChart.primaryPath && (
            <path
              key={`primary_${mode}_${analytics.totalCount}`}
              d={svgChart.primaryPath}
              fill="none"
              stroke="#10B981"
              strokeWidth="2.5"
              strokeLinecap="round"
              className="velocity-line-draw"
            />
          )}

          {mode !== 'combined' && svgChart.secondaryPath && (
            <path
              key={`sec_${mode}_${analytics.totalCount}`}
              d={svgChart.secondaryPath}
              fill="none"
              stroke="#F59E0B"
              strokeWidth="1.8"
              strokeDasharray="5 4"
              strokeLinecap="round"
            />
          )}

          {svgChart.nodes.map((node, idx) => {
            const active =
              hoverIdx === idx || (hoverIdx === null && idx === svgChart.nodes.length - 1);
            return (
              <g key={node.bucket.id}>
                {active && (
                  <line
                    x1={node.x}
                    x2={node.x}
                    y1={svgChart.padTop}
                    y2={svgChart.height - svgChart.padBottom}
                    stroke="#10B981"
                    strokeOpacity="0.4"
                    strokeDasharray="2 2"
                  />
                )}
                <circle
                  cx={node.x}
                  cy={node.yPrimary}
                  r={active ? 5 : 3}
                  className={
                    active
                      ? 'fill-emerald-500 stroke-white stroke-2 dark:fill-emerald-400 dark:stroke-slate-950'
                      : 'fill-emerald-600/85 dark:fill-emerald-400/85'
                  }
                />
                <rect
                  x={node.x - 24}
                  y={8}
                  width="48"
                  height={svgChart.height - 16}
                  fill="transparent"
                  className="cursor-crosshair"
                  onMouseEnter={() => setHoverIdx(idx)}
                  onMouseLeave={() => setHoverIdx(null)}
                />
                {(idx % 2 === 0 || svgChart.nodes.length <= 6) && (
                  <text
                    x={node.x}
                    y={svgChart.height - 8}
                    textAnchor="middle"
                    className="fill-slate-400 font-mono text-[10px] dark:fill-slate-500"
                  >
                    {node.bucket.label}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}

interface AmanatRadialGaugeProps {
  score: number;
  ledgerEntries: LedgerEntry[];
}

export function AmanatRadialGaugeSvg({ score, ledgerEntries }: AmanatRadialGaugeProps) {
  const pct = Math.max(0, Math.min(1, score / 1000));
  const radius = 44;
  const circumference = 2 * Math.PI * radius;
  const arcSpan = circumference * (240 / 360);
  const filledArc = arcSpan * pct;

  const recentBars = useMemo(() => {
    const recent = ledgerEntries.slice(0, 7).reverse();
    const maxUsd = Math.max(10, ...recent.map((e) => e.usdAmount));
    return recent.map((entry) => ({
      id: entry.id,
      ref: entry.reference,
      heightPct: Math.max(18, Math.round((entry.usdAmount / maxUsd) * 100)),
      settled: entry.status === 'settled' || entry.entryType === 'cash_sale' || entry.entryType === 'payment_received',
    }));
  }, [ledgerEntries]);

  return (
    <div className="grid grid-cols-1 items-center gap-4 sm:grid-cols-2">
      <div className="flex items-center justify-center">
        <svg viewBox="0 0 120 100" className="h-28 w-36" role="img" aria-label={`Amanat score ${score} of 1000`}>
          <defs>
            <linearGradient id="amanatArcGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>
          </defs>
          <circle
            cx="60"
            cy="58"
            r={radius}
            fill="none"
            stroke="currentColor"
            className="text-slate-200 dark:text-slate-800"
            strokeWidth="9"
            strokeLinecap="round"
            strokeDasharray={`${arcSpan} ${circumference}`}
            transform="rotate(150 60 58)"
          />
          <circle
            cx="60"
            cy="58"
            r={radius}
            fill="none"
            stroke="url(#amanatArcGrad)"
            strokeWidth="9"
            strokeLinecap="round"
            strokeDasharray={`${filledArc} ${circumference}`}
            transform="rotate(150 60 58)"
            style={{ transition: 'stroke-dasharray 650ms cubic-bezier(0.16, 1, 0.3, 1)' }}
          />
          <text
            x="60"
            y="57"
            textAnchor="middle"
            className="fill-slate-900 font-mono text-[20px] font-bold dark:fill-white"
          >
            {score}
          </text>
          <text
            x="60"
            y="72"
            textAnchor="middle"
            className="fill-slate-400 font-mono text-[8px]"
          >
            / 1000 AMANAT
          </text>
        </svg>
      </div>

      <div>
        <div className="mb-1.5 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span>Recent DAG Seal Velocity</span>
          <span className="font-mono text-emerald-600 dark:text-emerald-400">
            {recentBars.length} blocks
          </span>
        </div>
        <svg viewBox="0 0 140 52" className="h-14 w-full" role="img" aria-label="Recent ledger seal velocity">
          {recentBars.map((bar, idx) => {
            const barW = 14;
            const gap = 6;
            const x = 4 + idx * (barW + gap);
            const h = Math.max(6, (bar.heightPct / 100) * 40);
            const y = 46 - h;
            return (
              <g key={bar.id}>
                <rect
                  x={x}
                  y={y}
                  width={barW}
                  height={h}
                  rx="3"
                  fill={bar.settled ? '#10B981' : '#F59E0B'}
                  className="velocity-bar-rise"
                  style={{ animationDelay: `${idx * 40}ms` }}
                />
                <title>{bar.ref}</title>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}

interface CorridorSegment {
  label: string;
  val: number;
  pct: number;
  stroke: string;
}

export function CorridorVelocityDonutSvg({
  segments,
  pardaActive,
}: {
  segments: CorridorSegment[];
  pardaActive: boolean;
}) {
  const [hoveredLabel, setHoveredLabel] = useState<string | null>(null);
  const totalUsd = segments.reduce((s, seg) => s + seg.val, 0);
  const activeSeg = segments.find((s) => s.label === hoveredLabel) ?? segments[0];

  const radius = 36;
  const circumference = 2 * Math.PI * radius;
  let offset = 0;

  return (
    <div className="mt-4 flex flex-col items-center gap-4 sm:flex-row">
      <svg viewBox="0 0 100 100" className="h-28 w-28 shrink-0" role="img" aria-label="Corridor share donut chart">
        <circle
          cx="50"
          cy="50"
          r={radius}
          fill="none"
          stroke="currentColor"
          className="text-slate-100 dark:text-slate-800"
          strokeWidth="12"
        />
        {segments.map((seg) => {
          const segLen = Math.max(0, (seg.pct / 100) * circumference);
          const dashArray = `${segLen} ${circumference}`;
          const dashOffset = -offset;
          offset += segLen;
          const isHovered = hoveredLabel === seg.label;
          return (
            <circle
              key={seg.label}
              cx="50"
              cy="50"
              r={radius}
              fill="none"
              stroke={seg.stroke}
              strokeWidth={isHovered ? 15 : 12}
              strokeDasharray={dashArray}
              strokeDashoffset={dashOffset}
              transform="rotate(-90 50 50)"
              className="cursor-pointer transition-all duration-300"
              onMouseEnter={() => setHoveredLabel(seg.label)}
              onMouseLeave={() => setHoveredLabel(null)}
            />
          );
        })}
        <text
          x="50"
          y="48"
          textAnchor="middle"
          className="fill-slate-900 font-mono text-[13px] font-bold dark:fill-white"
        >
          {activeSeg ? `${activeSeg.pct}%` : '100%'}
        </text>
        <text
          x="50"
          y="60"
          textAnchor="middle"
          className={`fill-slate-500 font-mono text-[7px] dark:fill-slate-400 ${pardaActive ? 'parda-blur' : ''}`}
        >
          {activeSeg ? `$${Math.round(activeSeg.val).toLocaleString()}` : `$${Math.round(totalUsd).toLocaleString()}`}
        </text>
      </svg>

      <div className="grid w-full grid-cols-1 gap-2 text-xs sm:grid-cols-2">
        {segments.map((seg) => (
          <button
            key={seg.label}
            type="button"
            onMouseEnter={() => setHoveredLabel(seg.label)}
            onMouseLeave={() => setHoveredLabel(null)}
            className={`flex items-center justify-between rounded-xl px-2.5 py-1.5 text-left transition-colors ${
              hoveredLabel === seg.label
                ? 'bg-teal-700/12 text-teal-800 dark:bg-teal-500/15 dark:text-teal-300'
                : 'bg-[#F8F7F3] dark:bg-[#0B1117]'
            }`}
          >
            <span className="flex items-center gap-1.5 truncate text-stone-700 dark:text-stone-300">
              <span className="h-2 w-2 shrink-0 rounded-xs" style={{ backgroundColor: seg.stroke }} />
              <span className="truncate">{seg.label}</span>
            </span>
            <span className="font-mono font-semibold text-stone-900 tabular-nums dark:text-white">
              {seg.pct}%
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
