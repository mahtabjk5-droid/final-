import { useMemo, useState } from 'react';
import { CheckCircle2, Sparkles, Users } from 'lucide-react';
import type { LedgerEntry, PaymentTransaction } from '../../shared/types';
import { formatCurrency } from '../utils/formatters';
import { apiFetch } from '../utils/sessionClient';
import { sufiSoundscape } from '../utils/sufiSoundscape';

interface RilliQuiltProps {
  ledgerEntries: LedgerEntry[];
  transactions: PaymentTransaction[];
  pardaActive: boolean;
}

interface RilliTile {
  id: string;
  title: string;
  amountLabel: string;
  channel: string;
  tone: 'crimson' | 'emerald' | 'gold' | 'indigo';
  intensity: number;
}

export function SindhiRilliQuiltWidget({
  ledgerEntries,
  transactions,
  pardaActive,
}: RilliQuiltProps) {
  const tiles = useMemo<RilliTile[]>(() => {
    const out: RilliTile[] = [];
    for (const tx of transactions.slice(0, 12)) {
      const tone: RilliTile['tone'] =
        tx.status === 'settled'
          ? tx.currency === 'PKR'
            ? 'emerald'
            : 'gold'
          : tx.status === 'refunded'
            ? 'crimson'
            : 'indigo';
      out.push({
        id: tx.id,
        title: `${tx.reference} · ${tx.customerName}`,
        amountLabel: formatCurrency(tx.amount, tx.currency),
        channel: `${tx.railName} · ${tx.customerCountry}`,
        tone,
        intensity: Math.min(1, Math.max(0.35, tx.usdAmount / 2500)),
      });
    }
    for (const entry of ledgerEntries.slice(0, 12)) {
      const tone: RilliTile['tone'] =
        entry.status === 'settled' || entry.status === 'sadqah_forgiven'
          ? 'emerald'
          : entry.status === 'grace_15d'
            ? 'gold'
            : 'crimson';
      out.push({
        id: entry.id,
        title: `#${entry.index} ${entry.reference} · ${entry.debtorName}`,
        amountLabel: formatCurrency(entry.amount, entry.currency),
        channel: `${entry.entryType.replace('_', ' ')} · ${entry.branchId}`,
        tone,
        intensity: Math.min(1, Math.max(0.4, entry.usdAmount / 1500)),
      });
    }
    return out.slice(0, 21);
  }, [ledgerEntries, transactions]);

  const [selectedTileId, setSelectedTileId] = useState<string | null>(
    () => tiles[0]?.id ?? null
  );
  const selected = tiles.find((t) => t.id === selectedTileId) ?? tiles[0] ?? null;

  const toneClasses: Record<RilliTile['tone'], string> = {
    crimson: 'border-rose-500/45 bg-[#9F1239]/80 text-rose-100',
    emerald: 'border-emerald-400/45 bg-emerald-900/75 text-emerald-100',
    gold: 'border-amber-400/55 bg-amber-700/75 text-amber-50',
    indigo: 'border-indigo-400/45 bg-[#1E1B4B]/85 text-indigo-100',
  };

  return (
    <div className="flex h-full flex-col justify-between rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <h3 className="font-editorial text-xl font-bold text-slate-900 dark:text-white">
            Sindhi Rilli Patchwork Tapestry
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Select any geometric inlay to inspect live blocks &amp; settlements
          </p>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
          <span>Settled</span>
          <span aria-hidden="true">·</span>
          <span>Grace / FX</span>
          <span aria-hidden="true">·</span>
          <span>Open Udhaar</span>
        </div>
      </div>

      <div className="my-5 grid grid-cols-7 gap-2 rounded-xl border border-stone-200 bg-[#0D2327] p-3.5 dark:border-slate-800">
        {tiles.map((tile) => {
          const isSelected = selected?.id === tile.id;
          return (
            <button
              key={tile.id}
              type="button"
              onClick={() => setSelectedTileId(tile.id)}
              title={`${tile.title} (${tile.amountLabel})`}
              className={`flex aspect-square items-center justify-center rounded-md border transition-transform hover:scale-105 ${
                toneClasses[tile.tone]
              } ${isSelected ? 'ring-2 ring-teal-300 ring-offset-1 ring-offset-[#0D2327]' : ''}`}
              style={{ opacity: 0.65 + tile.intensity * 0.35 }}
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5 opacity-90">
                <polygon
                  points="12,2 22,12 12,22 2,12"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                />
                <circle cx="12" cy="12" r="2.2" fill="currentColor" />
              </svg>
            </button>
          );
        })}
      </div>

      {selected && (
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-stone-200 pt-3.5 text-xs dark:border-slate-800">
          <div className="min-w-0">
            <div className="truncate font-semibold text-slate-900 dark:text-slate-100">
              {selected.title}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              {selected.channel}
            </div>
          </div>
          <div
            className={`font-mono text-sm font-bold text-teal-700 tabular-nums dark:text-teal-400 ${
              pardaActive ? 'parda-blur' : ''
            }`}
          >
            {selected.amountLabel}
          </div>
        </div>
      )}
    </div>
  );
}

interface OtaqMajlisProps {
  ledgerEntries: LedgerEntry[];
  amanatScore: number;
  witnessCount: number;
  onWitnessAdded?: () => Promise<void>;
}

export function OtaqMajlisWidget({
  ledgerEntries,
  amanatScore,
  witnessCount,
  onWitnessAdded,
}: OtaqMajlisProps) {
  const [selectedEntryId, setSelectedEntryId] = useState<string>(
    () => ledgerEntries[0]?.id ?? ''
  );
  const [witnessName, setWitnessName] = useState('Sardar Ali Nawaz Jamali');
  const [witnessRole, setWitnessRole] = useState('Sakrand Bazaar Otaq Witness');
  const [otaqLocation, setOtaqLocation] = useState('Sakrand Main Otaq, Sindh');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const activeEntry =
    ledgerEntries.find((e) => e.id === selectedEntryId) ?? ledgerEntries[0] ?? null;

  async function handleAddWitness(e: React.FormEvent) {
    e.preventDefault();
    if (!activeEntry) return;
    setBusy(true);
    setNotice(null);
    try {
      const res = await apiFetch(`/api/ledger/${activeEntry.id}/witness`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          witnessName,
          witnessRole,
          otaqLocation,
        }),
      });
      if (!res.ok) {
        const err = (await res.json()) as { error?: string };
        setNotice(err.error || 'Unable to append Otaq witness.');
        return;
      }
      sufiSoundscape.playSealChime();
      setNotice(`Shahadah witness recorded on ${activeEntry.reference}.`);
      if (onWitnessAdded) {
        await onWitnessAdded();
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex h-full flex-col justify-between rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-teal-700 dark:text-teal-400" />
          <h3 className="font-editorial text-xl font-bold text-slate-900 dark:text-white">
            The &ldquo;Otaq&rdquo; (اوطاق) Digital Majlis
          </h3>
        </div>
        <span className="font-mono text-xs font-semibold text-teal-700 tabular-nums dark:text-teal-400">
          {witnessCount} Witnesses · Crown {amanatScore}/1000
        </span>
      </div>

      <form onSubmit={handleAddWitness} className="mt-4 space-y-3 text-xs">
        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300">
              Contract Block
            </label>
            <select
              value={activeEntry?.id || ''}
              onChange={(e) => setSelectedEntryId(e.target.value)}
              className="mt-1 w-full rounded-lg border border-stone-300 bg-white px-2.5 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-100"
            >
              {ledgerEntries.slice(0, 10).map((entry) => (
                <option key={entry.id} value={entry.id}>
                  #{entry.index} {entry.reference} — {entry.debtorName}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-300">
              Witness Elder / Trader
            </label>
            <input
              type="text"
              required
              value={witnessName}
              onChange={(e) => setWitnessName(e.target.value)}
              className="mt-1 w-full rounded-lg border border-stone-300 bg-white px-2.5 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-100"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          <input
            type="text"
            required
            value={witnessRole}
            onChange={(e) => setWitnessRole(e.target.value)}
            placeholder="Role (e.g. Grain Mandi Elder)"
            className="w-full rounded-lg border border-stone-300 bg-white px-2.5 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-100"
          />
          <input
            type="text"
            required
            value={otaqLocation}
            onChange={(e) => setOtaqLocation(e.target.value)}
            placeholder="Otaq Location"
            className="w-full rounded-lg border border-stone-300 bg-white px-2.5 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-100"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <button
            type="submit"
            disabled={busy || !activeEntry}
            className="inline-flex items-center gap-1.5 rounded-lg bg-teal-700 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-60 dark:bg-teal-500 dark:text-slate-950"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>{busy ? 'Attesting...' : 'Record Shahadah Witness'}</span>
          </button>
          {notice && (
            <span className="text-[11px] font-medium text-teal-700 dark:text-teal-400">
              {notice}
            </span>
          )}
        </div>
      </form>

      {activeEntry && (
        <div className="mt-4 space-y-1.5 border-t border-stone-200 pt-3.5 text-xs dark:border-slate-800">
          <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
            Witnesses on {activeEntry.reference}
          </div>
          {(activeEntry.witnesses?.length ?? 0) === 0 ? (
            <div className="text-[11px] text-slate-400">
              No community witness yet — record the first Shahadah attestation above.
            </div>
          ) : (
            <div className="divide-y divide-stone-200 dark:divide-slate-800">
              {activeEntry.witnesses?.slice(-3).map((w) => (
                <div
                  key={w.id}
                  className="flex items-center justify-between gap-2 py-1.5 text-[11px]"
                >
                  <span className="flex items-center gap-1.5 font-medium text-slate-800 dark:text-slate-200">
                    <CheckCircle2 className="h-3 w-3 text-teal-600" />
                    {w.witnessName} ({w.witnessRole})
                  </span>
                  <span className="font-mono text-slate-500 dark:text-slate-400">
                    {w.otaqLocation}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
