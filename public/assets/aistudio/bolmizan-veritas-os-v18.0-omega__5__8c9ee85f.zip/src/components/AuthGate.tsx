import { useState } from 'react';
import { startAuthentication } from '@simplewebauthn/browser';
import {
  ArrowRight,
  Crown,
  Delete,
  ExternalLink,
  Fingerprint,
  KeyRound,
  Lock,
  Mail,
  MessageCircle,
  ShieldCheck,
  Smartphone,
  UserPlus,
} from 'lucide-react';
import type { UiLanguage, WorkspaceRole } from '../../shared/types';
import {
  apiFetch,
  beginExternalAuthFlow,
  clearExternalAuthFlow,
  setSessionToken,
} from '../utils/sessionClient';
import { SindhMizanEmblem } from './SindhMizanEmblem';

interface AuthGateProps {
  language: UiLanguage;
  lockedReason?: string | null;
  onChangeLanguage: (lang: UiLanguage) => void;
  onAuthenticated: () => Promise<boolean>;
}

type AuthChannel = 'email' | 'phone_pin' | 'whatsapp_otp' | 'google';

export function AuthGate({
  language,
  lockedReason,
  onChangeLanguage,
  onAuthenticated,
}: AuthGateProps) {
  const [channel, setChannel] = useState<AuthChannel>('email');
  const [mode, setMode] = useState<'login' | 'register'>('login');

  const [email, setEmail] = useState('mahtabjk123@gmail.com');
  const [password, setPassword] = useState('Veritas@7860');
  const [fullName, setFullName] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [location, setLocation] = useState('Sakrand, Sindh, Pakistan');
  const [defaultRole, setDefaultRole] = useState<WorkspaceRole>('merchant');

  const [mobileNumber, setMobileNumber] = useState('03007860786');
  const [mobilePin, setMobilePin] = useState('7860');
  const [mobileName, setMobileName] = useState('');

  const [waPhone, setWaPhone] = useState('03007860786');
  const [waOtpCode, setWaOtpCode] = useState('');
  const [waOtpSent, setWaOtpSent] = useState<{
    maskedPhone: string;
    waLink: string;
    previewCode: string;
  } | null>(null);

  const [googleEmail, setGoogleEmail] = useState('mahtabjk123@gmail.com');
  const [googleName, setGoogleName] = useState('Mahtab Ali Jamali');
  const [googleBusiness, setGoogleBusiness] = useState('Sakrand Global Export House');

  const [busy, setBusy] = useState(false);
  const [founderBusy, setFounderBusy] = useState(false);
  const [passkeyBusy, setPasskeyBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [pavilionFailed, setPavilionFailed] = useState(false);
  const [craftFailed, setCraftFailed] = useState(false);

  async function finalizeAuthResponse(res: Response, fallbackError: string) {
    const json = (await res.json()) as { error?: string; token?: string };
    if (!res.ok) {
      setErrorMsg(json.error || fallbackError);
      return;
    }
    if (json.token) {
      setSessionToken(json.token);
    }
    const ok = await onAuthenticated();
    if (!ok) {
      setErrorMsg('Session created but workspace bootstrap failed. Please retry.');
    }
  }

  async function handleFounderQuickLaunch() {
    setErrorMsg(null);
    setFounderBusy(true);
    try {
      const res = await apiFetch('/api/auth/founder-quick', { method: 'POST' });
      await finalizeAuthResponse(res, 'Founder quick launch failed.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Network error');
    } finally {
      setFounderBusy(false);
    }
  }

  async function handleEmailSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErrorMsg(null);
    setBusy(true);
    try {
      const endpoint = mode === 'login' ? '/api/auth/login' : '/api/auth/register';
      const body =
        mode === 'login'
          ? { email: email.trim(), password }
          : {
              email: email.trim(),
              password,
              fullName: fullName.trim() || email.split('@')[0] || 'Trade Operator',
              businessName: businessName.trim() || 'SINDH-MIZAN Merchant Desk',
              location: location.trim() || 'Sakrand, Sindh, Pakistan',
              defaultRole,
            };
      const res = await apiFetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      await finalizeAuthResponse(res, 'Authentication failed.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Network error');
    } finally {
      setBusy(false);
    }
  }

  async function handlePasskeySignIn() {
    setErrorMsg(null);
    setPasskeyBusy(true);
    beginExternalAuthFlow(30_000);
    try {
      const optRes = await apiFetch('/api/auth/webauthn/login-options', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const optJson = (await optRes.json()) as {
        error?: string;
        options?: Parameters<typeof startAuthentication>[0]['optionsJSON'];
        userId?: string;
      };
      if (!optRes.ok || !optJson.options || !optJson.userId) {
        setErrorMsg(optJson.error || 'Passkey unavailable for this email.');
        return;
      }
      const assertion = await startAuthentication({ optionsJSON: optJson.options });
      const verRes = await apiFetch('/api/auth/webauthn/login-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: optJson.userId, response: assertion }),
      });
      await finalizeAuthResponse(verRes, 'Passkey verification failed.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Biometric authentication cancelled.');
    } finally {
      clearExternalAuthFlow();
      setPasskeyBusy(false);
    }
  }

  async function handlePhonePinSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErrorMsg(null);
    setBusy(true);
    try {
      const res = await apiFetch('/api/auth/phone-pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: mobileNumber.trim(),
          pin: mobilePin.trim(),
          fullName: mobileName.trim() || undefined,
          location: 'Sakrand, Sindh, Pakistan',
        }),
      });
      await finalizeAuthResponse(res, 'Mobile PIN authentication failed.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Network error');
    } finally {
      setBusy(false);
    }
  }

  async function handleRequestWhatsappOtp() {
    setErrorMsg(null);
    setBusy(true);
    try {
      const res = await apiFetch('/api/auth/whatsapp-otp/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: waPhone.trim() }),
      });
      const json = (await res.json()) as {
        error?: string;
        maskedPhone?: string;
        waLink?: string;
        previewCode?: string;
      };
      if (!res.ok || !json.waLink || !json.previewCode) {
        setErrorMsg(json.error || 'Unable to generate WhatsApp OTP.');
        return;
      }
      setWaOtpSent({
        maskedPhone: json.maskedPhone || waPhone,
        waLink: json.waLink,
        previewCode: json.previewCode,
      });
      setWaOtpCode(json.previewCode);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Network error');
    } finally {
      setBusy(false);
    }
  }

  async function handleVerifyWhatsappOtp(e: React.FormEvent) {
    e.preventDefault();
    setErrorMsg(null);
    setBusy(true);
    try {
      const res = await apiFetch('/api/auth/whatsapp-otp/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: waPhone.trim(),
          code: waOtpCode.trim(),
        }),
      });
      await finalizeAuthResponse(res, 'WhatsApp OTP verification failed.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Network error');
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogleContinue(e: React.FormEvent) {
    e.preventDefault();
    setErrorMsg(null);
    setBusy(true);
    beginExternalAuthFlow(15_000);
    try {
      const res = await apiFetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: googleEmail.trim(),
          fullName: googleName.trim(),
          businessName: googleBusiness.trim() || undefined,
          location: 'Sakrand, Sindh, Pakistan',
        }),
      });
      await finalizeAuthResponse(res, 'Google sign-in failed.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Network error');
    } finally {
      clearExternalAuthFlow();
      setBusy(false);
    }
  }

  function appendKeypadDigit(digit: string) {
    if (mobilePin.length >= 6) return;
    setMobilePin((prev) => `${prev}${digit}`);
  }

  const CHANNEL_TABS: Array<{ id: AuthChannel; label: string; icon: typeof Mail }> = [
    { id: 'email', label: 'Email', icon: Mail },
    { id: 'phone_pin', label: 'Phone PIN', icon: Smartphone },
    { id: 'whatsapp_otp', label: 'WhatsApp', icon: MessageCircle },
    { id: 'google', label: 'Google', icon: ShieldCheck },
  ];

  const inputCls =
    'mt-1 w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:outline-none dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-100 dark:focus:border-teal-400';

  return (
    <div className="grid min-h-screen w-full grid-cols-1 bg-[#F8F7F3] text-slate-900 lg:grid-cols-12 dark:bg-[#0B1117] dark:text-slate-100">
      {/* Left 6 Cols: Daylight Hala Kashi Courtyard Architectural Pavilion */}
      <div className="relative flex min-h-[460px] flex-col justify-between overflow-hidden bg-[#0F3938] p-8 text-white sm:p-12 lg:col-span-6">
        {!pavilionFailed && (
          <img
            src="/src/assets/images/kashi_mizan_pavilion_1794630301954.jpg"
            alt="Hala glazed turquoise ceramic pavilion with precision brass Mizan balance scale"
            referrerPolicy="no-referrer"
            onError={() => setPavilionFailed(true)}
            className="absolute inset-0 h-full w-full object-cover"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#082223] via-[#0B2D2D]/70 to-[#082223]/40" />

        <div className="relative z-10 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <SindhMizanEmblem size={44} />
            <div>
              <div className="font-display text-sm font-bold tracking-wide text-white">
                SINDH-MIZAN
              </div>
              <div className="font-mono text-[11px] text-teal-200/90">
                Sakrand, Sindh · 26.1384° N, 68.2735° E
              </div>
            </div>
          </div>

          <div className="hidden items-center gap-2 font-editorial text-sm text-teal-100 sm:flex">
            <span>سنڌ ميزان</span>
            <span aria-hidden="true">·</span>
            <span>سندھ میزان</span>
          </div>
        </div>

        <div className="relative z-10 my-10 max-w-xl space-y-4">
          <div className="text-xs font-semibold tracking-wider text-amber-200">
            Har Bol Mein Amanat · Har Hisab Mein Adl
          </div>
          <h1 className="font-editorial text-4xl font-bold leading-[1.06] tracking-tight text-balance text-white sm:text-5xl">
            Adl Jo Tarazu, Amanat Jo Khazano.
          </h1>
          <p className="text-sm leading-relaxed text-teal-50/90 sm:text-base">
            Designed equally for a daily-wage vendor in Sakrand Bazaar and global export clearing across Riyadh, Dubai, London, and New York — Voice-to-Hisab, SHA-256 Quran 2:282 contracts, Otaq witnesses, and 21 sovereign rails.
          </p>
        </div>

        <div className="relative z-10 space-y-5">
          <button
            type="button"
            onClick={handleFounderQuickLaunch}
            disabled={founderBusy}
            className="group flex w-full max-w-lg items-center justify-between gap-4 rounded-xl border border-white/25 bg-[#082223]/85 px-5 py-4 text-left backdrop-blur-md transition-colors hover:border-teal-300/70 hover:bg-[#0D3233] disabled:opacity-60"
          >
            <div className="flex items-center gap-4">
              {!craftFailed ? (
                <img
                  src="/src/assets/images/ajrak_mercantile_craft_1794630302546.jpg"
                  alt="Ajrak cloth and precision brass mercantile compass"
                  referrerPolicy="no-referrer"
                  onError={() => setCraftFailed(true)}
                  className="h-12 w-12 shrink-0 rounded-lg border border-white/25 object-cover"
                />
              ) : (
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-teal-600 text-white">
                  <Crown className="h-5 w-5" />
                </div>
              )}
              <div>
                <div className="font-display text-sm font-bold text-white">
                  {founderBusy
                    ? 'Unlocking Sovereign Session...'
                    : 'Launch as Founder · Mahtab Ali Jamali'}
                </div>
                <div className="mt-0.5 font-mono text-xs text-teal-200">
                  mahtabjk123@gmail.com · Sakrand HQ · Full Clearinghouse
                </div>
              </div>
            </div>
            <ArrowRight className="h-4 w-4 shrink-0 text-teal-300 transition-transform group-hover:translate-x-1" />
          </button>

          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-white/20 pt-4 text-xs text-teal-100/85">
            <span className="font-mono tabular-nums">0% Riba Mathematical Gate</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">5-Way Zero-Trust Lock</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">21 Sindh Districts Live</span>
          </div>
        </div>
      </div>

      {/* Right 6 Cols: Crisp Porcelain Operator Access Studio */}
      <div className="flex flex-col justify-between bg-white px-6 py-8 sm:px-12 lg:col-span-6 lg:py-12 dark:bg-[#111922]">
        <div className="mx-auto w-full max-w-md space-y-6">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300">
              <Lock className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
              <span>Zero-Trust Operator Portal</span>
            </div>

            <select
              value={language}
              onChange={(e) => onChangeLanguage(e.target.value as UiLanguage)}
              aria-label="Interface Language"
              className="rounded-lg border border-stone-300 bg-[#F8F7F3] px-2.5 py-1 text-xs font-medium text-slate-800 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-200"
            >
              <option value="en">English</option>
              <option value="ur">اردو</option>
              <option value="sd">سنڌي</option>
              <option value="ar">العربية</option>
            </select>
          </div>

          <div>
            <h2 className="font-editorial text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              Verify Identity
            </h2>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Sessions lock automatically on exit. Choose your preferred sign-in channel below.
            </p>
          </div>

          {lockedReason && (
            <div className="rounded-lg border border-amber-300 bg-amber-50 px-3.5 py-2.5 text-xs font-medium text-amber-950 dark:border-amber-700/60 dark:bg-amber-950/40 dark:text-amber-200">
              {lockedReason}
            </div>
          )}

          {/* Segmented Auth Channel Bar */}
          <div className="grid grid-cols-4 gap-1 rounded-lg border border-stone-200 bg-[#F3F1EB] p-1 dark:border-slate-800 dark:bg-[#0B1117]">
            {CHANNEL_TABS.map((tab) => {
              const Icon = tab.icon;
              const active = channel === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setChannel(tab.id);
                    setErrorMsg(null);
                  }}
                  className={`flex items-center justify-center gap-1.5 rounded-md px-2 py-2 text-xs font-semibold whitespace-nowrap transition-colors ${
                    active
                      ? 'bg-white text-teal-800 shadow-xs dark:bg-teal-500 dark:text-slate-950'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Channel 1: Email + PBKDF2 + WebAuthn Passkey */}
          {channel === 'email' && (
            <div className="space-y-4">
              <div className="flex border-b border-stone-200 text-xs font-semibold dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setErrorMsg(null);
                    if (!email.trim()) {
                      setEmail('mahtabjk123@gmail.com');
                      setPassword('Veritas@7860');
                    }
                  }}
                  className={`border-b-2 px-4 py-2.5 transition-colors ${
                    mode === 'login'
                      ? 'border-teal-700 text-teal-800 dark:border-teal-400 dark:text-teal-300'
                      : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setErrorMsg(null);
                    if (email.trim().toLowerCase() === 'mahtabjk123@gmail.com') {
                      setEmail('');
                      setPassword('');
                    }
                  }}
                  className={`border-b-2 px-4 py-2.5 transition-colors ${
                    mode === 'register'
                      ? 'border-teal-700 text-teal-800 dark:border-teal-400 dark:text-teal-300'
                      : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400'
                  }`}
                >
                  Create Account
                </button>
              </div>

              <form onSubmit={handleEmailSubmit} className="space-y-3.5">
                {mode === 'register' && (
                  <>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                          Full Name
                        </label>
                        <input
                          type="text"
                          required
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="Bilal Bhutto"
                          className={inputCls}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                          Business / Shop
                        </label>
                        <input
                          type="text"
                          required
                          value={businessName}
                          onChange={(e) => setBusinessName(e.target.value)}
                          placeholder="Mehran Agro Store"
                          className={inputCls}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                          City / Hub
                        </label>
                        <input
                          type="text"
                          required
                          value={location}
                          onChange={(e) => setLocation(e.target.value)}
                          className={inputCls}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                          Workspace Role
                        </label>
                        <select
                          value={defaultRole}
                          onChange={(e) => setDefaultRole(e.target.value as WorkspaceRole)}
                          className={inputCls}
                        >
                          <option value="merchant">Mazdoor / Shopkeeper</option>
                          <option value="founder">Founder / CEO</option>
                          <option value="exporter">Enterprise Exporter</option>
                          <option value="product_manager">Product Manager</option>
                          <option value="marketer">Growth Marketer</option>
                          <option value="auditor">Security Auditor</option>
                        </select>
                      </div>
                    </div>
                  </>
                )}

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={inputCls}
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                    Password (PBKDF2-SHA512)
                  </label>
                  <input
                    type="password"
                    required
                    minLength={mode === 'register' ? 8 : 1}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className={inputCls}
                  />
                </div>

                <button
                  type="submit"
                  disabled={busy}
                  className="flex w-full items-center justify-center gap-2 rounded-lg bg-teal-700 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-60 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                >
                  {mode === 'login' ? (
                    <>
                      <KeyRound className="h-4 w-4" />
                      <span>{busy ? 'Verifying Session...' : 'Sign In'}</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="h-4 w-4" />
                      <span>{busy ? 'Creating Account...' : 'Register & Enter'}</span>
                    </>
                  )}
                </button>
              </form>

              {mode === 'login' && (
                <button
                  type="button"
                  disabled={passkeyBusy}
                  onClick={handlePasskeySignIn}
                  className="flex w-full items-center justify-center gap-2 rounded-lg border border-stone-300 bg-transparent px-4 py-2.5 text-xs font-semibold text-slate-800 transition-colors hover:bg-stone-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <Fingerprint className="h-4 w-4 text-teal-700 dark:text-teal-400" />
                  <span>
                    {passkeyBusy ? 'Checking Passkey...' : 'Sign In with FIDO2 Passkey'}
                  </span>
                </button>
              )}
            </div>
          )}

          {/* Channel 2: Mobile Number + Tactile Numeric Keypad */}
          {channel === 'phone_pin' && (
            <form onSubmit={handlePhonePinSubmit} className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-teal-600/30 bg-teal-50 px-3.5 py-2.5 text-xs dark:border-teal-700/50 dark:bg-teal-950/35">
                <div>
                  <div className="font-semibold text-teal-900 dark:text-teal-300">
                    Sakrand Worker Preset (مزدور لاگ اِن)
                  </div>
                  <div className="font-mono text-[11px] text-slate-600 dark:text-slate-300">
                    03007860786 · PIN 7860 · Khadim Hussain Mochi
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setMobileNumber('03007860786');
                    setMobilePin('7860');
                    setMobileName('Khadim Hussain Mochi');
                  }}
                  className="rounded-md bg-teal-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950"
                >
                  Use Worker
                </button>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                    Mobile Number
                  </label>
                  <input
                    type="tel"
                    required
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    placeholder="03007860786"
                    className={`${inputCls} font-mono`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                    Name (New Account)
                  </label>
                  <input
                    type="text"
                    value={mobileName}
                    onChange={(e) => setMobileName(e.target.value)}
                    placeholder="Khadim Hussain"
                    className={inputCls}
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-medium text-slate-700 dark:text-slate-300">
                  <span>4–6 Digit Secret PIN</span>
                  <span className="font-mono font-bold tracking-widest text-teal-700 dark:text-teal-400">
                    {mobilePin.replace(/./g, '●') || '----'}
                  </span>
                </div>
                <div className="mt-2 grid grid-cols-4 gap-2 sm:grid-cols-6">
                  {['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'].map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => appendKeypadDigit(d)}
                      className="rounded-lg border border-stone-300 bg-[#F8F7F3] py-2.5 font-mono text-sm font-bold text-slate-900 transition-colors hover:border-teal-600 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-100"
                    >
                      {d}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setMobilePin((p) => p.slice(0, -1))}
                    aria-label="Backspace PIN"
                    className="flex items-center justify-center rounded-lg border border-stone-300 bg-stone-100 py-2.5 text-xs font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                  >
                    <Delete className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setMobilePin('')}
                    className="rounded-lg border border-stone-300 bg-stone-100 py-2.5 text-xs font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                  >
                    Clear
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={busy || mobilePin.length < 4}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#9B1C2E] px-4 py-2.5 text-sm font-bold text-white transition-colors hover:bg-[#821626] disabled:opacity-60"
              >
                <Smartphone className="h-4 w-4" />
                <span>{busy ? 'Verifying PIN...' : 'Unlock with Mobile + PIN'}</span>
              </button>
            </form>
          )}

          {/* Channel 3: WhatsApp Instant 6-Digit OTP */}
          {channel === 'whatsapp_otp' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600 dark:text-slate-300">
                Receive a 6-digit verification code via WhatsApp (`wa.me`) for passwordless entry.
              </p>

              <div className="flex flex-col gap-2 sm:flex-row">
                <input
                  type="tel"
                  value={waPhone}
                  onChange={(e) => setWaPhone(e.target.value)}
                  placeholder="03007860786"
                  className="flex-1 rounded-lg border border-stone-300 bg-white px-3.5 py-2 font-mono text-sm text-slate-900 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-100"
                />
                <button
                  type="button"
                  disabled={busy}
                  onClick={handleRequestWhatsappOtp}
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-teal-700 px-4 py-2 text-xs font-semibold text-white whitespace-nowrap hover:bg-teal-800 disabled:opacity-60 dark:bg-teal-500 dark:text-slate-950"
                >
                  <MessageCircle className="h-4 w-4" />
                  <span>{busy ? 'Sending...' : 'Send OTP'}</span>
                </button>
              </div>

              {waOtpSent && (
                <form
                  onSubmit={handleVerifyWhatsappOtp}
                  className="space-y-3 rounded-lg border border-teal-600/35 bg-teal-50/70 p-4 dark:border-teal-700/50 dark:bg-teal-950/30"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="font-medium text-teal-900 dark:text-teal-300">
                      {waOtpSent.maskedPhone} · Code: <strong className="font-mono">{waOtpSent.previewCode}</strong>
                    </span>
                    <a
                      href={waOtpSent.waLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => beginExternalAuthFlow(20_000)}
                      className="inline-flex items-center gap-1 font-semibold text-teal-800 underline dark:text-teal-300"
                    >
                      <span>Open WhatsApp</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>

                  <div className="flex flex-col gap-2 sm:flex-row">
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={waOtpCode}
                      onChange={(e) => setWaOtpCode(e.target.value)}
                      placeholder="6-digit OTP"
                      className="flex-1 rounded-lg border border-stone-300 bg-white px-3.5 py-2 font-mono text-sm tracking-widest text-slate-900 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-100"
                    />
                    <button
                      type="submit"
                      disabled={busy}
                      className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-teal-500 dark:text-slate-950"
                    >
                      Verify &amp; Enter
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Channel 4: Continue with Google */}
          {channel === 'google' && (
            <form onSubmit={handleGoogleContinue} className="space-y-3.5">
              <p className="text-xs text-slate-600 dark:text-slate-300">
                Sign in with your Google identity — binds automatically to Sakrand HQ &amp; global corridors.
              </p>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                    Google Email
                  </label>
                  <input
                    type="email"
                    required
                    value={googleEmail}
                    onChange={(e) => setGoogleEmail(e.target.value)}
                    className={inputCls}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={googleName}
                    onChange={(e) => setGoogleName(e.target.value)}
                    className={inputCls}
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                  Business / Export House
                </label>
                <input
                  type="text"
                  value={googleBusiness}
                  onChange={(e) => setGoogleBusiness(e.target.value)}
                  className={inputCls}
                />
              </div>
              <button
                type="submit"
                disabled={busy}
                className="flex w-full items-center justify-center gap-2 rounded-lg border border-stone-300 bg-[#F8F7F3] px-4 py-2.5 text-sm font-semibold text-slate-900 transition-colors hover:bg-stone-200/70 dark:border-slate-700 dark:bg-[#0B1117] dark:text-white dark:hover:bg-slate-800"
              >
                <span className="flex h-5 w-5 items-center justify-center rounded-sm bg-teal-700 text-[11px] font-black text-white">
                  G
                </span>
                <span>{busy ? 'Signing in...' : 'Continue with Google'}</span>
              </button>
            </form>
          )}

          {errorMsg && (
            <div className="rounded-lg border border-rose-300 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800 dark:border-rose-900/60 dark:bg-rose-950/40 dark:text-rose-300">
              {errorMsg}
            </div>
          )}
        </div>

        <div className="mx-auto mt-8 w-full max-w-md border-t border-stone-200 pt-4 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
          Founder: <span className="font-mono text-teal-800 dark:text-teal-400">mahtabjk123@gmail.com</span> /{' '}
          <span className="font-mono">Veritas@7860</span> · Worker:{' '}
          <span className="font-mono">03007860786</span> (PIN <span className="font-mono">7860</span>)
        </div>
      </div>
    </div>
  );
}
