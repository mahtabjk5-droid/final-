import { useEffect } from 'react';
import type { CulturalMotifId } from '../utils/culturalCalendar';

interface IndusFlowParallaxLayerProps {
  motif: CulturalMotifId;
}

const MOTIF_COLORS: Record<
  CulturalMotifId,
  { primary: string; secondary: string; river: string }
> = {
  ajrak: { primary: '#9F1239', secondary: '#F59E0B', river: '#10B981' },
  kashi: { primary: '#0D9488', secondary: '#38BDF8', river: '#1D4ED8' },
  thar: { primary: '#D97706', secondary: '#FBBF24', river: '#B45309' },
  indus: { primary: '#059669', secondary: '#F59E0B', river: '#0EA5E9' },
};

export function IndusFlowParallaxLayer({ motif }: IndusFlowParallaxLayerProps) {
  const palette = MOTIF_COLORS[motif];

  useEffect(() => {
    if (typeof window === 'undefined') return;
    let rafId: number | null = null;

    const updateScrollVars = () => {
      rafId = null;
      const scrollY = window.scrollY || window.pageYOffset || 0;
      const docHeight = Math.max(
        1,
        document.documentElement.scrollHeight - window.innerHeight
      );
      const progress = Math.min(1, Math.max(0, scrollY / docHeight));

      const rootStyle = document.documentElement.style;
      rootStyle.setProperty('--indus-scroll-y', `${scrollY.toFixed(1)}px`);
      rootStyle.setProperty('--indus-progress', progress.toFixed(4));
    };

    const handleScroll = () => {
      if (rafId === null) {
        rafId = window.requestAnimationFrame(updateScrollVars);
      }
    };

    updateScrollVars();
    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
      if (rafId !== null) {
        window.cancelAnimationFrame(rafId);
      }
    };
  }, []);

  return (
    <>
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-0 overflow-hidden select-none"
      >
        {/* Depth Layer 1: Deep Makli & Hala Kashi Star Lattice */}
        <svg
          className="indus-parallax-deep absolute -inset-24 h-[calc(100%+12rem)] w-[calc(100%+12rem)] opacity-[0.38] dark:opacity-[0.55]"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <pattern
              id="hala-kashi-grid"
              width="120"
              height="120"
              patternUnits="userSpaceOnUse"
            >
              <g fill="none" strokeWidth="0.75">
                <polygon
                  points="60,8 112,60 60,112 8,60"
                  stroke={palette.secondary}
                  strokeOpacity="0.11"
                />
                <polygon
                  points="60,24 96,60 60,96 24,60"
                  stroke={palette.primary}
                  strokeOpacity="0.14"
                />
                <circle
                  cx="60"
                  cy="60"
                  r="11"
                  stroke={palette.river}
                  strokeOpacity="0.12"
                />
                <path
                  d="M0 0 L24 24 M120 0 L96 24 M0 120 L24 96 M120 120 L96 96"
                  stroke={palette.secondary}
                  strokeOpacity="0.08"
                />
              </g>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#hala-kashi-grid)" />
        </svg>

        {/* Depth Layer 2: Mid Ajrak Woodblock & Shisha Mirror Constellations */}
        <svg
          viewBox="0 0 1440 1200"
          preserveAspectRatio="xMidYMid slice"
          className="indus-parallax-mid absolute -inset-16 h-[135vh] w-[calc(100%+8rem)] opacity-60 dark:opacity-75"
        >
          {[
            { cx: 120, cy: 180, r: 22 },
            { cx: 1320, cy: 260, r: 26 },
            { cx: 160, cy: 640, r: 18 },
            { cx: 1280, cy: 760, r: 24 },
            { cx: 220, cy: 1020, r: 20 },
            { cx: 1220, cy: 1080, r: 22 },
          ].map((m, idx) => (
            <g key={idx}>
              <polygon
                points={`${m.cx},${m.cy - m.r} ${m.cx + m.r},${m.cy} ${m.cx},${m.cy + m.r} ${m.cx - m.r},${m.cy}`}
                fill={palette.primary}
                fillOpacity="0.05"
                stroke={palette.secondary}
                strokeOpacity="0.2"
                strokeWidth="1"
              />
              <circle
                cx={m.cx}
                cy={m.cy}
                r="3.2"
                fill={palette.secondary}
                className="shisha-glint"
                style={{ animationDelay: `${idx * 0.45}s` }}
              />
            </g>
          ))}
        </svg>

        {/* Depth Layer 3: Foreground River Indus Flowing Splines */}
        <svg
          viewBox="0 0 1440 1200"
          preserveAspectRatio="none"
          className="indus-parallax-front absolute inset-x-0 -top-24 h-[145vh] w-full opacity-55 dark:opacity-70"
        >
          <path
            d="M 42 -40 C 110 210, -15 430, 68 680 C 140 900, 12 1080, 74 1280"
            fill="none"
            stroke={palette.river}
            strokeOpacity="0.16"
            strokeWidth="2.2"
            strokeDasharray="10 8"
          />
          <path
            d="M 1398 -40 C 1320 240, 1455 480, 1368 740 C 1295 950, 1425 1100, 1365 1280"
            fill="none"
            stroke={palette.secondary}
            strokeOpacity="0.18"
            strokeWidth="1.8"
          />
        </svg>
      </div>

      {/* Subtle Desktop Scroll-Progress Indus Thread */}
      <div
        aria-hidden="true"
        className="no-print pointer-events-none fixed right-2.5 top-24 bottom-24 z-30 hidden w-0.5 rounded-full bg-stone-300/40 lg:block dark:bg-white/10"
      >
        <div
          className="indus-scroll-ribbon h-full w-full rounded-full"
          style={{
            background: `linear-gradient(to bottom, ${palette.primary}, ${palette.secondary}, ${palette.river})`,
          }}
        />
      </div>
    </>
  );
}
