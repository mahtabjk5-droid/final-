import { Award, Globe2, Printer, ShieldCheck, TrendingUp, X } from 'lucide-react';
import type { VeritasBootstrapPayload } from '../../shared/types';
import { formatCurrency } from '../utils/formatters';

interface InvestorPitchHudModalProps {
  data: VeritasBootstrapPayload;
  onClose: () => void;
}

export function InvestorPitchHudModal({ data, onClose }: InvestorPitchHudModalProps) {
  const arrRunRate = data.treasury.mrrUsd * 12;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/70 p-4 backdrop-blur-xs dark:bg-[#0B1117]/80">
      <div className="veritas-enter w-full max-w-4xl overflow-hidden rounded-2xl border border-stone-200 bg-white text-stone-900 shadow-2xl dark:border-slate-800 dark:bg-[#111922] dark:text-stone-100">
        <div className="no-print flex items-center justify-between border-b border-stone-200 px-6 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-700/10 text-teal-700 dark:bg-teal-500/15 dark:text-teal-400">
              <TrendingUp className="h-5 w-5" />
            </div>
            <div>
              <div className="font-editorial text-xl font-bold text-stone-900 dark:text-white">
                SINDH-MIZAN OS™ — Executive Investor HUD
              </div>
              <div className="text-xs text-stone-500 dark:text-slate-400">
                Founder: Mahtab Ali Jamali (mahtabjk123@gmail.com) · Sakrand, Sindh HQ
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 rounded-xl bg-teal-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Print Snapshot</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl p-1.5 text-stone-500 hover:bg-stone-100 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="space-y-6 p-6">
          <div className="grid grid-cols-2 divide-y divide-stone-200 overflow-hidden rounded-xl border border-stone-200 bg-[#F8F7F3] sm:grid-cols-4 sm:divide-x sm:divide-y-0 dark:divide-slate-800 dark:border-slate-800 dark:bg-[#0B1117]">
            <div className="p-4">
              <div className="text-xs text-stone-500 dark:text-slate-400">SaaS Run-Rate (ARR)</div>
              <div className="mt-1 font-mono text-2xl font-bold text-teal-700 tabular-nums dark:text-teal-300">
                {formatCurrency(arrRunRate, 'USD')}
              </div>
              <div className="mt-1 text-[11px] text-emerald-700 dark:text-emerald-400">
                MRR {formatCurrency(data.treasury.mrrUsd, 'USD')}
              </div>
            </div>
            <div className="p-4">
              <div className="text-xs text-stone-500 dark:text-slate-400">Live Cleared Volume</div>
              <div className="mt-1 font-mono text-2xl font-bold text-stone-900 tabular-nums dark:text-white">
                {formatCurrency(data.metrics.grossVolumeUsd, 'USD')}
              </div>
              <div className="mt-1 text-[11px] text-stone-500 dark:text-slate-400">
                {data.metrics.totalTransactions} tx · 21 rails
              </div>
            </div>
            <div className="p-4">
              <div className="text-xs text-stone-500 dark:text-slate-400">Amanat Credit Index</div>
              <div className="mt-1 font-mono text-2xl font-bold text-emerald-700 tabular-nums dark:text-emerald-400">
                {data.amanatPassport.score}/1000
              </div>
              <div className="mt-1 text-[11px] text-stone-500 dark:text-slate-400">
                0% Riba · SHA-256 Verified
              </div>
            </div>
            <div className="p-4">
              <div className="text-xs text-stone-500 dark:text-slate-400">TAM / SAM / SOM</div>
              <div className="mt-1 font-mono text-xl font-bold text-stone-900 tabular-nums dark:text-white">
                $4.2T / $480B / $14B
              </div>
              <div className="mt-1 text-[11px] text-[#9B1C2E] dark:text-amber-300">
                Islamic Trade + MSME Clearing
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div className="rounded-xl border border-teal-600/25 bg-teal-700/5 p-4 text-xs dark:bg-teal-500/8">
              <div className="flex items-center gap-2 font-semibold text-teal-800 dark:text-teal-300">
                <ShieldCheck className="h-4 w-4" />
                <span>Unfair Zero-Riba Cryptographic Moat</span>
              </div>
              <p className="mt-2 leading-relaxed text-stone-600 dark:text-slate-300">
                Every Udhaar, Murabaha, and Mukasa settlement is chained in SHA-256, court-admissible under Pakistan ETO-2002 / UNCITRAL, and mathematically blocks interest rates at API validation layer.
              </p>
            </div>

            <div className="rounded-xl border border-[#9B1C2E]/25 bg-[#9B1C2E]/5 p-4 text-xs dark:bg-[#9B1C2E]/10">
              <div className="flex items-center gap-2 font-semibold text-[#9B1C2E] dark:text-rose-300">
                <Globe2 className="h-4 w-4" />
                <span>Sakrand-to-GCC Network Flywheel</span>
              </div>
              <p className="mt-2 leading-relaxed text-stone-600 dark:text-slate-300">
                $0 onboarding for laborers (Haq-e-Mazdoor) and Sabzi-Wala vendors creates viral bottom-up adoption, converting wholesale corridors and GCC exporters into $15–$79/mo SaaS + flat Ujrah fees.
              </p>
            </div>

            <div className="rounded-xl border border-stone-200 bg-[#F8F7F3] p-4 text-xs dark:border-slate-800 dark:bg-[#0B1117]">
              <div className="flex items-center gap-2 font-semibold text-stone-900 dark:text-white">
                <Award className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                <span>Multi-Hub Live Presence</span>
              </div>
              <div className="mt-2 space-y-1.5">
                {data.branches.map((b) => (
                  <div key={b.id} className="flex justify-between font-mono text-[11px]">
                    <span className="text-stone-600 dark:text-slate-300">{b.name}</span>
                    <span className="font-semibold text-teal-700 dark:text-teal-400">
                      {formatCurrency(b.volumeUsd, 'USD')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
