import { useMemo, useState } from 'react';
import type { VolumeSeriesPoint } from '../../shared/types';
import { formatCurrency } from '../utils/formatters';

interface VolumeChartProps {
  series: VolumeSeriesPoint[];
  subtitle: string;
}

export function VolumeChart({ series, subtitle }: VolumeChartProps) {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const [metricMode, setMetricMode] = useState<'volume' | 'count'>('volume');

  const chart = useMemo(() => {
    const width = 760;
    const height = 240;
    const padLeft = 56;
    const padRight = 16;
    const padTop = 20;
    const padBottom = 30;
    const plotW = width - padLeft - padRight;
    const plotH = height - padTop - padBottom;

    const values = series.map((s) => (metricMode === 'volume' ? s.volumeUsd : s.txCount));
    const maxVal = Math.max(10, ...values) * 1.15;

    const points = series.map((point, idx) => {
      const val = metricMode === 'volume' ? point.volumeUsd : point.txCount;
      const x =
        series.length <= 1
          ? padLeft + plotW / 2
          : padLeft + (idx / (series.length - 1)) * plotW;
      const y = padTop + plotH - (val / maxVal) * plotH;
      return { x, y, val, point };
    });

    const linePath = points
      .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
      .join(' ');

    const areaPath =
      points.length > 0
        ? `${linePath} L ${points[points.length - 1].x.toFixed(1)} ${(padTop + plotH).toFixed(1)} L ${points[0].x.toFixed(1)} ${(padTop + plotH).toFixed(1)} Z`
        : '';

    const yTicks = [0, 0.33, 0.66, 1].map((ratio) => ({
      value: maxVal * ratio,
      y: padTop + plotH - ratio * plotH,
    }));

    return { width, height, padLeft, padBottom, points, linePath, areaPath, yTicks };
  }, [series, metricMode]);

  const activePoint =
    hoverIdx !== null && chart.points[hoverIdx] ? chart.points[hoverIdx] : chart.points[chart.points.length - 1];

  return (
    <div className="rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-editorial text-xl font-bold text-slate-900 dark:text-white">
            Live Clearing Velocity
          </h2>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>
        </div>

        <div className="flex items-center gap-4">
          {activePoint && (
            <div className="text-right">
              <div className="font-mono text-sm font-semibold text-slate-900 tabular-nums dark:text-slate-100">
                {metricMode === 'volume'
                  ? formatCurrency(activePoint.point.volumeUsd, 'USD')
                  : `${activePoint.point.txCount} events`}
              </div>
              <div className="text-[11px] text-slate-500 tabular-nums dark:text-slate-400">
                Window {activePoint.point.label} · {activePoint.point.txCount} tx
              </div>
            </div>
          )}

          <div className="flex items-center rounded-lg border border-stone-200 bg-[#F8F7F3] p-0.5 dark:border-slate-800 dark:bg-[#0B1117]">
            <button
              type="button"
              onClick={() => setMetricMode('volume')}
              className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                metricMode === 'volume'
                  ? 'bg-teal-700 text-white dark:bg-teal-500 dark:text-slate-950'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Volume USD
            </button>
            <button
              type="button"
              onClick={() => setMetricMode('count')}
              className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                metricMode === 'count'
                  ? 'bg-teal-700 text-white dark:bg-teal-500 dark:text-slate-950'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Event Count
            </button>
          </div>
        </div>
      </div>

      <div className="relative w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${chart.width} ${chart.height}`}
          className="h-60 w-full select-none"
          role="img"
          aria-label="Live clearing velocity chart"
        >
          <defs>
            <linearGradient id="veritasAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#059669" stopOpacity="0.24" />
              <stop offset="100%" stopColor="#059669" stopOpacity="0.01" />
            </linearGradient>
          </defs>

          {chart.yTicks.map((tick, idx) => (
            <g key={idx}>
              <line
                x1={chart.padLeft}
                x2={chart.width - 16}
                y1={tick.y}
                y2={tick.y}
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeDasharray="3 3"
              />
              <text
                x={chart.padLeft - 8}
                y={tick.y + 4}
                textAnchor="end"
                className="fill-slate-400 font-mono text-[10px] dark:fill-slate-500"
              >
                {metricMode === 'volume'
                  ? `$${Math.round(tick.value).toLocaleString()}`
                  : Math.round(tick.value)}
              </text>
            </g>
          ))}

          {chart.areaPath && <path d={chart.areaPath} fill="url(#veritasAreaGrad)" />}
          {chart.linePath && (
            <path
              d={chart.linePath}
              fill="none"
              stroke="#059669"
              strokeWidth="2.25"
              strokeLinejoin="round"
              strokeLinecap="round"
            />
          )}

          {chart.points.map((pt, idx) => {
            const isHovered = hoverIdx === idx || (hoverIdx === null && idx === chart.points.length - 1);
            return (
              <g key={pt.point.label + idx}>
                {isHovered && (
                  <line
                    x1={pt.x}
                    x2={pt.x}
                    y1={20}
                    y2={chart.height - chart.padBottom}
                    stroke="#059669"
                    strokeOpacity="0.35"
                    strokeDasharray="2 2"
                  />
                )}
                <circle
                  cx={pt.x}
                  cy={pt.y}
                  r={isHovered ? 4.5 : 2.5}
                  className={
                    isHovered
                      ? 'fill-emerald-600 stroke-white stroke-2 dark:fill-emerald-400 dark:stroke-slate-900'
                      : 'fill-emerald-600/80 dark:fill-emerald-400/80'
                  }
                />
                <rect
                  x={pt.x - 24}
                  y={10}
                  width={48}
                  height={chart.height - 20}
                  fill="transparent"
                  className="cursor-crosshair"
                  onMouseEnter={() => setHoverIdx(idx)}
                  onMouseLeave={() => setHoverIdx(null)}
                />
                {idx % 2 === 0 && (
                  <text
                    x={pt.x}
                    y={chart.height - 8}
                    textAnchor="middle"
                    className="fill-slate-400 font-mono text-[10px] dark:fill-slate-500"
                  >
                    {pt.point.label}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}
