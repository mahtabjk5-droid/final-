import { useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  Loader2,
  Mic,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Square,
  Volume2,
  X,
} from 'lucide-react';
import type {
  BranchId,
  ChainVerificationResult,
  CurrencyCode,
  LedgerEntry,
  LedgerEntryType,
  UiLanguage,
  VoiceParseResult,
} from '../../shared/types';
import { CURRENCY_METADATA } from '../../shared/rails';
import { formatCurrency } from '../utils/formatters';
import { apiFetch } from '../utils/sessionClient';
import { enqueueOfflineAction, speakMultilingual } from '../utils/ttsAndOffline';

interface VoiceCaptureModalProps {
  language: UiLanguage;
  businessName: string;
  simulateOffline: boolean;
  onQueuedOffline: () => void;
  onCompleted: () => Promise<void> | void;
  onClose: () => void;
}

type ModalStage = 'capture' | 'parsing' | 'review' | 'sealed';

const QUICK_SAMPLES: Array<{ label: string; lang: UiLanguage; text: string }> = [
  { label: 'اردو', lang: 'ur', text: 'محمد علی کو 14,500 روپے چینی اور گھی ادھار دیا' },
  { label: 'سنڌي', lang: 'sd', text: 'محبوب علي کي 14,500 جو اڌار ڏنو' },
  { label: 'العربية', lang: 'ar', text: 'عقد مرابحة إسلامي 4600 ريال تمور عجوة للتصدير' },
  { label: 'English', lang: 'en', text: 'Murabaha wheat export contract 1850 USD to Dubai Marina' },
];

const ENTRY_TYPE_OPTIONS: Array<{ value: LedgerEntryType; label: string }> = [
  { value: 'udhaar_given', label: 'Udhaar Given (Receivable · 0% Riba)' },
  { value: 'udhaar_taken', label: 'Udhaar Taken (Payable · 0% Riba)' },
  { value: 'cash_sale', label: 'Cash Sale (Naqad)' },
  { value: 'payment_received', label: 'Payment Received (Wasooli)' },
  { value: 'murabaha_contract', label: 'Murabaha Trade Contract' },
  { value: 'salam_contract', label: 'Salam Forward Agro Contract' },
];

const CURRENCY_OPTIONS = Object.keys(CURRENCY_METADATA) as CurrencyCode[];

function selectSupportedMimeType(): string {
  if (typeof MediaRecorder === 'undefined' || typeof MediaRecorder.isTypeSupported !== 'function') {
    return 'audio/webm';
  }
  const candidates = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/mp4',
    'audio/ogg;codecs=opus',
  ];
  for (const mime of candidates) {
    if (MediaRecorder.isTypeSupported(mime)) {
      return mime;
    }
  }
  return '';
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const base64 = result.includes(',') ? result.split(',')[1] : result;
      if (!base64) {
        reject(new Error('Could not encode audio recording.'));
        return;
      }
      resolve(base64);
    };
    reader.onerror = () => reject(new Error('Failed to read recorded audio blob.'));
    reader.readAsDataURL(blob);
  });
}

export function VoiceCaptureModal({
  language,
  businessName,
  simulateOffline,
  onQueuedOffline,
  onCompleted,
  onClose,
}: VoiceCaptureModalProps) {
  const [stage, setStage] = useState<ModalStage>('capture');
  const [recording, setRecording] = useState(false);
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioMimeType, setAudioMimeType] = useState<string>('audio/webm');
  const [supplementalNote, setSupplementalNote] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [parserEngine, setParserEngine] = useState<VoiceParseResult['parserEngine']>('gemini-4-hydrogen');
  const [detectedLang, setDetectedLang] = useState<UiLanguage>(language);
  const [recognizedTranscript, setRecognizedTranscript] = useState('');
  const [branchId, setBranchId] = useState<Exclude<BranchId, 'all'>>('sakrand_hq');
  const [entryType, setEntryType] = useState<LedgerEntryType>('udhaar_given');
  const [counterparty, setCounterparty] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<CurrencyCode>('PKR');
  const [costBasisUsd, setCostBasisUsd] = useState('1000');
  const [murabahaMarkupUsd, setMurabahaMarkupUsd] = useState('120');
  const [itemsSummary, setItemsSummary] = useState('');
  const [dueDate, setDueDate] = useState(() =>
    new Date(Date.now() + 15 * 86400_000).toISOString().slice(0, 10)
  );
  const [submitting, setSubmitting] = useState(false);
  const [sealedEntry, setSealedEntry] = useState<LedgerEntry | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const timerRef = useRef<number | null>(null);
  const rafRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  function stopMediaResources() {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (rafRef.current !== null) {
      window.cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      void audioContextRef.current.close().catch(() => undefined);
      audioContextRef.current = null;
    }
  }

  useEffect(() => {
    return () => {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        try {
          mediaRecorderRef.current.stop();
        } catch {
          // Ignore stop errors on unmount
        }
      }
      stopMediaResources();
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);

  function drawIdleWaveform() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = 'rgba(15, 118, 110, 0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, canvas.height / 2);
    ctx.lineTo(canvas.width, canvas.height / 2);
    ctx.stroke();
  }

  useEffect(() => {
    if (stage === 'capture' && !recording) {
      drawIdleWaveform();
    }
  }, [stage, recording]);

  async function sendToAiParse(payload: {
    audioBase64?: string;
    mimeType?: string;
    transcript?: string;
    languageHint: UiLanguage;
  }) {
    setStage('parsing');
    setErrorMsg(null);
    try {
      const res = await apiFetch('/api/ai-parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as VoiceParseResult & { error?: string };
      if (!res.ok) {
        throw new Error(json.error || 'Voice extraction failed.');
      }

      setParserEngine(json.parserEngine);
      setDetectedLang(json.languageDetected || language);
      setRecognizedTranscript(json.transcript || payload.transcript || '');
      setCounterparty(json.customerName || 'Counter Customer');
      setAmount(String(json.amount || 1000));
      setCurrency(json.currency || 'PKR');
      setEntryType(json.entryType || 'udhaar_given');
      setItemsSummary(json.itemsSummary || 'Trade goods & supplies');
      setDueDate(
        json.dueDate || new Date(Date.now() + 15 * 86400_000).toISOString().slice(0, 10)
      );
      setStage('review');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to parse voice recording.');
      setStage('capture');
    }
  }

  async function startRecording() {
    setErrorMsg(null);
    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices?.getUserMedia ||
      typeof MediaRecorder === 'undefined'
    ) {
      setErrorMsg(
        'Browser MediaRecorder / Microphone API is unavailable here. Enter a voice note or select a UTF-8 sample below.'
      );
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const preferredMime = selectSupportedMimeType();
      const recorder = preferredMime
        ? new MediaRecorder(stream, { mimeType: preferredMime })
        : new MediaRecorder(stream);

      mediaRecorderRef.current = recorder;
      chunksRef.current = [];
      const activeMime = recorder.mimeType || preferredMime || 'audio/webm';
      setAudioMimeType(activeMime);

      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        const audioCtx = new AudioCtx();
        audioContextRef.current = audioCtx;
        const source = audioCtx.createMediaStreamSource(stream);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 128;
        source.connect(analyser);
        const buffer = new Uint8Array(analyser.frequencyBinCount);

        const renderFrame = () => {
          const canvas = canvasRef.current;
          if (!canvas) return;
          const ctx = canvas.getContext('2d');
          if (!ctx) return;
          analyser.getByteFrequencyData(buffer);

          ctx.clearRect(0, 0, canvas.width, canvas.height);
          const barCount = Math.min(40, buffer.length);
          const barWidth = canvas.width / barCount;
          for (let i = 0; i < barCount; i++) {
            const magnitude = buffer[i] / 255;
            const barHeight = Math.max(4, magnitude * (canvas.height - 10));
            const x = i * barWidth;
            const y = (canvas.height - barHeight) / 2;
            ctx.fillStyle = magnitude > 0.55 ? '#F59E0B' : '#0F766E';
            ctx.fillRect(x + 1, y, Math.max(2, barWidth - 3), barHeight);
          }
          rafRef.current = window.requestAnimationFrame(renderFrame);
        };
        rafRef.current = window.requestAnimationFrame(renderFrame);
      }

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      recorder.onstop = async () => {
        stopMediaResources();
        setRecording(false);
        const blob = new Blob(chunksRef.current, { type: activeMime });
        chunksRef.current = [];

        if (blob.size < 64) {
          setErrorMsg('Recorded clip was too short. Hold Record for at least 1 second.');
          return;
        }

        if (audioUrl) {
          URL.revokeObjectURL(audioUrl);
        }
        const nextUrl = URL.createObjectURL(blob);
        setAudioUrl(nextUrl);

        try {
          const audioBase64 = await blobToBase64(blob);
          await sendToAiParse({
            audioBase64,
            mimeType: activeMime,
            transcript: supplementalNote.trim() || undefined,
            languageHint: language,
          });
        } catch (err) {
          setErrorMsg(err instanceof Error ? err.message : 'Failed to process audio clip.');
          setStage('capture');
        }
      };

      recorder.onerror = () => {
        stopMediaResources();
        setRecording(false);
        setErrorMsg('MediaRecorder stopped unexpectedly. Try recording again or type below.');
      };

      recorder.start(250);
      setRecording(true);
      setSecondsElapsed(0);
      timerRef.current = window.setInterval(() => {
        setSecondsElapsed((prev) => {
          if (prev + 1 >= 45) {
            stopRecording();
            return 45;
          }
          return prev + 1;
        });
      }, 1000);
    } catch (err) {
      stopMediaResources();
      setRecording(false);
      setErrorMsg(
        err instanceof Error
          ? `Microphone permission or device error (${err.message}). You can still parse any voice/text note below.`
          : 'Microphone access denied. You can still type or test a UTF-8 preset below.'
      );
    }
  }

  function stopRecording() {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        stopMediaResources();
        setRecording(false);
      }
    }
  }

  async function handleConfirmAndSeal(e: React.FormEvent) {
    e.preventDefault();
    setErrorMsg(null);

    const parsedAmount = Number(amount);
    if (!Number.isFinite(parsedAmount) || parsedAmount <= 0) {
      setErrorMsg('Amount must be greater than 0.');
      return;
    }
    if (counterparty.trim().length < 2) {
      setErrorMsg('Counterparty name must be at least 2 characters.');
      return;
    }

    setSubmitting(true);
    const isTradeContract = entryType === 'murabaha_contract' || entryType === 'salam_contract';
    const payload = {
      branchId,
      entryType,
      creditorName: entryType === 'udhaar_taken' ? counterparty.trim() : businessName,
      debtorName: entryType === 'udhaar_taken' ? businessName : counterparty.trim(),
      amount: parsedAmount,
      currency,
      costBasisUsd: isTradeContract ? Number(costBasisUsd) || 0 : undefined,
      murabahaMarkupUsd: isTradeContract ? Number(murabahaMarkupUsd) || 0 : undefined,
      itemsSummary: itemsSummary.trim() || 'Voice-captured trade contract',
      dueDate: entryType === 'cash_sale' ? null : dueDate || null,
      language: detectedLang,
      voiceTranscript: recognizedTranscript.trim() || null,
      cognitiveHumanScore: 96,
      interestRate: 0,
    };

    if (simulateOffline || (typeof navigator !== 'undefined' && !navigator.onLine)) {
      enqueueOfflineAction({
        endpoint: '/api/contracts',
        method: 'POST',
        body: payload,
        idempotencyKey: `off_voice_${Date.now()}`,
        label: `${counterparty.trim()} (${formatCurrency(parsedAmount, currency)})`,
      });
      onQueuedOffline();
      setSubmitting(false);
      onClose();
      return;
    }

    try {
      const res = await apiFetch('/api/contracts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as {
        error?: string;
        entry?: LedgerEntry;
        chainVerification?: ChainVerificationResult;
      };
      if (!res.ok || !json.entry) {
        setErrorMsg(json.error || 'Transaction rejected by Zero-Riba Shariah Gate.');
        return;
      }

      setSealedEntry(json.entry);
      setStage('sealed');
      speakMultilingual(
        `${json.entry.debtorName}, ${json.entry.amount} ${json.entry.currency} sealed on BolMizan ledger.`,
        detectedLang
      );
      await onCompleted();
    } catch {
      setErrorMsg('Network error submitting contract to WAL ledger.');
    } finally {
      setSubmitting(false);
    }
  }

  function resetToCapture() {
    setErrorMsg(null);
    setSealedEntry(null);
    setStage('capture');
  }

  const fieldCls =
    'w-full rounded-lg border border-stone-200 bg-[#F8F7F3] px-3.5 py-2 text-sm text-stone-900 placeholder:text-stone-400 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100 dark:focus:border-teal-400';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/70 p-4 backdrop-blur-sm dark:bg-[#0B1117]/80"
      role="dialog"
      aria-modal="true"
      aria-label="Voice Transaction Capture & Prepopulated Confirmation"
    >
      <div className="veritas-enter w-full max-w-2xl overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-[#111922]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-200 px-6 py-4 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-teal-700/25 bg-teal-50 text-teal-700 dark:border-teal-500/30 dark:bg-teal-950/50 dark:text-teal-400">
              <Mic className="h-4 w-4" />
            </div>
            <div>
              <h2 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
                Voice-to-Hisab Capture Studio
              </h2>
              <p className="text-xs text-stone-500 dark:text-slate-400">
                MediaRecorder API → <span className="font-mono">/api/ai-parse</span> → Prepopulated 0% Riba Review
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close voice capture modal"
            className="rounded-lg p-1.5 text-stone-500 transition-colors hover:bg-stone-100 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="max-h-[82vh] overflow-y-auto p-6">
          {errorMsg && (
            <div className="mb-4 rounded-xl border border-[#9B1C2E]/30 bg-rose-50 px-4 py-3 text-xs text-[#9B1C2E] dark:border-rose-500/30 dark:bg-rose-950/30 dark:text-rose-200">
              {errorMsg}
            </div>
          )}

          {/* STAGE 1: CAPTURE */}
          {stage === 'capture' && (
            <div className="space-y-5">
              <div className="rounded-xl border border-stone-200 bg-[#F8F7F3] p-5 dark:border-slate-800 dark:bg-[#0B1117]">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-semibold text-stone-800 dark:text-stone-200">
                      {recording ? (
                        <span className="h-2.5 w-2.5 rounded-full animate-pulse bg-rose-500" />
                      ) : (
                        <Mic className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
                      )}
                      <span>
                        {recording
                          ? `Recording Live Audio (${audioMimeType.split(';')[0]})`
                          : 'Ready to Record Voice Clip (اردو · سنڌي · العربية · EN)'}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-stone-500 dark:text-slate-400">
                      Speak customer name, amount, currency, and goods. Audio stops automatically at 45s.
                    </p>
                  </div>

                  <div className="font-mono text-lg font-bold text-teal-700 tabular-nums dark:text-teal-400">
                    {String(Math.floor(secondsElapsed / 60)).padStart(2, '0')}:
                    {String(secondsElapsed % 60).padStart(2, '0')}
                  </div>
                </div>

                <canvas
                  ref={canvasRef}
                  width={560}
                  height={72}
                  className="mt-4 h-18 w-full rounded-xl border border-stone-200 bg-white dark:border-slate-800 dark:bg-[#111922]"
                />

                <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                  {!recording ? (
                    <button
                      type="button"
                      onClick={startRecording}
                      className="inline-flex shrink-0 items-center gap-2 rounded-lg bg-teal-700 px-4 py-2.5 text-xs font-semibold whitespace-nowrap text-white transition-colors hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                    >
                      <Mic className="h-4 w-4" />
                      <span>Start Voice Recording</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={stopRecording}
                      className="inline-flex shrink-0 items-center gap-2 rounded-lg bg-[#9B1C2E] px-4 py-2.5 text-xs font-semibold whitespace-nowrap text-white transition-colors hover:bg-rose-800"
                    >
                      <Square className="h-3.5 w-3.5 fill-current" />
                      <span>Stop &amp; Parse via /api/ai-parse</span>
                    </button>
                  )}

                  {audioUrl && !recording && (
                    <audio controls src={audioUrl} className="h-9 max-w-[260px]" />
                  )}
                </div>
              </div>

              <div className="space-y-3 rounded-xl border border-stone-200 bg-white p-4 dark:border-slate-800 dark:bg-[#0B1117]">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                    Optional Note or Hardware-Free UTF-8 Voice Simulation
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {QUICK_SAMPLES.map((sample) => (
                      <button
                        key={sample.label}
                        type="button"
                        onClick={() => setSupplementalNote(sample.text)}
                        className="shrink-0 rounded-md border border-stone-200 bg-[#F8F7F3] px-2.5 py-1 text-[11px] font-medium whitespace-nowrap text-stone-700 transition-colors hover:border-teal-600/40 hover:bg-teal-50/50 dark:border-slate-800 dark:bg-[#111922] dark:text-stone-200 dark:hover:border-teal-500/40"
                      >
                        {sample.label}
                      </button>
                    ))}
                  </div>
                </div>

                <textarea
                  rows={2}
                  value={supplementalNote}
                  onChange={(e) => setSupplementalNote(e.target.value)}
                  placeholder="e.g. Bilal Traders ko 28,500 PKR Basmati Rice udhaar diya — or click a UTF-8 sample above"
                  className={fieldCls}
                />

                <div className="flex justify-end">
                  <button
                    type="button"
                    disabled={recording || supplementalNote.trim().length < 3}
                    onClick={() =>
                      sendToAiParse({
                        transcript: supplementalNote.trim(),
                        languageHint: language,
                      })
                    }
                    className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-teal-700 px-4 py-2 text-xs font-semibold whitespace-nowrap text-white transition-colors hover:bg-teal-800 disabled:cursor-not-allowed disabled:opacity-45 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    <span>Parse Text via /api/ai-parse</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STAGE 2: PARSING */}
          {stage === 'parsing' && (
            <div className="flex flex-col items-center justify-center gap-3 py-12 text-center">
              <Loader2 className="h-9 w-9 animate-spin text-teal-700 dark:text-teal-400" />
              <div className="font-display text-sm font-semibold text-stone-900 dark:text-stone-100">
                Sending Audio Clip to /api/ai-parse…
              </div>
              <p className="max-w-md text-xs text-stone-500 dark:text-slate-400">
                Transcribing Urdu, Sindhi, Arabic, or English voice speech and extracting structured Shariah ledger details.
              </p>
            </div>
          )}

          {/* STAGE 3: PREPOPULATED REVIEW */}
          {stage === 'review' && (
            <form onSubmit={handleConfirmAndSeal} className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-teal-700/25 bg-teal-50 px-4 py-2.5 text-xs dark:border-teal-500/30 dark:bg-teal-950/35">
                <div className="flex items-center gap-2 font-medium text-teal-800 dark:text-teal-300">
                  <Sparkles className="h-4 w-4 shrink-0" />
                  <span>
                    Prepopulated via <span className="font-mono font-semibold">{parserEngine}</span> · Detected{' '}
                    <span className="font-mono font-semibold">{detectedLang.toUpperCase()}</span>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={resetToCapture}
                  className="inline-flex shrink-0 items-center gap-1 rounded-md border border-teal-700/25 bg-white px-2.5 py-1 text-[11px] font-semibold whitespace-nowrap text-teal-800 hover:bg-teal-50 dark:border-teal-500/30 dark:bg-[#0B1117] dark:text-teal-300 dark:hover:bg-slate-800"
                >
                  <RotateCcw className="h-3 w-3" />
                  <span>Re-record</span>
                </button>
              </div>

              {audioUrl && (
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-stone-200 bg-[#F8F7F3] px-3.5 py-2 dark:border-slate-800 dark:bg-[#0B1117]">
                  <span className="inline-flex items-center gap-1.5 text-xs font-medium text-stone-600 dark:text-slate-300">
                    <Volume2 className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
                    Captured Voice Clip
                  </span>
                  <audio controls src={audioUrl} className="h-8 max-w-[260px]" />
                </div>
              )}

              <div>
                <label className="mb-1 block text-xs font-medium text-stone-600 dark:text-slate-300">
                  Recognized Transcript (UTF-8)
                </label>
                <input
                  type="text"
                  value={recognizedTranscript}
                  onChange={(e) => setRecognizedTranscript(e.target.value)}
                  className={fieldCls}
                />
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-medium text-stone-600 dark:text-slate-300">
                    Counterparty Name
                  </label>
                  <input
                    type="text"
                    required
                    value={counterparty}
                    onChange={(e) => setCounterparty(e.target.value)}
                    className={fieldCls}
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-stone-600 dark:text-slate-300">
                    Shariah Entry Type
                  </label>
                  <select
                    value={entryType}
                    onChange={(e) => setEntryType(e.target.value as LedgerEntryType)}
                    className={fieldCls}
                  >
                    {ENTRY_TYPE_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-stone-600 dark:text-slate-300">
                    Amount
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className={`${fieldCls} font-mono tabular-nums`}
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-stone-600 dark:text-slate-300">
                    Currency
                  </label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                    className={fieldCls}
                  >
                    {CURRENCY_OPTIONS.map((code) => (
                      <option key={code} value={code}>
                        {code} — {CURRENCY_METADATA[code].name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-stone-600 dark:text-slate-300">
                    Corridor Branch
                  </label>
                  <select
                    value={branchId}
                    onChange={(e) => setBranchId(e.target.value as Exclude<BranchId, 'all'>)}
                    className={fieldCls}
                  >
                    <option value="sakrand_hq">Sakrand HQ (Sindh, PK)</option>
                    <option value="karachi_port">Karachi Port Export Hub</option>
                    <option value="riyadh_hub">Riyadh GCC Hub (SAR)</option>
                    <option value="dubai_marina">Dubai Marina Hub (AED)</option>
                  </select>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-stone-600 dark:text-slate-300">
                    Due Date (Quran 2:282)
                  </label>
                  <input
                    type="date"
                    disabled={entryType === 'cash_sale'}
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className={`${fieldCls} disabled:opacity-50`}
                  />
                </div>
              </div>

              {(entryType === 'murabaha_contract' || entryType === 'salam_contract') && (
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-stone-600 dark:text-slate-300">
                      Disclosed Cost Basis (USD)
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="any"
                      value={costBasisUsd}
                      onChange={(e) => setCostBasisUsd(e.target.value)}
                      className={`${fieldCls} font-mono tabular-nums`}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-stone-600 dark:text-slate-300">
                      Fixed Murabaha Markup (USD)
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="any"
                      value={murabahaMarkupUsd}
                      onChange={(e) => setMurabahaMarkupUsd(e.target.value)}
                      className={`${fieldCls} font-mono tabular-nums`}
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="mb-1 block text-xs font-medium text-stone-600 dark:text-slate-300">
                  Goods / Contract Summary
                </label>
                <input
                  type="text"
                  required
                  value={itemsSummary}
                  onChange={(e) => setItemsSummary(e.target.value)}
                  className={fieldCls}
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-stone-200 pt-4 dark:border-slate-800">
                <div className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-700 dark:text-teal-400">
                  <ShieldCheck className="h-4 w-4" />
                  <span>0% Riba Enforced · SHA-256 Merkle Seal</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="shrink-0 rounded-lg border border-stone-200 px-4 py-2 text-xs font-semibold whitespace-nowrap text-stone-700 hover:bg-stone-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-teal-700 px-4 py-2 text-xs font-semibold whitespace-nowrap text-white hover:bg-teal-800 disabled:opacity-50 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                  >
                    {submitting ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <CheckCircle2 className="h-3.5 w-3.5" />
                    )}
                    <span>{submitting ? 'Sealing Block…' : 'Confirm & Seal onto Ledger'}</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* STAGE 4: SEALED CONFIRMATION */}
          {stage === 'sealed' && sealedEntry && (
            <div className="space-y-4 py-4 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-50 text-teal-700 dark:bg-teal-950/50 dark:text-teal-400">
                <CheckCircle2 className="h-7 w-7" />
              </div>
              <div>
                <div className="font-display text-base font-bold text-stone-900 dark:text-stone-100">
                  Block #{sealedEntry.index} Sealed onto SHA-256 Ledger
                </div>
                <p className="mt-1 text-xs text-stone-500 dark:text-slate-400">
                  {sealedEntry.debtorName} · <span className="tabular-nums">{formatCurrency(sealedEntry.amount, sealedEntry.currency)}</span> ·{' '}
                  <span className="font-mono">{sealedEntry.reference}</span>
                </p>
              </div>

              <div className="rounded-xl border border-stone-200 bg-[#F8F7F3] p-3 font-mono text-[11px] break-all text-teal-700 dark:border-slate-800 dark:bg-[#0B1117] dark:text-teal-400">
                SHA-256: {sealedEntry.hash}
              </div>

              <div className="flex justify-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={resetToCapture}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-stone-200 px-4 py-2 text-xs font-semibold whitespace-nowrap text-stone-700 hover:bg-stone-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <Mic className="h-3.5 w-3.5" />
                  <span>Record Another</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="shrink-0 rounded-lg bg-teal-700 px-4 py-2 text-xs font-semibold whitespace-nowrap text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
