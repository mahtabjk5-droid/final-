import { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  Download,
  EyeOff,
  Link2,
  Lock,
  Plus,
  QrCode,
  RotateCcw,
} from 'lucide-react';
import type {
  BranchId,
  CurrencyCode,
  FxRateSnapshot,
  PaymentLinkRecord,
  PaymentRailId,
  PaymentTransaction,
  RailCategory,
} from '../../shared/types';
import { CURRENCY_METADATA, GLOBAL_PAYMENT_RAILS, RAIL_BY_ID } from '../../shared/rails';
import { downloadTransactionsCsv, formatCurrency } from '../utils/formatters';
import { apiFetch } from '../utils/sessionClient';
import { enqueueOfflineAction, renderQrDataUrl } from '../utils/ttsAndOffline';

interface GlobalRailsCheckoutViewProps {
  fx: FxRateSnapshot;
  transactions: PaymentTransaction[];
  paymentLinks: PaymentLinkRecord[];
  killSwitchFrozen: boolean;
  simulateOffline: boolean;
  onQueuedOffline: () => void;
}

const SAMPLE_PRESETS: Record<
  PaymentRailId,
  { instrument: string; currency: CurrencyCode; country: string }
> = {
  sbp_raast: { instrument: 'PK36SCBL0000001123456702', currency: 'PKR', country: 'Pakistan' },
  jazzcash: { instrument: '03001234567', currency: 'PKR', country: 'Pakistan' },
  easypaisa: { instrument: '03459876543', currency: 'PKR', country: 'Pakistan' },
  onelink_1bill: { instrument: '1001248901234567', currency: 'PKR', country: 'Pakistan' },
  sadapay_nayapay: { instrument: '03125558899', currency: 'PKR', country: 'Pakistan' },
  saudi_mada: { instrument: '4242424242424242', currency: 'SAR', country: 'Saudi Arabia' },
  stc_pay: { instrument: '+966501234567', currency: 'SAR', country: 'Saudi Arabia' },
  uae_aani: { instrument: '+971501234567', currency: 'AED', country: 'United Arab Emirates' },
  stripe_card: { instrument: '4242 4242 4242 4242', currency: 'USD', country: 'United States' },
  apple_pay: { instrument: 'apay_tok_biometric_9821', currency: 'USD', country: 'United Kingdom' },
  google_pay: { instrument: 'gpay_tok_ecv2_4410', currency: 'EUR', country: 'Germany' },
  paypal: { instrument: 'buyer@enterprise.com', currency: 'USD', country: 'Canada' },
  sepa_instant: { instrument: 'DE89370400440532013000', currency: 'EUR', country: 'Germany' },
  fednow_ach: { instrument: '021000021:984002145', currency: 'USD', country: 'United States' },
  uk_faster_payments: { instrument: '20-00-00:55779911', currency: 'GBP', country: 'United Kingdom' },
  india_upi: { instrument: 'ananya.sharma@okicici', currency: 'INR', country: 'India' },
  brazil_pix: { instrument: 'lucas.silva@pix.br', currency: 'BRL', country: 'Brazil' },
  wise_corridor: { instrument: '@meridiantrade', currency: 'USD', country: 'United Kingdom' },
  mpesa: { instrument: '+254712345678', currency: 'KES', country: 'Kenya' },
  usdc_base: {
    instrument: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
    currency: 'USD',
    country: 'Singapore',
  },
  alipay_wechat: { instrument: 'wxp_289401849201', currency: 'CNY', country: 'China' },
};

export function GlobalRailsCheckoutView({
  fx,
  transactions,
  paymentLinks,
  killSwitchFrozen,
  simulateOffline,
  onQueuedOffline,
}: GlobalRailsCheckoutViewProps) {
  const [category, setCategory] = useState<'All' | RailCategory>('All');
  const [railId, setRailId] = useState<PaymentRailId>('sbp_raast');
  const [currency, setCurrency] = useState<CurrencyCode>('PKR');
  const [amount, setAmount] = useState('25000');
  const [instrument, setInstrument] = useState(SAMPLE_PRESETS.sbp_raast.instrument);
  const [customerName, setCustomerName] = useState('Bilal Raza');
  const [customerEmail, setCustomerEmail] = useState('bilal@karachitrade.pk');
  const [customerCountry, setCustomerCountry] = useState('Pakistan');
  const [branchId, setBranchId] = useState<BranchId>('sakrand_hq');
  const [selectedLinkId, setSelectedLinkId] = useState<string | null>(null);
  const [utmSource, setUtmSource] = useState<string>('direct_checkout');
  const [utmCampaign, setUtmCampaign] = useState<string>('veritas_terminal');
  const [creatorHandle, setCreatorHandle] = useState<string>('');
  const [idempotencyKey, setIdempotencyKey] = useState(
    () => `idem_${Math.random().toString(36).slice(2, 10)}`
  );
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<PaymentTransaction | null>(null);
  const [qrImageUrl, setQrImageUrl] = useState<string | null>(null);
  const [stripeSessionMsg, setStripeSessionMsg] = useState<string | null>(null);
  const [cardImgFailed, setCardImgFailed] = useState(false);
  const [hubImgFailed, setHubImgFailed] = useState(false);

  const [showLinkForm, setShowLinkForm] = useState(false);
  const [linkTitle, setLinkTitle] = useState('Gulf Wholesale Basmati Drop');
  const [linkDesc, setLinkDesc] = useState('Instant Shariah-compliant settlement across 21 global rails');
  const [linkAmount, setLinkAmount] = useState('450');
  const [linkCurrency, setLinkCurrency] = useState<CurrencyCode>('USD');
  const [linkUtm, setLinkUtm] = useState('whatsapp_vip');
  const [creatingLink, setCreatingLink] = useState(false);

  const selectedRail = RAIL_BY_ID[railId];
  const filteredRails = useMemo(
    () =>
      GLOBAL_PAYMENT_RAILS.filter((r) => category === 'All' || r.category === category),
    [category]
  );

  useEffect(() => {
    if (!receipt?.qrPayload) {
      setQrImageUrl(null);
      return;
    }
    renderQrDataUrl(receipt.qrPayload).then(setQrImageUrl).catch(() => setQrImageUrl(null));
  }, [receipt?.qrPayload]);

  function handleSelectRail(id: PaymentRailId) {
    setRailId(id);
    setErrorMsg(null);
    const rail = RAIL_BY_ID[id];
    const preset = SAMPLE_PRESETS[id];
    if (!rail.currencies.includes(currency)) {
      setCurrency(preset.currency);
    }
    setInstrument(preset.instrument);
    setCustomerCountry(preset.country);
  }

  function handleLoadPaymentLink(lnk: PaymentLinkRecord) {
    setSelectedLinkId(lnk.id);
    setAmount(String(lnk.amount));
    setCurrency(lnk.currency);
    setUtmSource(lnk.utmSource);
    setUtmCampaign(lnk.utmCampaign);
    setCreatorHandle(lnk.creatorHandle);
    setIdempotencyKey(`idem_${Math.random().toString(36).slice(2, 10)}`);
    if (!selectedRail.currencies.includes(lnk.currency)) {
      const compatible = GLOBAL_PAYMENT_RAILS.find((r) => r.currencies.includes(lnk.currency));
      if (compatible) {
        setRailId(compatible.id);
        setInstrument(SAMPLE_PRESETS[compatible.id].instrument);
        setCustomerCountry(SAMPLE_PRESETS[compatible.id].country);
      }
    }
  }

  async function handleCreateLink(e: React.FormEvent) {
    e.preventDefault();
    setCreatingLink(true);
    try {
      const res = await apiFetch('/api/payment-links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: linkTitle,
          description: linkDesc,
          amount: Number(linkAmount),
          currency: linkCurrency,
          allowedCategories: ['Pakistan & MENA', 'Global Cards & Wallets', 'International Bank Rails'],
          utmSource: linkUtm,
          utmCampaign: 'veritas_growth',
          creatorHandle: '@bolmizan_hq',
        }),
      });
      if (res.ok) {
        setShowLinkForm(false);
      }
    } finally {
      setCreatingLink(false);
    }
  }

  async function handleCheckout(e: React.FormEvent) {
    e.preventDefault();
    setErrorMsg(null);
    setSubmitting(true);

    const payload = {
      amount: Number(amount),
      currency,
      railId,
      instrumentInput: instrument,
      customerName,
      customerEmail,
      customerCountry,
      branchId,
      paymentLinkId: selectedLinkId,
      utmSource,
      utmCampaign,
      creatorHandle: creatorHandle || null,
    };

    if (simulateOffline || !navigator.onLine) {
      enqueueOfflineAction({
        endpoint: '/api/payments/checkout',
        method: 'POST',
        body: payload,
        idempotencyKey,
        label: `${selectedRail.shortName} ${formatCurrency(Number(amount), currency)}`,
      });
      onQueuedOffline();
      setErrorMsg('Offline Mode: Payment authorization queued for automatic sync.');
      setSubmitting(false);
      return;
    }

    try {
      const res = await apiFetch('/api/payments/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Idempotency-Key': idempotencyKey,
        },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as {
        error?: string;
        transaction?: PaymentTransaction;
      };
      if (!res.ok || !json.transaction) {
        setErrorMsg(json.error || 'Checkout failed.');
        return;
      }
      setReceipt(json.transaction);
      setIdempotencyKey(`idem_${Math.random().toString(36).slice(2, 10)}`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Network error');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDownloadExport(endpoint: string, filename: string) {
    setErrorMsg(null);
    try {
      const res = await apiFetch(endpoint);
      if (!res.ok) {
        setErrorMsg(`Export failed (${res.status}). Verify your active session and retry.`);
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
    } catch {
      setErrorMsg('Unable to download compliance export while offline.');
    }
  }

  async function handleCreateStripeSession() {
    setStripeSessionMsg(null);
    const res = await apiFetch('/api/payments/stripe-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        amount: Number(amount) || 100,
        currency,
        title: `BolMizan ${selectedRail.shortName} Clearing`,
      }),
    });
    const json = (await res.json()) as {
      mode?: string;
      sessionId?: string;
      signature?: string;
      error?: string;
    };
    if (!res.ok) {
      setStripeSessionMsg(json.error || 'Stripe session failed.');
      return;
    }
    setStripeSessionMsg(
      `Stripe Session ${json.sessionId} (${json.mode}${json.signature ? ` · sig:${json.signature}` : ''}) ready.`
    );
  }

  const usdEq = (Number(amount) || 0) / (fx.rates[currency] || 1);
  const inputCls =
    'mt-1 w-full rounded-xl border border-stone-200 bg-[#F8F7F3] px-3.5 py-2 text-sm text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100 dark:focus:border-teal-400';

  return (
    <div className="space-y-6 veritas-enter">
      {killSwitchFrozen && (
        <div className="rounded-xl border border-[#9B1C2E]/35 bg-[#9B1C2E]/10 px-5 py-3 text-sm font-semibold text-[#9B1C2E] dark:text-rose-300">
          MASTER AI KILL-SWITCH ACTIVE: Outbound payment rails are currently frozen. Unlock in Security &amp; Anti-Scam.
        </div>
      )}

      {/* Sakrand-to-World Astrolabe Trade Radar */}
      <div className="overflow-hidden rounded-xl border border-teal-500/25 bg-[#0D2327] p-5 text-white">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="font-editorial text-lg font-bold text-amber-300">
            Live Sakrand-to-World Trade Astrolabe · Active Corridor: {selectedRail.shortName} ({customerCountry})
          </div>
          <div className="font-mono text-[11px] text-teal-300">
            SLA {selectedRail.settlementSla} · Fee {selectedRail.baseFeePct}% · {selectedRail.currencies.join('/')}
          </div>
        </div>
        <svg viewBox="0 0 640 96" className="mt-2 h-20 w-full">
          <circle cx="320" cy="48" r="36" fill="none" stroke="#F59E0B" strokeOpacity="0.25" strokeDasharray="3 3" className="astrolabe-sweep" />
          {[
            { city: 'Karachi', x: 260, y: 66 },
            { city: 'Riyadh', x: 185, y: 52 },
            { city: 'Dubai', x: 215, y: 34 },
            { city: 'London', x: 105, y: 24 },
            { city: 'Mumbai', x: 410, y: 64 },
            { city: 'Nairobi', x: 475, y: 74 },
            { city: 'New York', x: 565, y: 28 },
          ].map((hub) => {
            const activeTarget =
              customerCountry.toLowerCase().includes(hub.city.toLowerCase()) ||
              (hub.city === 'Riyadh' && customerCountry.includes('Saudi')) ||
              (hub.city === 'Dubai' && customerCountry.includes('Emirates')) ||
              (hub.city === 'London' && customerCountry.includes('United Kingdom')) ||
              (hub.city === 'New York' && customerCountry.includes('United States')) ||
              (hub.city === 'Karachi' && customerCountry.includes('Pakistan'));
            return (
              <g key={hub.city}>
                <path
                  d={`M 320 48 Q ${(320 + hub.x) / 2} 14 ${hub.x} ${hub.y}`}
                  fill="none"
                  stroke={activeTarget ? '#F59E0B' : '#2DD4BF'}
                  strokeWidth={activeTarget ? '2.1' : '1.1'}
                  strokeOpacity={activeTarget ? '0.95' : '0.45'}
                  className="arc-travel"
                />
                <circle cx={hub.x} cy={hub.y} r={activeTarget ? 4.2 : 2.8} fill={activeTarget ? '#F59E0B' : '#2DD4BF'} />
                <text x={hub.x} y={hub.y + 12} textAnchor="middle" fill="#CCFBF1" fontSize="9" fontFamily="monospace">
                  {hub.city}
                </text>
              </g>
            );
          })}
          <circle cx="320" cy="48" r="5.5" fill="#F59E0B" stroke="#FEF3C7" strokeWidth="1.5" />
          <text x="320" y="68" textAnchor="middle" fill="#FDE68A" fontSize="9" fontWeight="bold" fontFamily="sans-serif">
            Sakrand HQ
          </text>
        </svg>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* 21-Rail Checkout Form */}
        <form
          onSubmit={handleCheckout}
          className="space-y-5 rounded-xl border border-stone-200 bg-white p-6 lg:col-span-7 dark:border-slate-800 dark:bg-[#111922]"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
                21-Rail Global &amp; Regional Payment Orchestration
              </h2>
              <p className="mt-0.5 text-xs text-stone-500 dark:text-stone-400">
                SBP Raast EMVCo QR, ZATCA Phase-2 TLV, JazzCash, Easypaisa, 1LINK, Stripe, SEPA, FedNow, UPI, and USDC
              </p>
            </div>
            {selectedLinkId && (
              <button
                type="button"
                onClick={() => setSelectedLinkId(null)}
                className="rounded-lg border border-teal-600/35 bg-teal-700/10 px-2.5 py-1 text-[11px] font-medium text-teal-800 dark:text-teal-300"
              >
                Linked: {utmSource} (Clear)
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
                Amount
              </label>
              <input
                type="number"
                required
                min="1"
                step="any"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={`${inputCls} font-mono`}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
                Currency (USD eq: {formatCurrency(usdEq, 'USD')})
              </label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                className={inputCls}
              >
                {(Object.keys(CURRENCY_METADATA) as CurrencyCode[]).map((c) => (
                  <option key={c} value={c}>
                    {c} — {CURRENCY_METADATA[c].name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
                Clearing Hub
              </label>
              <select
                value={branchId}
                onChange={(e) => setBranchId(e.target.value as BranchId)}
                className={inputCls}
              >
                <option value="sakrand_hq">Sakrand HQ (Sindh)</option>
                <option value="karachi_port">Karachi Port</option>
                <option value="riyadh_hub">Riyadh Hub (GCC)</option>
                <option value="dubai_marina">Dubai Marina</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 rounded-xl border border-stone-200 bg-[#F8F7F3] p-2.5 font-mono text-[11px] tabular-nums sm:grid-cols-6 dark:border-slate-800 dark:bg-[#0B1117]">
            {(['PKR', 'SAR', 'AED', 'USD', 'EUR', 'GBP'] as const).map((target) => {
              const converted = usdEq * (fx.rates[target] || 1);
              return (
                <div key={target} className="truncate">
                  <span className="text-stone-500">{target} </span>
                  <span className="font-semibold text-teal-700 dark:text-teal-400">
                    {converted.toLocaleString(undefined, {
                      maximumFractionDigits: target === 'PKR' ? 0 : 2,
                    })}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Rail Category Tabs */}
          <div className="flex flex-wrap gap-1 rounded-xl border border-stone-200 bg-[#F8F7F3] p-1 dark:border-slate-800 dark:bg-[#0B1117]">
            {(
              [
                'All',
                'Pakistan & MENA',
                'Global Cards & Wallets',
                'International Bank Rails',
                'Web3 & APAC',
              ] as const
            ).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategory(cat)}
                className={`rounded-lg px-2.5 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                  category === cat
                    ? 'bg-teal-700 text-white shadow-xs dark:bg-teal-500 dark:text-slate-950'
                    : 'text-stone-600 hover:text-stone-900 dark:text-stone-400 dark:hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Rails Grid */}
          <div className="grid max-h-64 grid-cols-1 gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
            {filteredRails.map((rail) => {
              const active = rail.id === railId;
              return (
                <button
                  key={rail.id}
                  type="button"
                  onClick={() => handleSelectRail(rail.id)}
                  className={`flex flex-col items-start rounded-xl border p-3 text-left transition-colors ${
                    active
                      ? 'border-teal-600 bg-teal-700/8 dark:border-teal-400 dark:bg-teal-500/12'
                      : 'border-stone-200 bg-[#F8F7F3] hover:border-teal-600/40 dark:border-slate-800 dark:bg-[#0B1117]'
                  }`}
                >
                  <div className="flex w-full items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-stone-900 dark:text-stone-100">
                      {rail.shortName}
                    </span>
                    <span className="font-mono text-[11px] text-stone-500 dark:text-stone-400">
                      {rail.baseFeePct}%
                    </span>
                  </div>
                  <div className="mt-1 text-[11px] text-stone-500 dark:text-stone-400">
                    {rail.settlementSla} · {rail.currencies.slice(0, 3).join('/')}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="rounded-xl border border-stone-200 bg-[#F8F7F3] p-4 dark:border-slate-800 dark:bg-[#0B1117]">
            <div className="flex items-center justify-between gap-2">
              <label className="text-xs font-medium text-stone-700 dark:text-stone-300">
                {selectedRail.inputLabel}
              </label>
              <button
                type="button"
                onClick={() => setInstrument(SAMPLE_PRESETS[railId].instrument)}
                className="text-xs font-semibold text-teal-700 hover:underline dark:text-teal-400"
              >
                Fill valid credential
              </button>
            </div>
            <input
              type="text"
              required
              value={instrument}
              onChange={(e) => setInstrument(e.target.value)}
              className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 font-mono text-sm text-stone-900 focus:border-teal-600 focus:outline-none dark:border-slate-800 dark:bg-[#111922] dark:text-stone-100"
            />
            <p className="mt-1 text-xs text-stone-500 dark:text-stone-400">
              {selectedRail.inputHint}
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <input
              type="text"
              required
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="Customer Name"
              className={inputCls}
            />
            <input
              type="email"
              required
              value={customerEmail}
              onChange={(e) => setCustomerEmail(e.target.value)}
              placeholder="Receipt Email"
              className={inputCls}
            />
            <input
              type="text"
              required
              value={customerCountry}
              onChange={(e) => setCustomerCountry(e.target.value)}
              placeholder="Country"
              className={inputCls}
            />
          </div>

          <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400">
            <span className="inline-flex items-center gap-1.5">
              <Lock className="h-3.5 w-3.5" />
              <span>Idempotency-Key: </span>
              <code className="font-mono text-stone-800 dark:text-stone-200">{idempotencyKey}</code>
            </span>
            <button
              type="button"
              onClick={() => setIdempotencyKey(`idem_${Math.random().toString(36).slice(2, 10)}`)}
              className="inline-flex items-center gap-1 font-medium hover:text-stone-900 dark:hover:text-stone-200"
            >
              <RotateCcw className="h-3 w-3" />
              <span>Rotate key</span>
            </button>
          </div>

          {errorMsg && (
            <div className="rounded-xl border border-[#9B1C2E]/30 bg-[#9B1C2E]/10 px-3.5 py-2.5 text-xs text-[#9B1C2E] dark:text-rose-300">
              {errorMsg}
            </div>
          )}

          {stripeSessionMsg && (
            <div className="rounded-xl border border-teal-600/30 bg-teal-700/10 px-3.5 py-2 font-mono text-[11px] text-teal-800 dark:text-teal-300">
              {stripeSessionMsg}
            </div>
          )}

          <div className="flex flex-wrap gap-2">
            <button
              type="submit"
              disabled={submitting || killSwitchFrozen}
              className="flex-1 rounded-xl bg-teal-700 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-50 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
            >
              {submitting
                ? 'Clearing Payment...'
                : `Clear ${formatCurrency(Number(amount) || 0, currency)} via ${selectedRail.shortName}`}
            </button>
            <button
              type="button"
              disabled={killSwitchFrozen}
              onClick={handleCreateStripeSession}
              className="rounded-xl border border-stone-200 bg-[#F8F7F3] px-4 py-3 text-xs font-semibold text-stone-800 hover:bg-stone-100 disabled:opacity-50 dark:border-slate-800 dark:bg-[#0B1117] dark:text-teal-300 dark:hover:bg-slate-800"
            >
              Stripe Session
            </button>
          </div>
        </form>

        {/* Right: Titanium Terminal Visual, Live QR Preview & Payment Links */}
        <div className="space-y-5 lg:col-span-5">
          <div className="overflow-hidden rounded-xl border border-stone-200 bg-white dark:border-slate-800 dark:bg-[#111922]">
            <div className="relative h-36 overflow-hidden bg-[#0D2327]">
              {!cardImgFailed && (
                <img
                  src="/src/assets/images/meridian_card_metal_1794551163480.jpg"
                  alt="Meridian Titanium Clearing Instrument"
                  referrerPolicy="no-referrer"
                  onError={() => setCardImgFailed(true)}
                  className="h-full w-full object-cover opacity-55"
                />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0D2327] via-[#0D2327]/65 to-transparent" />
              <div className="absolute inset-0 flex flex-col justify-between p-4 text-white">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono text-teal-300">{selectedRail.shortName}</span>
                  <QrCode className="h-4 w-4 text-teal-300" />
                </div>
                <div>
                  <div className="font-mono text-lg font-bold tabular-nums">
                    {formatCurrency(Number(amount) || 0, currency)}
                  </div>
                  <div className="text-[11px] text-teal-100/80">
                    USD Eq {formatCurrency(usdEq, 'USD')} · SLA {selectedRail.settlementSla}
                  </div>
                </div>
              </div>
            </div>

            <div className="p-5">
              <h3 className="font-display text-sm font-semibold text-stone-900 dark:text-stone-100">
                Dynamic Settlement &amp; QR Terminal
              </h3>

              {receipt ? (
                <div className="mt-3 space-y-3 text-xs">
                  <div className="flex items-center gap-2 text-teal-700 dark:text-teal-400">
                    <CheckCircle2 className="h-4 w-4" />
                    <span className="font-semibold">
                      Cleared {receipt.reference} ({receipt.railName})
                    </span>
                  </div>
                  {qrImageUrl && receipt.qrPayload && (
                    <div className="flex flex-col items-center rounded-xl border border-stone-200 bg-[#F8F7F3] p-4 dark:border-slate-800 dark:bg-[#0B1117]">
                      <img
                        src={qrImageUrl}
                        alt="EMVCo or ZATCA dynamic QR"
                        className="h-40 w-40 rounded-lg bg-white p-1.5"
                      />
                      <div className="mt-2 break-all text-center font-mono text-[10px] text-stone-500">
                        {receipt.qrPayload}
                      </div>
                    </div>
                  )}
                  <div className="space-y-1 font-mono">
                    <div className="flex justify-between">
                      <span className="text-stone-500">Intent:</span>
                      <span>{receipt.gatewayIntentId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">Net USD:</span>
                      <span className="font-semibold text-teal-700 dark:text-teal-400">
                        {formatCurrency(receipt.netUsd, 'USD')}
                      </span>
                    </div>
                    {typeof receipt.ujrahFeeUsd === 'number' && receipt.ujrahFeeUsd > 0 && (
                      <div className="flex justify-between">
                        <span className="text-stone-500">Halal Ujrah Fee:</span>
                        <span className="font-semibold text-amber-700 dark:text-amber-300">
                          {formatCurrency(receipt.ujrahFeeUsd, 'USD')}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <p className="mt-2 text-xs text-stone-500 dark:text-stone-400">
                  Execute a payment via SBP Raast, Saudi Mada, or STC Pay to generate a live CRC-16 EMVCo QR or ZATCA Phase-2 TLV Base64 QR code.
                </p>
              )}
            </div>
          </div>

          <div className="overflow-hidden rounded-xl border border-stone-200 bg-white dark:border-slate-800 dark:bg-[#111922]">
            <div className="relative h-24 overflow-hidden bg-[#0D2327]">
              {!hubImgFailed && (
                <img
                  src="/src/assets/images/global_rails_hub_clean_1794551177007.jpg"
                  alt="Global Clearing Architecture"
                  referrerPolicy="no-referrer"
                  onError={() => setHubImgFailed(true)}
                  className="h-full w-full object-cover opacity-50"
                />
              )}
              <div className="absolute inset-0 bg-gradient-to-r from-[#0D2327]/95 via-[#0D2327]/65 to-transparent" />
              <div className="absolute inset-0 flex items-center justify-between p-4 text-white">
                <div>
                  <div className="font-display text-sm font-semibold">
                    Payment Links &amp; Regulatory Exports
                  </div>
                  <div className="text-[11px] text-teal-100/80">
                    ISO-20022 XML, CSV, GDPR JSON &amp; UTM Attribution
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowLinkForm((s) => !s)}
                  className="inline-flex items-center gap-1 rounded-xl bg-teal-500 px-2.5 py-1.5 text-xs font-semibold text-slate-950 hover:bg-teal-400"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>New Link</span>
                </button>
              </div>
            </div>

            <div className="space-y-4 p-5">
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() =>
                    void handleDownloadExport(
                      '/api/exports/iso20022',
                      'bolmizan-iso20022-pain001.xml'
                    )
                  }
                  className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 text-xs font-medium text-stone-700 hover:bg-stone-100 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-200 dark:hover:bg-slate-800"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>ISO-20022 XML</span>
                </button>
                <button
                  type="button"
                  onClick={() => downloadTransactionsCsv(transactions)}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 text-xs font-medium text-stone-700 hover:bg-stone-100 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-200 dark:hover:bg-slate-800"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>CSV Ledger</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    void handleDownloadExport(
                      '/api/compliance/export',
                      'bolmizan-veritas-gdpr-export.json'
                    )
                  }
                  className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 text-xs font-medium text-stone-700 hover:bg-stone-100 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-200 dark:hover:bg-slate-800"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>GDPR JSON</span>
                </button>
              </div>

              {showLinkForm && (
                <form
                  onSubmit={handleCreateLink}
                  className="space-y-2.5 rounded-xl border border-stone-200 bg-[#F8F7F3] p-3 text-xs dark:border-slate-800 dark:bg-[#0B1117]"
                >
                  <input
                    type="text"
                    required
                    value={linkTitle}
                    onChange={(e) => setLinkTitle(e.target.value)}
                    placeholder="Link title"
                    className="w-full rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 dark:border-slate-800 dark:bg-[#111922] dark:text-stone-100"
                  />
                  <input
                    type="text"
                    required
                    value={linkDesc}
                    onChange={(e) => setLinkDesc(e.target.value)}
                    placeholder="Description"
                    className="w-full rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 dark:border-slate-800 dark:bg-[#111922] dark:text-stone-100"
                  />
                  <div className="grid grid-cols-3 gap-2">
                    <input
                      type="number"
                      required
                      min="1"
                      value={linkAmount}
                      onChange={(e) => setLinkAmount(e.target.value)}
                      className="rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 font-mono dark:border-slate-800 dark:bg-[#111922] dark:text-stone-100"
                    />
                    <select
                      value={linkCurrency}
                      onChange={(e) => setLinkCurrency(e.target.value as CurrencyCode)}
                      className="rounded-xl border border-stone-200 bg-white px-2 py-1.5 dark:border-slate-800 dark:bg-[#111922] dark:text-stone-100"
                    >
                      {(Object.keys(CURRENCY_METADATA) as CurrencyCode[]).map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      value={linkUtm}
                      onChange={(e) => setLinkUtm(e.target.value)}
                      placeholder="UTM Source"
                      className="rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 dark:border-slate-800 dark:bg-[#111922] dark:text-stone-100"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={creatingLink}
                    className="w-full rounded-xl bg-teal-700 py-1.5 font-semibold text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950"
                  >
                    {creatingLink ? 'Publishing...' : 'Publish Global Payment Link'}
                  </button>
                </form>
              )}

              <div className="border-t border-stone-200 pt-3 dark:border-slate-800">
                <div className="text-xs font-medium text-stone-600 dark:text-stone-400">
                  Active Payment Links ({paymentLinks.length})
                </div>
                <div className="mt-2 space-y-2">
                  {paymentLinks.map((lnk) => (
                    <div
                      key={lnk.id}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-stone-200 px-3 py-2 text-xs dark:border-slate-800"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="truncate font-medium text-stone-900 dark:text-stone-100">
                          {lnk.title}
                        </div>
                        <div className="text-stone-500">
                          {lnk.conversions} paid · {lnk.utmSource} ·{' '}
                          <span className={lnk.active ? 'text-teal-700 dark:text-teal-400' : 'text-stone-400'}>
                            {lnk.active ? 'Active' : 'Paused'}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono font-semibold text-stone-900 dark:text-stone-100">
                          {formatCurrency(lnk.amount, lnk.currency)}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleLoadPaymentLink(lnk)}
                          title="Load into checkout"
                          className="rounded-lg border border-stone-200 p-1 text-stone-600 hover:bg-stone-100 dark:border-slate-800 dark:text-stone-300 dark:hover:bg-slate-800"
                        >
                          <Link2 className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            apiFetch(`/api/payment-links/${lnk.id}/toggle`, { method: 'PATCH' })
                          }
                          className="rounded-lg border border-stone-200 px-2 py-1 text-[11px] font-medium hover:bg-stone-100 dark:border-slate-800 dark:hover:bg-slate-800"
                        >
                          {lnk.active ? 'Pause' : 'Resume'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Transaction Table */}
      <div className="overflow-hidden rounded-xl border border-stone-200 bg-white dark:border-slate-800 dark:bg-[#111922]">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-stone-200 text-stone-500 dark:border-slate-800 dark:text-stone-400">
                <th className="px-4 py-3.5">Reference</th>
                <th className="px-4 py-3.5">Customer</th>
                <th className="px-4 py-3.5">Rail</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5 text-right">Amount</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200 dark:divide-slate-800">
              {transactions.slice(0, 12).map((tx) => (
                <tr key={tx.id} className="transition-colors hover:bg-[#F8F7F3] dark:hover:bg-slate-800/30">
                  <td className="px-4 py-3.5 font-mono font-semibold">{tx.reference}</td>
                  <td className="px-4 py-3.5">
                    {tx.customerName} ({tx.customerCountry})
                  </td>
                  <td className="px-4 py-3.5">{tx.railName}</td>
                  <td className="px-4 py-3.5 capitalize">{tx.status}</td>
                  <td className="px-4 py-3.5 text-right font-mono tabular-nums">
                    {formatCurrency(tx.amount, tx.currency)}
                  </td>
                  <td className="px-4 py-3.5 text-right">
                    <div className="inline-flex gap-1.5">
                      <button
                        type="button"
                        disabled={tx.status === 'refunded'}
                        onClick={() => apiFetch(`/api/payments/${tx.id}/refund`, { method: 'POST' })}
                        className="rounded-lg border border-stone-200 px-2 py-1 hover:bg-stone-100 disabled:opacity-40 dark:border-slate-800 dark:hover:bg-slate-800"
                      >
                        Refund
                      </button>
                      <button
                        type="button"
                        disabled={tx.piiRedacted}
                        onClick={() => apiFetch(`/api/compliance/redact/${tx.id}`, { method: 'POST' })}
                        className="inline-flex items-center gap-1 rounded-lg border border-stone-200 px-2 py-1 hover:bg-stone-100 disabled:opacity-40 dark:border-slate-800 dark:hover:bg-slate-800"
                      >
                        <EyeOff className="h-3 w-3" />
                        <span>{tx.piiRedacted ? 'Redacted' : 'GDPR'}</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
