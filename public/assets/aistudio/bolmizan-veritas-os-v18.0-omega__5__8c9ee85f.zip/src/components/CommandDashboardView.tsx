import { useMemo, useState } from 'react';
import {
  Activity,
  ArrowUpRight,
  Award,
  Compass,
  Globe2,
  MapPin,
  Mic,
  Music2,
  Palette,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Volume2,
} from 'lucide-react';
import type {
  BranchId,
  MizanAdvisorReport,
  NavSection,
  UiLanguage,
  VeritasBootstrapPayload,
  WorkspaceRole,
} from '../../shared/types';
import { GLOBAL_PAYMENT_RAILS } from '../../shared/rails';
import type { CulturalMotifId } from '../utils/culturalCalendar';
import { formatCurrency } from '../utils/formatters';
import { apiFetch } from '../utils/sessionClient';
import { sufiSoundscape } from '../utils/sufiSoundscape';
import { speakMultilingual } from '../utils/ttsAndOffline';
import {
  AmanatRadialGaugeSvg,
  CorridorVelocityDonutSvg,
  RealTimeLedgerVelocityChart,
} from './LedgerVelocityCharts';
import { PoorySindhMap } from './PoorySindhMap';
import { OtaqMajlisWidget, SindhiRilliQuiltWidget } from './RilliAndOtaqWidgets';
import { SindhCultureStudio } from './SindhCultureStudio';
import { SindhMizanEmblem } from './SindhMizanEmblem';
import { VolumeChart } from './VolumeChart';

interface CommandDashboardViewProps {
  data: VeritasBootstrapPayload;
  activeRole: WorkspaceRole;
  language: UiLanguage;
  pardaActive: boolean;
  mizanTiltDeg: number;
  mizanPulseKey: number;
  mizanKickDeg: number;
  activeMotif: CulturalMotifId;
  soundMuted: boolean;
  onSelectMotif: (motif: CulturalMotifId) => void;
  onToggleSound: () => void;
  onSelectRole: (role: WorkspaceRole) => void;
  onNavigate: (section: NavSection) => void;
  onOpenWelcomeModal: () => void;
  onOpenVoiceModal: () => void;
  onRefresh?: () => Promise<void>;
}

const ROLE_OPTIONS: Array<{ id: WorkspaceRole; label: string }> = [
  { id: 'founder', label: 'Founder / CEO' },
  { id: 'merchant', label: 'Mazdoor / Shop' },
  { id: 'exporter', label: 'Global Exporter' },
  { id: 'product_manager', label: 'Product Lead' },
  { id: 'marketer', label: 'Growth' },
  { id: 'auditor', label: 'Auditor' },
];

const RADAR_NODES: Array<{
  city: string;
  x: number;
  y: number;
  highlight?: boolean;
}> = [
  { city: 'Sakrand HQ', x: 245, y: 112, highlight: true },
  { city: 'Karachi', x: 234, y: 126 },
  { city: 'Dubai', x: 196, y: 112 },
  { city: 'Riyadh', x: 175, y: 119 },
  { city: 'Mumbai', x: 256, y: 129 },
  { city: 'Nairobi', x: 162, y: 156 },
  { city: 'London', x: 112, y: 66 },
  { city: 'New York', x: 46, y: 80 },
];

type WorkbenchTab = 'velocity' | 'atlas' | 'culture';

export function CommandDashboardView({
  data,
  activeRole,
  language,
  pardaActive,
  mizanTiltDeg,
  mizanPulseKey,
  mizanKickDeg,
  activeMotif,
  soundMuted,
  onSelectMotif,
  onToggleSound,
  onSelectRole,
  onNavigate,
  onOpenWelcomeModal,
  onOpenVoiceModal,
  onRefresh,
}: CommandDashboardViewProps) {
  const [branchFilter, setBranchFilter] = useState<BranchId>('all');
  const [workbenchTab, setWorkbenchTab] = useState<WorkbenchTab>('velocity');
  const [advisor, setAdvisor] = useState<MizanAdvisorReport>(data.advisorReport);
  const [advisorBusy, setAdvisorBusy] = useState(false);

  const filteredTxs = useMemo(() => {
    if (branchFilter === 'all') return data.transactions;
    return data.transactions.filter((t) => t.branchId === branchFilter);
  }, [data.transactions, branchFilter]);

  const filteredLedger = useMemo(() => {
    if (branchFilter === 'all') return data.ledgerEntries;
    return data.ledgerEntries.filter((e) => e.branchId === branchFilter);
  }, [data.ledgerEntries, branchFilter]);

  const branchGrossUsd = useMemo(
    () =>
      Number(
        filteredTxs
          .filter((t) => t.status !== 'declined' && t.status !== 'refunded')
          .reduce((s, t) => s + t.usdAmount, 0)
          .toFixed(2)
      ),
    [filteredTxs]
  );

  const hubVolumeMap = useMemo(() => {
    const map = new Map<string, number>();
    for (const b of data.branches) {
      map.set(b.city.toLowerCase(), b.volumeUsd);
    }
    return map;
  }, [data.branches]);

  const roleMeta = ROLE_OPTIONS.find((r) => r.id === activeRole) ?? ROLE_OPTIONS[0];

  const railBreakdown = useMemo(() => {
    const counts: Record<string, number> = {
      'Pakistan & MENA': 0,
      'Global Cards & Wallets': 0,
      'International Bank Rails': 0,
      'Web3 & APAC': 0,
    };
    const railMap = new Map(GLOBAL_PAYMENT_RAILS.map((r) => [r.id, r.category]));
    for (const tx of filteredTxs) {
      const cat = railMap.get(tx.railId);
      if (cat) counts[cat] += tx.usdAmount;
    }
    const total = Object.values(counts).reduce((s, v) => s + v, 0) || 1;
    return [
      {
        label: 'Pakistan & MENA',
        val: counts['Pakistan & MENA'],
        pct: Math.round((counts['Pakistan & MENA'] / total) * 100),
        stroke: '#0F766E',
      },
      {
        label: 'Global Bank Rails',
        val: counts['International Bank Rails'],
        pct: Math.round((counts['International Bank Rails'] / total) * 100),
        stroke: '#D97706',
      },
      {
        label: 'Web3 & APAC',
        val: counts['Web3 & APAC'],
        pct: Math.round((counts['Web3 & APAC'] / total) * 100),
        stroke: '#0284C7',
      },
      {
        label: 'Cards & Wallets',
        val: counts['Global Cards & Wallets'],
        pct: Math.round((counts['Global Cards & Wallets'] / total) * 100),
        stroke: '#9B1C2E',
      },
    ];
  }, [filteredTxs]);

  async function handleRefreshAdvisor() {
    setAdvisorBusy(true);
    try {
      const res = await apiFetch('/api/advisor/insights', { method: 'POST' });
      if (res.ok) {
        const next = (await res.json()) as MizanAdvisorReport;
        setAdvisor(next);
      }
    } finally {
      setAdvisorBusy(false);
    }
  }

  function handlePlayCulturalGreeting() {
    if (soundMuted) {
      onToggleSound();
    } else {
      sufiSoundscape.playWelcomeChord();
      sufiSoundscape.startDrone();
    }
    const spokenLine =
      language === 'ur'
        ? `بھلی کرے آیا ${data.user.fullName}! سندھ میزان او ایس میں خوش آمدید`
        : language === 'ar'
          ? `مرحباً ${data.user.fullName} في نظام سندھ ميزان`
          : `Bhali Kare Aaya ${data.user.fullName}! Sindh Mizan OS mein Khush Amdeed.`;
    speakMultilingual(spokenLine, language === 'en' ? 'ur' : language);
  }

  const maskClass = pardaActive ? 'parda-blur' : '';

  return (
    <div className="space-y-7">
      {/* 01. Porcelain Split Architectural Sovereign Hero */}
      <section className="overflow-hidden rounded-xl border border-stone-200 bg-white dark:border-slate-800 dark:bg-[#111922]">
        <div className="grid grid-cols-1 divide-y divide-stone-200 lg:grid-cols-12 lg:divide-x lg:divide-y-0 dark:divide-slate-800">
          {/* Left 7 Cols: Sovereign Liquidity, Balance Mizan & Primary Actions */}
          <div className="flex flex-col justify-between p-6 sm:p-8 lg:col-span-7">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="text-xs font-semibold tracking-wide text-teal-700 dark:text-teal-400">
                  Bhali Kare Aaya · ڀلي ڪري آيا · بھلی کرے آیا
                </div>
                <h1 className="mt-1 font-editorial text-3xl font-bold leading-tight tracking-tight text-slate-900 sm:text-4xl dark:text-white">
                  {data.user.fullName}
                </h1>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  {data.user.businessName} · {data.user.location}
                </p>
              </div>

              <SindhMizanEmblem
                size={64}
                tiltDeg={mizanTiltDeg}
                animatePulseKey={mizanPulseKey}
                tiltKickDeg={mizanKickDeg}
                className="shrink-0"
              />
            </div>

            <div className="my-7">
              <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Cleared Sovereign Volume ({branchFilter === 'all' ? 'All 4 Hubs' : branchFilter})
              </div>
              <div
                className={`mt-1 font-mono text-[clamp(2.2rem,4vw,3.4rem)] font-bold leading-none tracking-tight text-slate-900 tabular-nums dark:text-white ${maskClass}`}
              >
                {formatCurrency(branchGrossUsd, 'USD')}
              </div>

              <div className="mt-6 grid grid-cols-2 gap-6 border-t border-stone-200 pt-4 dark:border-slate-800">
                <div>
                  <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    Open Receivables (Haq)
                  </div>
                  <div className={`mt-0.5 font-mono text-lg font-bold text-teal-700 tabular-nums dark:text-teal-400 ${maskClass}`}>
                    {formatCurrency(data.metrics.openReceivablesPkr, 'PKR')}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    Open Payables · Mizan Tilt ({mizanTiltDeg > 0 ? `+${mizanTiltDeg}` : mizanTiltDeg}°)
                  </div>
                  <div className={`mt-0.5 font-mono text-lg font-bold text-[#9B1C2E] tabular-nums dark:text-rose-400 ${maskClass}`}>
                    {formatCurrency(data.metrics.openPayablesPkr, 'PKR')}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={onOpenVoiceModal}
                className="inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2.5 text-xs font-semibold text-white whitespace-nowrap transition-colors hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
              >
                <Mic className="h-3.5 w-3.5" />
                <span>Speak New Entry</span>
              </button>
              <button
                type="button"
                onClick={handlePlayCulturalGreeting}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#9B1C2E] px-4 py-2.5 text-xs font-semibold text-white whitespace-nowrap transition-colors hover:bg-[#821626]"
              >
                <Music2 className="h-3.5 w-3.5" />
                <span>Bhitai Tambura</span>
              </button>
              <button
                type="button"
                onClick={onOpenWelcomeModal}
                className="inline-flex items-center gap-1.5 rounded-lg border border-stone-300 bg-[#F8F7F3] px-4 py-2.5 text-xs font-semibold text-slate-800 whitespace-nowrap transition-colors hover:bg-stone-200/70 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <span>Cultural Briefing</span>
              </button>
            </div>
          </div>

          {/* Right 5 Cols: Deep Kashi Slate Astrolabe Instrument Panel */}
          <div className="flex flex-col justify-between bg-[#0D2327] p-6 text-white sm:p-8 lg:col-span-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Globe2 className="h-4 w-4 text-teal-300" />
                <span className="font-display text-sm font-semibold text-white">
                  Sakrand-to-World Corridor Radar
                </span>
              </div>
              <span className="text-[11px] text-teal-200/80">{roleMeta.label}</span>
            </div>

            <div className="my-4 rounded-lg border border-teal-500/20 bg-[#08171A] p-2">
              <svg viewBox="0 0 340 190" className="h-44 w-full">
                <g opacity="0.32">
                  <circle cx="245" cy="112" r="28" fill="none" stroke="#F59E0B" strokeWidth="0.8" />
                  <circle
                    cx="245"
                    cy="112"
                    r="58"
                    fill="none"
                    stroke="#2DD4BF"
                    strokeWidth="0.8"
                    strokeDasharray="4 4"
                    className="astrolabe-sweep"
                  />
                  <circle cx="245" cy="112" r="98" fill="none" stroke="#1E4B52" strokeWidth="0.8" />
                  <circle cx="245" cy="112" r="145" fill="none" stroke="#13343A" strokeWidth="0.8" />
                </g>

                {RADAR_NODES.filter((n) => !n.highlight).map((node) => {
                  const midX = (245 + node.x) / 2;
                  const midY = Math.min(245, Math.min(112, node.y) - 24);
                  const cityVol = hubVolumeMap.get(node.city.toLowerCase()) ?? 250;
                  const dynamicStroke = Number(
                    Math.min(2.6, 1.0 + Math.log10(Math.max(10, cityVol)) * 0.32).toFixed(2)
                  );
                  const dynamicDuration = `${Math.max(2.1, 5.2 - Math.min(2.8, cityVol / 1500)).toFixed(1)}s`;
                  return (
                    <g key={node.city}>
                      <path
                        d={`M245 112 Q ${midX} ${midY} ${node.x} ${node.y}`}
                        fill="none"
                        stroke="#2DD4BF"
                        strokeWidth={dynamicStroke}
                        className="arc-travel"
                        style={{ animationDuration: dynamicDuration }}
                      />
                      <circle cx={node.x} cy={node.y} r={dynamicStroke + 1.3} fill="#FBBF24" />
                      <text
                        x={node.x}
                        y={node.y + 11}
                        textAnchor="middle"
                        fill="#CCFBF1"
                        fontSize="8"
                        fontFamily="monospace"
                      >
                        {node.city}
                      </text>
                    </g>
                  );
                })}

                <circle cx="245" cy="112" r="6" fill="#F59E0B" stroke="#FEF3C7" strokeWidth="2" />
                <text
                  x="245"
                  y="100"
                  textAnchor="middle"
                  fill="#FDE68A"
                  fontSize="9"
                  fontWeight="bold"
                  fontFamily="sans-serif"
                >
                  Sakrand HQ
                </text>
              </svg>
            </div>

            <div className="grid grid-cols-2 divide-x divide-teal-500/20 overflow-hidden rounded-lg border border-teal-500/20 bg-[#08171A] text-xs sm:grid-cols-4">
              {data.branches.map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => setBranchFilter((prev) => (prev === b.id ? 'all' : b.id))}
                  className={`p-2.5 text-left transition-colors ${
                    branchFilter === b.id ? 'bg-teal-500/25 text-teal-100' : 'hover:bg-white/5'
                  }`}
                >
                  <div className="truncate font-semibold text-white">{b.city}</div>
                  <div className={`mt-0.5 font-mono text-[11px] text-teal-300 tabular-nums ${maskClass}`}>
                    {formatCurrency(b.volumeUsd, 'USD')}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 02. Seamless 4-Column Hairline KPI Ribbon */}
      <div className="grid grid-cols-1 divide-y divide-stone-200 overflow-hidden rounded-xl border border-stone-200 bg-white sm:grid-cols-2 sm:divide-x sm:divide-y-0 xl:grid-cols-4 dark:divide-slate-800 dark:border-slate-800 dark:bg-[#111922]">
        <div className="p-5 sm:p-6">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Settlement Auth Rate
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums dark:text-white">
            {data.metrics.approvalRatePct}%
          </div>
          <div className="mt-1 text-xs text-teal-700 tabular-nums dark:text-teal-400">
            {filteredTxs.length} settled across 21 global rails
          </div>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('treasury')}
          className="p-5 text-left transition-colors hover:bg-[#F8F7F3] sm:p-6 dark:hover:bg-slate-800/40"
        >
          <div className="flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
            <span>Founder MRR &amp; Ujrah Treasury</span>
            <ArrowUpRight className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
          </div>
          <div className={`mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums dark:text-white ${maskClass}`}>
            {formatCurrency(data.treasury.availableBalanceUsd, 'USD')}
          </div>
          <div className="mt-1 text-xs text-slate-500 tabular-nums dark:text-slate-400">
            MRR {formatCurrency(data.treasury.mrrUsd, 'USD')}/mo · Ujrah ${data.treasury.cumulativeUjrahUsd.toFixed(2)}
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('treasury')}
          className="p-5 text-left transition-colors hover:bg-[#F8F7F3] sm:p-6 dark:hover:bg-slate-800/40"
        >
          <div className="flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
            <span>Haq-e-Mazdoor Wage Vault</span>
            <ArrowUpRight className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
          </div>
          <div className={`mt-2 font-mono text-2xl font-bold text-teal-700 tabular-nums dark:text-teal-400 ${maskClass}`}>
            {formatCurrency(data.metrics.escrowLockedPkr, 'PKR')}
          </div>
          <div className="mt-1 text-xs text-slate-500 tabular-nums dark:text-slate-400">
            0% fee · Released {formatCurrency(data.metrics.escrowReleasedPkr, 'PKR')}
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('mukasa')}
          className="p-5 text-left transition-colors hover:bg-[#F8F7F3] sm:p-6 dark:hover:bg-slate-800/40"
        >
          <div className="flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
            <span>Mukasa &amp; Maal-Guard</span>
            <ArrowUpRight className="h-3.5 w-3.5 text-[#9B1C2E] dark:text-rose-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums dark:text-white">
            {data.metrics.detectedCycleCount} Loops · {data.metrics.expiringSoonCount} Exp
          </div>
          <div className={`mt-1 text-xs text-[#9B1C2E] tabular-nums dark:text-rose-400 ${maskClass}`}>
            Shrinkage {formatCurrency(data.metrics.shrinkageLossPkr, 'PKR')}
          </div>
        </button>
      </div>

      {/* 03. Unified Interactive Command Workbench Tabs (Reduces clutter & puts everything 1 click away) */}
      <section className="space-y-4">
        <div className="flex flex-col gap-3 border-b border-stone-200 pb-3 lg:flex-row lg:items-center lg:justify-between dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-1 rounded-lg border border-stone-200 bg-white p-1 dark:border-slate-800 dark:bg-[#111922]">
            {(
              [
                { id: 'velocity', label: 'Live Velocity & FX', icon: Activity },
                { id: 'atlas', label: '21-District Sindh Atlas', icon: Compass },
                { id: 'culture', label: 'Culture, Otaq & Synth', icon: Palette },
              ] as const
            ).map((tab) => {
              const Icon = tab.icon;
              const active = workbenchTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setWorkbenchTab(tab.id)}
                  className={`inline-flex items-center gap-1.5 rounded-md px-3.5 py-2 text-xs font-semibold whitespace-nowrap transition-colors ${
                    active
                      ? 'bg-teal-700 text-white dark:bg-teal-500 dark:text-slate-950'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-wrap items-center gap-1">
              {ROLE_OPTIONS.map((role) => (
                <button
                  key={role.id}
                  type="button"
                  onClick={() => onSelectRole(role.id)}
                  className={`rounded-md px-2.5 py-1.5 text-[11px] font-semibold whitespace-nowrap transition-colors ${
                    activeRole === role.id
                      ? 'bg-slate-900 text-white dark:bg-slate-200 dark:text-slate-950'
                      : 'text-slate-600 hover:bg-stone-200/70 dark:text-slate-400 dark:hover:bg-slate-800'
                  }`}
                >
                  {role.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 shrink-0 text-teal-700 dark:text-teal-400" />
              <select
                value={branchFilter}
                onChange={(e) => setBranchFilter(e.target.value as BranchId)}
                aria-label="Branch Filter"
                className="rounded-lg border border-stone-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-800 dark:border-slate-700 dark:bg-[#111922] dark:text-slate-200"
              >
                <option value="all">All 4 Global Hubs</option>
                <option value="sakrand_hq">Sakrand Main HQ</option>
                <option value="karachi_port">Karachi Port</option>
                <option value="riyadh_hub">Riyadh Hub</option>
                <option value="dubai_marina">Dubai Marina</option>
              </select>
            </div>
          </div>
        </div>

        {workbenchTab === 'velocity' && (
          <div className="space-y-6 veritas-enter">
            <RealTimeLedgerVelocityChart
              ledgerEntries={filteredLedger}
              transactions={filteredTxs}
              fx={data.fx}
              branchFilter={branchFilter}
              pardaActive={pardaActive}
            />

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div className="lg:col-span-7">
                <VolumeChart
                  series={data.volumeSeries}
                  subtitle={`Active window · ${filteredTxs.length} settled events across 21 corridors`}
                />
              </div>

              <div className="flex flex-col justify-between rounded-xl border border-stone-200 bg-white p-6 lg:col-span-5 dark:border-slate-800 dark:bg-[#111922]">
                <div>
                  <h3 className="font-editorial text-xl font-bold text-slate-900 dark:text-white">
                    21-Rail Corridor Share &amp; Spot FX
                  </h3>
                  <CorridorVelocityDonutSvg segments={railBreakdown} pardaActive={pardaActive} />
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2 border-t border-stone-200 pt-4 font-mono text-xs tabular-nums dark:border-slate-800">
                  {(['PKR', 'SAR', 'AED', 'EUR', 'GBP', 'INR'] as const).map((code) => (
                    <div
                      key={code}
                      className="rounded-lg bg-[#F8F7F3] px-2.5 py-2 dark:bg-[#0B1117]"
                    >
                      <span className="text-slate-500">USD/{code} </span>
                      <span className="font-semibold text-teal-800 dark:text-teal-400">
                        {data.fx.rates[code]}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {workbenchTab === 'atlas' && (
          <div className="veritas-enter">
            <PoorySindhMap
              language={language}
              sakrandVolumeUsd={hubVolumeMap.get('sakrand') ?? 0}
              karachiVolumeUsd={hubVolumeMap.get('karachi') ?? 0}
              pardaActive={pardaActive}
            />
          </div>
        )}

        {workbenchTab === 'culture' && (
          <div className="space-y-6 veritas-enter">
            <SindhCultureStudio
              language={language}
              activeMotif={activeMotif}
              soundMuted={soundMuted}
              onSelectMotif={onSelectMotif}
              onToggleSound={onToggleSound}
              onNavigate={onNavigate}
            />

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div className="lg:col-span-6">
                <SindhiRilliQuiltWidget
                  ledgerEntries={filteredLedger}
                  transactions={filteredTxs}
                  pardaActive={pardaActive}
                />
              </div>
              <div className="lg:col-span-6">
                <OtaqMajlisWidget
                  ledgerEntries={filteredLedger}
                  amanatScore={data.amanatPassport.score}
                  witnessCount={data.amanatPassport.witnessCount ?? 0}
                  onWitnessAdded={onRefresh}
                />
              </div>
            </div>
          </div>
        )}
      </section>

      {/* 04. Amanat Credit Passport + AI Mizan-Advisor Split Panel */}
      <div className="grid grid-cols-1 divide-y divide-stone-200 overflow-hidden rounded-xl border border-stone-200 bg-white lg:grid-cols-12 lg:divide-x lg:divide-y-0 dark:divide-slate-800 dark:border-slate-800 dark:bg-[#111922]">
        <div className="flex flex-col justify-between p-6 lg:col-span-5">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-editorial text-xl font-bold text-slate-900 dark:text-white">
                <Award className="h-5 w-5 text-teal-700 dark:text-teal-400" />
                <span>Amanat Credit Passport</span>
              </div>
              <ShieldCheck className="h-4 w-4 text-teal-700 dark:text-teal-400" />
            </div>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {data.amanatPassport.tier} · Verified SHA-256 DAG &amp; Otaq Witnesses
            </p>
          </div>

          <div className="my-5">
            <AmanatRadialGaugeSvg
              score={data.amanatPassport.score}
              ledgerEntries={filteredLedger}
            />
            <div className="mt-2 flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
              <span>Clean Settlement Ratio</span>
              <span className="font-mono font-semibold text-teal-700 tabular-nums dark:text-teal-400">
                {data.amanatPassport.onTimeSettlementRatio}% on-time
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-stone-200 pt-4 text-xs dark:border-slate-800">
            <span className="text-slate-500 dark:text-slate-400">Zero-Riba Supplier Line</span>
            <span className={`font-mono font-bold text-slate-900 tabular-nums dark:text-teal-300 ${maskClass}`}>
              {formatCurrency(data.amanatPassport.unlockCreditLimitPkr, 'PKR')}
            </span>
          </div>
        </div>

        <div className="flex flex-col justify-between p-6 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 font-editorial text-xl font-bold text-slate-900 dark:text-white">
              <Sparkles className="h-5 w-5 text-teal-700 dark:text-teal-400" />
              <span>AI Mizan-Advisor ({advisor.generatedBy})</span>
            </div>
            <button
              type="button"
              disabled={advisorBusy}
              onClick={handleRefreshAdvisor}
              className="inline-flex items-center gap-1.5 rounded-lg border border-stone-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-stone-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${advisorBusy ? 'animate-spin' : ''}`} />
              <span>{advisorBusy ? 'Analyzing...' : 'Refresh Advice'}</span>
            </button>
          </div>

          <div className="mt-4 space-y-3 text-xs">
            <div className="text-sm font-semibold text-teal-800 dark:text-teal-400">
              {advisor.headline}
            </div>
            <p className="leading-relaxed text-slate-600 dark:text-slate-300">
              {advisor.insightSummary}
            </p>
            <div className="rounded-lg border border-amber-300 bg-amber-50/70 px-4 py-2.5 font-medium text-amber-950 dark:border-amber-700/50 dark:bg-amber-950/30 dark:text-amber-200">
              Next Step: {advisor.urgentAction}
            </div>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-4 border-t border-stone-200 pt-4 sm:grid-cols-2 dark:border-slate-800">
            <div className="flex items-start justify-between gap-2 rounded-lg bg-[#F8F7F3] p-3.5 text-xs dark:bg-[#0B1117]">
              <div dir="rtl" className="leading-relaxed text-slate-700 dark:text-slate-300">
                {advisor.politeReminderUr}
              </div>
              <button
                type="button"
                onClick={() => speakMultilingual(advisor.politeReminderUr, 'ur')}
                title="Read Urdu Reminder"
                className="shrink-0 rounded-md p-1.5 text-teal-700 hover:bg-stone-200 dark:text-teal-400 dark:hover:bg-slate-800"
              >
                <Volume2 className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="flex items-start justify-between gap-2 rounded-lg bg-[#F8F7F3] p-3.5 text-xs dark:bg-[#0B1117]">
              <div dir="rtl" className="leading-relaxed text-slate-700 dark:text-slate-300">
                {advisor.politeReminderSd}
              </div>
              <button
                type="button"
                onClick={() => speakMultilingual(advisor.politeReminderSd, 'sd')}
                title="Read Sindhi Reminder"
                className="shrink-0 rounded-md p-1.5 text-[#9B1C2E] hover:bg-stone-200 dark:text-rose-400 dark:hover:bg-slate-800"
              >
                <Volume2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
