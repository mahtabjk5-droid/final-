import { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  GitCompareArrows,
  Package,
  Printer,
  Share2,
  ShieldAlert,
  X,
} from 'lucide-react';
import type { DebtCycleResult, InventoryItem } from '../../shared/types';
import { formatCurrency } from '../utils/formatters';
import { apiFetch } from '../utils/sessionClient';

interface MukasaAndMaalGuardViewProps {
  debtCycles: DebtCycleResult[];
  inventory: InventoryItem[];
}

export function MukasaAndMaalGuardView({
  debtCycles,
  inventory,
}: MukasaAndMaalGuardViewProps) {
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [implodingCycleId, setImplodingCycleId] = useState<string | null>(null);
  const [ngoModalItem, setNgoModalItem] = useState<InventoryItem | null>(null);

  async function handleSettleCycle(cycleId: string) {
    setStatusMsg(null);
    setImplodingCycleId(cycleId);
    await new Promise((r) => setTimeout(r, 260));
    const res = await apiFetch(`/api/mukasa/settle/${cycleId}`, { method: 'POST' });
    setImplodingCycleId(null);
    const json = (await res.json()) as {
      error?: string;
      settled?: { settledAmountPkr: number; participants: string[] };
    };
    if (res.ok && json.settled) {
      setStatusMsg(
        `Settled PKR ${json.settled.settledAmountPkr.toLocaleString()} with ZERO cash movement across ${json.settled.participants.join(' → ')}.`
      );
    } else {
      setStatusMsg(json.error || 'Unable to settle cycle.');
    }
  }

  async function handleAdjustCount(id: string, delta: number, current: number) {
    const next = Math.max(0, current + delta);
    await apiFetch(`/api/inventory/${id}/actual`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ actualRemainingQty: next }),
    });
  }

  async function handleTriggerRescueDeal(item: InventoryItem) {
    setStatusMsg(null);
    const res = await apiFetch(`/api/inventory/${item.id}/rescue`, { method: 'POST' });
    if (res.ok) {
      setStatusMsg(
        `Maal-Guard B2B 30% Flash Rescue triggered for ${item.name} — $0.30 facilitation Ujrah credited to Founder Treasury.`
      );
    }
  }

  return (
    <div className="space-y-6 veritas-enter">
      {/* Circular Debt Mukasa Solver */}
      <section className="rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-teal-600/30 bg-teal-700/10 text-teal-700 dark:text-teal-400">
              <GitCompareArrows className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
                Macro-Scale Circular Debt Mukasa Clearinghouse
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                Graph DFS cycle detection across branches &amp; traders (A → B → C → A) with 1-click zero-cash offset
              </p>
            </div>
          </div>
          <div className="font-mono text-xs font-semibold text-teal-700 dark:text-teal-400">
            {debtCycles.length} Active Cycle{debtCycles.length === 1 ? '' : 's'}
          </div>
        </div>

        {statusMsg && (
          <div className="mt-4 rounded-xl border border-teal-600/30 bg-teal-700/8 px-4 py-2.5 text-xs font-medium text-teal-800 dark:bg-teal-500/15 dark:text-teal-300">
            {statusMsg}
          </div>
        )}

        <div className="mt-4 space-y-4">
          {debtCycles.length === 0 ? (
            <div className="flex items-center gap-2 rounded-xl border border-stone-200 bg-[#F8F7F3] p-4 text-xs text-stone-600 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-400">
              <CheckCircle2 className="h-4 w-4 text-teal-700 dark:text-teal-400" />
              <span>All circular debt loops are cleared cleanly.</span>
            </div>
          ) : (
            debtCycles.map((cyc) => {
              const uniqueNodes = cyc.participants.slice(0, -1);
              const n = uniqueNodes.length;
              const cx = 170;
              const cy = 98;
              const r = 64;
              const coords = uniqueNodes.map((label, idx) => {
                const angle = (idx / n) * Math.PI * 2 - Math.PI / 2;
                return {
                  label,
                  x: cx + r * Math.cos(angle),
                  y: cy + r * Math.sin(angle),
                };
              });

              return (
                <div
                  key={cyc.id}
                  className="grid grid-cols-1 items-center gap-5 rounded-xl border border-stone-200 bg-[#F8F7F3] p-4 lg:grid-cols-12 dark:border-slate-800 dark:bg-[#0B1117]"
                >
                  <div className="flex items-center justify-center lg:col-span-5">
                    <svg
                      viewBox="0 0 340 196"
                      className={`h-44 w-full max-w-[340px] transition-all duration-300 ${
                        implodingCycleId === cyc.id ? 'scale-50 opacity-20' : 'scale-100 opacity-100'
                      }`}
                    >
                      <defs>
                        <marker
                          id={`arrow-${cyc.id}`}
                          viewBox="0 0 10 10"
                          refX="8"
                          refY="5"
                          markerWidth="6"
                          markerHeight="6"
                          orient="auto-start-reverse"
                        >
                          <path d="M 0 1 L 10 5 L 0 9 z" fill="#0F766E" />
                        </marker>
                      </defs>

                      {coords.map((from, idx) => {
                        const to = coords[(idx + 1) % n];
                        const dx = to.x - from.x;
                        const dy = to.y - from.y;
                        const dist = Math.hypot(dx, dy) || 1;
                        const pad = 22;
                        const x1 = from.x + (dx / dist) * pad;
                        const y1 = from.y + (dy / dist) * pad;
                        const x2 = to.x - (dx / dist) * (pad + 4);
                        const y2 = to.y - (dy / dist) * (pad + 4);
                        const edge = cyc.edges[idx];
                        return (
                          <g key={`${from.label}-${to.label}`}>
                            <line
                              x1={x1}
                              y1={y1}
                              x2={x2}
                              y2={y2}
                              stroke="#0F766E"
                              strokeWidth="2"
                              markerEnd={`url(#arrow-${cyc.id})`}
                            />
                            {edge && (
                              <text
                                x={(x1 + x2) / 2}
                                y={(y1 + y2) / 2 - 5}
                                textAnchor="middle"
                                className="fill-[#9B1C2E] font-mono text-[9px] font-semibold dark:fill-amber-400"
                              >
                                {Math.round(edge.amountPkr / 1000)}k
                              </text>
                            )}
                          </g>
                        );
                      })}

                      {coords.map((node) => (
                        <g key={node.label}>
                          <circle
                            cx={node.x}
                            cy={node.y}
                            r="16"
                            className="fill-white stroke-teal-700 dark:fill-[#111922] dark:stroke-teal-400"
                            strokeWidth="2"
                          />
                          <text
                            x={node.x}
                            y={node.y + 3}
                            textAnchor="middle"
                            className="fill-stone-900 text-[9px] font-bold dark:fill-stone-100"
                          >
                            {node.label.slice(0, 6)}
                          </text>
                        </g>
                      ))}
                    </svg>
                  </div>

                  <div className="space-y-3 lg:col-span-7">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="font-display text-sm font-semibold text-stone-900 dark:text-stone-100">
                        {cyc.participants.join(' → ')}
                      </div>
                      <button
                        type="button"
                        onClick={() => handleSettleCycle(cyc.id)}
                        className="rounded-xl bg-teal-700 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                      >
                        Settle PKR {cyc.offsetAmountPkr.toLocaleString()} (Zero Cash)
                      </button>
                    </div>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                      {cyc.edges.map((e) => (
                        <div
                          key={`${e.from}-${e.to}`}
                          className="rounded-xl border border-stone-200 bg-white p-2.5 text-xs dark:border-slate-800 dark:bg-[#111922]"
                        >
                          <div className="truncate font-medium text-stone-800 dark:text-stone-200">
                            {e.from} owes {e.to}
                          </div>
                          <div className="mt-1 font-mono font-semibold text-teal-700 dark:text-teal-300">
                            {formatCurrency(e.amountPkr, 'PKR')}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </section>

      {/* Maal-Guard Inventory Shrinkage & Sub-30-Day Expiry Radar */}
      <section className="rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#9B1C2E]/25 bg-[#9B1C2E]/10 text-[#9B1C2E] dark:text-rose-400">
            <Package className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
              Maal-Guard Shrinkage Detector &amp; Global Expiry Rescue (Hazrat Usman RA Model)
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              Compares dispatched vs. remaining stock, issues 30%-discount B2B rescues (flat $0.30 Ujrah), or NGO certificates
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {inventory.map((item) => {
            const expectedRemaining = Math.max(0, item.expectedQty - item.dispatchedQty);
            const missingUnits = Math.max(0, expectedRemaining - item.actualRemainingQty);
            const shrinkagePkr = missingUnits * item.unitCostPkr;
            const daysLeft = Math.ceil((Date.parse(item.expiryDate) - Date.now()) / 86_400_000);
            const expiringSoon = daysLeft <= 30;
            const rescuePrice = Math.round(item.unitSellPkr * 0.7);
            const waText = encodeURIComponent(
              `BolMizan Maal-Guard 30% B2B Flash Offer (${item.branchId}): ${item.actualRemainingQty}x ${item.name} (${item.sku}) expiring ${item.expiryDate} at PKR ${rescuePrice}/unit.`
            );

            return (
              <div
                key={item.id}
                className="flex flex-col justify-between rounded-xl border border-stone-200 bg-[#F8F7F3] p-4 dark:border-slate-800 dark:bg-[#0B1117]"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-mono text-[11px] text-stone-500 dark:text-slate-400">
                        {item.sku} · {item.branchId}
                      </div>
                      <div className="mt-0.5 text-sm font-semibold text-stone-900 dark:text-stone-100">
                        {item.name}
                      </div>
                    </div>
                    {missingUnits > 0 && <ShieldAlert className="h-4 w-4 shrink-0 text-[#9B1C2E] dark:text-rose-400" />}
                  </div>

                  <div className="mt-3 space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-stone-500 dark:text-slate-400">Expected Remaining:</span>
                      <span className="font-mono font-semibold">{expectedRemaining} units</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-stone-500 dark:text-slate-400">Actual Count:</span>
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleAdjustCount(item.id, -1, item.actualRemainingQty)}
                          className="rounded-md border border-stone-200 bg-white px-1.5 py-0.5 font-mono hover:bg-stone-100 dark:border-slate-800 dark:bg-[#111922] dark:hover:bg-slate-800"
                        >
                          -
                        </button>
                        <span className="font-mono font-semibold">{item.actualRemainingQty}</span>
                        <button
                          type="button"
                          onClick={() => handleAdjustCount(item.id, 1, item.actualRemainingQty)}
                          className="rounded-md border border-stone-200 bg-white px-1.5 py-0.5 font-mono hover:bg-stone-100 dark:border-slate-800 dark:bg-[#111922] dark:hover:bg-slate-800"
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500 dark:text-slate-400">Expiry Countdown:</span>
                      <span
                        className={`font-mono font-semibold ${
                          expiringSoon
                            ? 'text-[#9B1C2E] dark:text-amber-400'
                            : 'text-teal-700 dark:text-teal-400'
                        }`}
                      >
                        {daysLeft} days ({item.expiryDate})
                      </span>
                    </div>
                  </div>

                  {missingUnits > 0 && (
                    <div className="mt-3 flex items-center gap-1.5 rounded-lg border border-[#9B1C2E]/30 bg-[#9B1C2E]/10 px-3 py-2 text-xs text-[#9B1C2E] dark:text-rose-300">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                      <span>
                        Shrinkage: {missingUnits} missing ({formatCurrency(shrinkagePkr, 'PKR')})
                      </span>
                    </div>
                  )}
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => handleTriggerRescueDeal(item)}
                    className="inline-flex flex-1 items-center justify-center gap-1 rounded-xl bg-teal-700 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                  >
                    <span>30% Rescue ({item.rescuedCount || 0})</span>
                  </button>
                  <a
                    href={`https://wa.me/?text=${waText}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-1 rounded-xl border border-stone-200 bg-white px-2.5 py-2 text-xs font-medium text-stone-700 hover:bg-stone-100 dark:border-slate-800 dark:bg-[#111922] dark:text-stone-200 dark:hover:bg-slate-800"
                  >
                    <Share2 className="h-3.5 w-3.5" />
                  </a>
                  <button
                    type="button"
                    onClick={() => setNgoModalItem(item)}
                    className="rounded-xl border border-stone-200 bg-white px-2.5 py-2 text-xs font-medium text-stone-700 hover:bg-stone-100 dark:border-slate-800 dark:bg-[#111922] dark:text-stone-200 dark:hover:bg-slate-800"
                  >
                    NGO
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {ngoModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/70 p-4 backdrop-blur-sm dark:bg-[#0B1117]/80">
          <div className="veritas-enter w-full max-w-md rounded-2xl border border-stone-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-[#111922]">
            <div className="no-print mb-3 flex items-center justify-between">
              <div className="font-display text-sm font-semibold text-stone-900 dark:text-stone-100">
                NGO Food / Medicine Rescue Certificate
              </div>
              <button
                type="button"
                onClick={() => setNgoModalItem(null)}
                className="rounded-lg p-1 text-stone-500 hover:bg-stone-100 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="space-y-2 rounded-xl border border-stone-200 bg-[#F8F7F3] p-4 text-xs dark:border-slate-800 dark:bg-[#0B1117]">
              <div className="font-display text-base font-bold text-stone-900 dark:text-stone-100">
                Maal-Guard Humanitarian Pledge
              </div>
              <p className="text-stone-600 dark:text-stone-400">
                Issued by BolMizan VERITAS OS (Sakrand, Sindh HQ) donating remaining stock before expiry:
              </p>
              <div className="font-semibold text-stone-900 dark:text-stone-100">
                {ngoModalItem.actualRemainingQty}x {ngoModalItem.name} ({ngoModalItem.sku})
              </div>
              <div className="font-mono text-stone-500 dark:text-slate-400">
                Tax-Deductible Fair Value:{' '}
                {formatCurrency(ngoModalItem.actualRemainingQty * ngoModalItem.unitCostPkr, 'PKR')}
              </div>
            </div>
            <button
              type="button"
              onClick={() => window.print()}
              className="no-print mt-4 inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-teal-700 py-2.5 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Print NGO Certificate</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
