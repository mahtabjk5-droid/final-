import { useRef, useState } from 'react';
import { Eraser, Fingerprint } from 'lucide-react';

interface SignaturePadProps {
  value: string | null;
  onChange: (dataUrl: string | null) => void;
}

export function SignaturePad({ value, onChange }: SignaturePadProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawingRef = useRef(false);
  const [hasInk, setHasInk] = useState(Boolean(value));

  function getPoint(e: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  }

  function handlePointerDown(e: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.setPointerCapture(e.pointerId);
    drawingRef.current = true;
    const pt = getPoint(e);
    ctx.beginPath();
    ctx.moveTo(pt.x, pt.y);
    ctx.lineWidth = 2.4;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1C1917';
  }

  function handlePointerMove(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!drawingRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;
    const pt = getPoint(e);
    ctx.lineTo(pt.x, pt.y);
    ctx.stroke();
    setHasInk(true);
  }

  function handlePointerUp() {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    const canvas = canvasRef.current;
    if (canvas) {
      onChange(canvas.toDataURL('image/png'));
    }
  }

  function handleStampThumbPrint() {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const cx = canvas.width - 54;
    const cy = canvas.height / 2;
    ctx.save();
    ctx.strokeStyle = '#9F1239';
    ctx.lineWidth = 1.4;
    for (let r = 6; r <= 24; r += 4) {
      ctx.beginPath();
      ctx.ellipse(cx, cy, r * 0.72, r, 0.15, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
    setHasInk(true);
    onChange(canvas.toDataURL('image/png'));
  }

  function handleClear() {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasInk(false);
    onChange(null);
  }

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-xs font-medium text-stone-700 dark:text-stone-300">
          Customer Signature / Digital Thumb-Print (Quran 2:282 Witness)
        </span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleStampThumbPrint}
            className="inline-flex items-center gap-1.5 rounded-lg border border-stone-200 bg-[#F8F7F3] px-2.5 py-1 text-[11px] font-medium text-stone-700 transition-colors hover:border-[#9B1C2E]/40 hover:bg-stone-100 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-300 dark:hover:bg-slate-800/60"
          >
            <Fingerprint className="h-3 w-3 text-[#9B1C2E] dark:text-rose-400" />
            <span>Thumb Stamp</span>
          </button>
          <button
            type="button"
            onClick={handleClear}
            className="inline-flex items-center gap-1.5 rounded-lg border border-stone-200 bg-[#F8F7F3] px-2.5 py-1 text-[11px] font-medium text-stone-700 transition-colors hover:bg-stone-100 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-300 dark:hover:bg-slate-800/60"
          >
            <Eraser className="h-3 w-3" />
            <span>Clear</span>
          </button>
        </div>
      </div>

      <canvas
        ref={canvasRef}
        width={480}
        height={110}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="h-28 w-full touch-none rounded-xl border border-stone-300 bg-white dark:border-slate-700"
      />
      {!hasInk && (
        <div className="text-[11px] text-stone-500 dark:text-stone-400">
          Draw customer signature with mouse/touch or tap Thumb Stamp.
        </div>
      )}
    </div>
  );
}
