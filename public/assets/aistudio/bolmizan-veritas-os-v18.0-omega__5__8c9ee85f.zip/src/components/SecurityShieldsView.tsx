import { useState } from 'react';
import { startRegistration } from '@simplewebauthn/browser';
import {
  CheckCircle2,
  Fingerprint,
  Lock,
  ShieldAlert,
  ShieldCheck,
  Volume2,
} from 'lucide-react';
import type {
  ScamAnalysisResult,
  UiLanguage,
  UserPublicProfile,
  WebhookEventRecord,
} from '../../shared/types';
import { apiFetch } from '../utils/sessionClient';
import { speakMultilingual } from '../utils/ttsAndOffline';

interface SecurityShieldsViewProps {
  user: UserPublicProfile;
  webhooks: WebhookEventRecord[];
  killSwitchFrozen: boolean;
  language: UiLanguage;
  onPasskeyAdded: () => Promise<void>;
}

export function SecurityShieldsView({
  user,
  webhooks,
  killSwitchFrozen,
  language,
  onPasskeyAdded,
}: SecurityShieldsViewProps) {
  const [smsText, setSmsText] = useState(
    'مبارک ہو! 8171 بینظیر انکم سپورٹ سے آپ کے 25,000 روپے نکلے ہیں، تصدیق کے لیے اپنا OTP اور پن کوڈ بھیجیں۔'
  );
  const [scamResult, setScamResult] = useState<ScamAnalysisResult | null>(null);
  const [scanning, setScanning] = useState(false);

  const [pinInput, setPinInput] = useState('');
  const [safetyCoverOpen, setSafetyCoverOpen] = useState(false);
  const [killMsg, setKillMsg] = useState<string | null>(null);
  const [passkeyMsg, setPasskeyMsg] = useState<string | null>(null);

  const [whPayload, setWhPayload] = useState(webhooks[0]?.payloadJson || '{}');
  const [whSig, setWhSig] = useState(webhooks[0]?.signatureHeader || '');
  const [whValid, setWhValid] = useState<boolean | null>(null);

  async function handleScamScan(e: React.FormEvent) {
    e.preventDefault();
    setScanning(true);
    try {
      const res = await apiFetch('/api/security/scam-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: smsText }),
      });
      if (res.ok) {
        const result = (await res.json()) as ScamAnalysisResult;
        setScamResult(result);
        if (result.verdict === 'high_risk_scam') {
          speakMultilingual(
            language === 'ur' || language === 'sd' ? result.advisoryUr : result.advisoryEn,
            language === 'sd' ? 'ur' : language
          );
        }
      }
    } finally {
      setScanning(false);
    }
  }

  async function handleToggleKillSwitch() {
    setKillMsg(null);
    const res = await apiFetch('/api/security/kill-switch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: pinInput, freeze: !killSwitchFrozen }),
    });
    const json = (await res.json()) as { error?: string; killSwitchFrozen?: boolean };
    if (!res.ok) {
      setKillMsg(json.error || 'Failed');
      return;
    }
    setKillMsg(
      json.killSwitchFrozen
        ? 'All 21 outbound payment rails are now FROZEN.'
        : 'Payment rails restored to normal operation.'
    );
  }

  async function handleEnrollPasskey() {
    setPasskeyMsg(null);
    try {
      const optRes = await apiFetch('/api/auth/webauthn/register-options', { method: 'POST' });
      const options = (await optRes.json()) as Parameters<typeof startRegistration>[0]['optionsJSON'];
      const attResp = await startRegistration({ optionsJSON: options });
      const verifyRes = await apiFetch('/api/auth/webauthn/register-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(attResp),
      });
      const verifyData = (await verifyRes.json()) as { verified?: boolean; error?: string };
      if (!verifyRes.ok || !verifyData.verified) {
        setPasskeyMsg(verifyData.error || 'Passkey enrollment failed.');
        return;
      }
      setPasskeyMsg('FIDO2/WebAuthn Passkey registered successfully.');
      await onPasskeyAdded();
    } catch (err) {
      setPasskeyMsg(err instanceof Error ? err.message : 'Passkey setup cancelled');
    }
  }

  async function handleVerifyWebhook(e: React.FormEvent) {
    e.preventDefault();
    const res = await apiFetch('/api/webhooks/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ payloadJson: whPayload, signatureHeader: whSig }),
    });
    const data = (await res.json()) as { valid?: boolean };
    setWhValid(Boolean(data.valid));
  }

  return (
    <div className="space-y-6 veritas-enter">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Anti-Scam Reality Truth-Filter */}
        <form
          onSubmit={handleScamScan}
          className="space-y-4 rounded-xl border border-stone-200 bg-white p-6 lg:col-span-7 dark:border-slate-800 dark:bg-[#111922]"
        >
          <div className="flex items-center justify-between gap-3">
            <div>
              <h2 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
                Anti-Scam Reality Truth-Filter (Urdu / Sindhi / English)
              </h2>
              <p className="mt-0.5 text-xs text-stone-500 dark:text-stone-400">
                Detects OTP theft, fake 8171/BISP grants, prize lotteries, and SBP/bank impersonation with instant voice alerts
              </p>
            </div>
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#9B1C2E]/25 bg-[#9B1C2E]/10 text-[#9B1C2E] dark:text-rose-400">
              <ShieldAlert className="h-5 w-5" />
            </div>
          </div>

          <textarea
            rows={4}
            value={smsText}
            onChange={(e) => setSmsText(e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-[#F8F7F3] p-3.5 text-sm text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100 dark:focus:border-teal-400"
          />

          <div className="flex flex-wrap gap-2">
            <button
              type="submit"
              disabled={scanning}
              className="rounded-xl bg-teal-700 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
            >
              {scanning ? 'Scanning UTF-8 Patterns...' : 'Scan Message for Scam'}
            </button>
            <button
              type="button"
              onClick={() =>
                setSmsText(
                  'Dear customer, your Raast account is blocked. Verify KYC immediately at http://bit.ly/sbp-fix and share OTP.'
                )
              }
              className="rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 text-xs font-medium text-stone-700 transition-colors hover:bg-stone-100 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-300 dark:hover:bg-slate-800/60"
            >
              English Phishing
            </button>
            <button
              type="button"
              onClick={() =>
                setSmsText(
                  'مبارڪ! بينظير انڪم سپورٽ مان اوهان جا 25,000 رپيا نڪتا آهن، او ٽي پي ۽ پن ڪوڊ فوري موڪليو.'
                )
              }
              className="rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 text-xs font-medium text-stone-700 transition-colors hover:bg-stone-100 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-300 dark:hover:bg-slate-800/60"
            >
              سنڌي فراڈ نمونو
            </button>
          </div>

          {scamResult && (
            <div
              className={`space-y-2 rounded-xl border p-4 text-xs ${
                scamResult.verdict === 'high_risk_scam'
                  ? 'border-[#9B1C2E]/35 bg-[#9B1C2E]/8 text-[#7F1D1D] dark:text-rose-200'
                  : scamResult.verdict === 'suspicious'
                    ? 'border-amber-500/35 bg-amber-500/10 text-amber-900 dark:text-amber-200'
                    : 'border-teal-600/35 bg-teal-600/10 text-teal-900 dark:text-teal-200'
              }`}
            >
              <div className="flex items-center justify-between font-semibold">
                <span>
                  Verdict: {scamResult.verdict.replace(/_/g, ' ').toUpperCase()} (Risk {scamResult.riskScore}/100)
                </span>
                <button
                  type="button"
                  onClick={() => speakMultilingual(scamResult.advisoryUr, 'ur')}
                  className="inline-flex items-center gap-1 underline"
                >
                  <Volume2 className="h-3.5 w-3.5" />
                  <span>Voice Alert</span>
                </button>
              </div>
              <p>{scamResult.advisoryEn}</p>
              <p dir="rtl" className="font-medium">
                {scamResult.advisoryUr}
              </p>
              {scamResult.matchedSignals.length > 0 && (
                <div className="pt-1 font-mono text-[11px]">
                  Signals: {scamResult.matchedSignals.join(' · ')}
                </div>
              )}
            </div>
          )}
        </form>

        {/* Master AI Kill-Switch & WebAuthn Passkeys */}
        <div className="space-y-5 lg:col-span-5">
          <div className="rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
            <h3 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
              Master AI Kill-Switch
            </h3>
            <p className="mt-1 text-xs text-stone-500 dark:text-stone-400">
              Emergency timing-safe PIN-locked freeze over all 21 outbound payment rails. Trivial PINs are rejected with brute-force lockout protection.
            </p>
            <div className="mt-4 space-y-3">
              <button
                type="button"
                onClick={() => setSafetyCoverOpen((open) => !open)}
                className={`flex w-full items-center justify-between rounded-xl border px-3.5 py-2.5 text-xs font-semibold transition-all ${
                  safetyCoverOpen
                    ? 'border-[#9B1C2E]/40 bg-[#9B1C2E]/10 text-[#9B1C2E] dark:text-rose-300'
                    : 'border-stone-200 bg-[#F8F7F3] text-stone-700 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-300'
                }`}
              >
                <span>
                  {safetyCoverOpen
                    ? 'Safety Guard Lifted — Armed for PIN Execution'
                    : 'Armored Safety Cover Closed — Click to Flip Open'}
                </span>
                <span className="font-mono text-[10px]">
                  {safetyCoverOpen ? 'OPEN' : 'LOCKED'}
                </span>
              </button>

              <div className="flex items-center gap-2">
                <input
                  type="password"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="Sovereign PIN"
                  className="w-36 rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 font-mono text-sm text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
                />
                <button
                  type="button"
                  disabled={!safetyCoverOpen}
                  onClick={handleToggleKillSwitch}
                  className={`flex-1 rounded-xl px-4 py-2 text-xs font-semibold text-white transition-opacity disabled:cursor-not-allowed disabled:opacity-40 ${
                    killSwitchFrozen
                      ? 'bg-teal-700 hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400'
                      : 'bg-[#9B1C2E] hover:bg-rose-800'
                  }`}
                >
                  {killSwitchFrozen ? 'Unlock All Payment Rails' : 'FREEZE ALL RAILS NOW'}
                </button>
              </div>
            </div>
            {killMsg && <p className="mt-2 text-xs font-medium text-stone-700 dark:text-stone-300">{killMsg}</p>}
          </div>

          <div className="rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
            <div className="flex items-center justify-between">
              <h3 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
                FIDO2 / WebAuthn Biometric Passkeys
              </h3>
              <Fingerprint className="h-5 w-5 text-teal-700 dark:text-teal-400" />
            </div>
            <p className="mt-1 text-xs text-stone-500 dark:text-stone-400">
              Registered Passkeys on {user.email}: <strong className="font-mono">{user.passkeyCount}</strong>
            </p>
            <button
              type="button"
              onClick={handleEnrollPasskey}
              className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-stone-200 bg-[#F8F7F3] px-4 py-2.5 text-xs font-semibold text-stone-800 transition-colors hover:bg-stone-100 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-200 dark:hover:bg-slate-800/60"
            >
              <Fingerprint className="h-4 w-4 text-teal-700 dark:text-teal-400" />
              <span>Enroll Device Passkey / TouchID</span>
            </button>
            {passkeyMsg && (
              <p className="mt-2 text-xs font-medium text-teal-700 dark:text-teal-400">
                {passkeyMsg}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* HMAC-SHA256 Webhook Verifier */}
      <form
        onSubmit={handleVerifyWebhook}
        className="space-y-4 rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]"
      >
        <div className="flex items-center gap-2">
          <Lock className="h-4 w-4 text-teal-700 dark:text-teal-400" />
          <h3 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
            HMAC-SHA256 Webhook Cryptographic Verifier
          </h3>
        </div>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
              Signature Header
            </label>
            <input
              type="text"
              value={whSig}
              onChange={(e) => {
                setWhSig(e.target.value);
                setWhValid(null);
              }}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 font-mono text-xs text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
              Raw Payload JSON
            </label>
            <input
              type="text"
              value={whPayload}
              onChange={(e) => {
                setWhPayload(e.target.value);
                setWhValid(null);
              }}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 font-mono text-xs text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
            />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-4">
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 rounded-xl bg-teal-700 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
          >
            <ShieldCheck className="h-4 w-4" />
            <span>Verify HMAC Signature</span>
          </button>
          {whValid !== null && (
            <span
              className={`inline-flex items-center gap-1.5 text-xs font-semibold ${
                whValid ? 'text-teal-700 dark:text-teal-400' : 'text-[#9B1C2E] dark:text-rose-400'
              }`}
            >
              {whValid ? <CheckCircle2 className="h-4 w-4" /> : <ShieldAlert className="h-4 w-4" />}
              <span>{whValid ? 'Authentic Signature Verified' : 'Tampered / Invalid Signature'}</span>
            </span>
          )}
        </div>
      </form>
    </div>
  );
}
