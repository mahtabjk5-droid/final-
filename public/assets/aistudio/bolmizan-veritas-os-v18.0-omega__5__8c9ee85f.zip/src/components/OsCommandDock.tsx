import { useEffect, useMemo, useState } from 'react';
import {
  BookOpenCheck,
  Calculator,
  CreditCard,
  Crown,
  GitCompareArrows,
  LayoutDashboard,
  Mic,
  Search,
  ShieldCheck,
  Sparkles,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import type { NavSection, UiDisplayMode } from '../../shared/types';

interface OsCommandDockProps {
  open: boolean;
  onClose: () => void;
  displayMode: UiDisplayMode;
  soundMuted: boolean;
  onNavigate: (section: NavSection) => void;
  onToggleDisplayMode: () => void;
  onOpenVoice: () => void;
  onReplayWelcome: () => void;
  onToggleSound: () => void;
}

const DOCK_ITEMS: Array<{ id: NavSection; label: string; icon: typeof LayoutDashboard }> = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'ledger', label: 'Shariah Ledger', icon: BookOpenCheck },
  { id: 'payments', label: '21 Global Rails', icon: CreditCard },
  { id: 'treasury', label: 'Treasury & Mazdoor', icon: Crown },
  { id: 'mukasa', label: 'Mukasa & Stock', icon: GitCompareArrows },
  { id: 'zakat', label: 'Zakat & Ushr', icon: Calculator },
  { id: 'security', label: 'Truth & Security', icon: ShieldCheck },
];

export function OsCommandDock({
  open,
  onClose,
  displayMode,
  soundMuted,
  onNavigate,
  onToggleDisplayMode,
  onOpenVoice,
  onReplayWelcome,
  onToggleSound,
}: OsCommandDockProps) {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (open) onClose();
        else window.dispatchEvent(new CustomEvent('sindh-mizan-open-palette'));
      } else if (e.key === 'Escape' && open) {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, onClose]);

  const commands = useMemo(
    () => [
      ...DOCK_ITEMS.map((item) => ({
        id: `nav:${item.id}`,
        label: `Go to ${item.label}`,
        keywords: `${item.id} ${item.label}`,
        icon: item.icon,
        run: () => onNavigate(item.id),
      })),
      {
        id: 'action:voice',
        label: 'Speak New Entry (MediaRecorder -> Gemini 4 AI)',
        keywords: 'voice mic audio hisab gemini speak',
        icon: Mic,
        run: onOpenVoice,
      },
      {
        id: 'action:mode',
        label:
          displayMode === 'sabziwala'
            ? 'Switch to Executive Atelier Mode'
            : 'Switch to 3-Tap Mazdoor / Sabzi-Wala Counter',
        keywords: 'mochi mazdoor sabziwala pos command mode counter',
        icon: LayoutDashboard,
        run: onToggleDisplayMode,
      },
      {
        id: 'action:welcome',
        label: 'Open Indus Heritage Briefing & Map',
        keywords: 'bhali kare aaya welcome sindh mohenjo daro heritage',
        icon: Sparkles,
        run: onReplayWelcome,
      },
      {
        id: 'action:sound',
        label: soundMuted ? 'Play Bhitai Acoustic Synth' : 'Mute Bhitai Acoustic Synth',
        keywords: 'sound audio tambura surando alghoza mute unmute',
        icon: soundMuted ? VolumeX : Volume2,
        run: onToggleSound,
      },
    ],
    [displayMode, onNavigate, onOpenVoice, onReplayWelcome, onToggleDisplayMode, onToggleSound, soundMuted]
  );

  const filteredCommands = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return commands;
    return commands.filter(
      (c) => c.label.toLowerCase().includes(q) || c.keywords.toLowerCase().includes(q)
    );
  }, [commands, query]);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="SINDH-MIZAN Quick Command Search"
      className="fixed inset-0 z-50 flex items-start justify-center bg-slate-950/55 px-4 pt-20 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="veritas-enter w-full max-w-lg overflow-hidden rounded-xl border border-stone-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-[#111922]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2.5 border-b border-stone-200 px-4 py-3 dark:border-slate-800">
          <Search className="h-4 w-4 text-teal-700 dark:text-teal-400" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Jump to module, Voice Capture, 3-Tap Counter, Synth..."
            className="flex-1 bg-transparent text-sm text-slate-900 placeholder-slate-400 focus:outline-none dark:text-slate-100"
          />
          <button
            type="button"
            onClick={onClose}
            aria-label="Close quick search"
            className="rounded-lg p-1 text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="max-h-80 divide-y divide-stone-100 overflow-y-auto dark:divide-slate-800/80">
          {filteredCommands.map((cmd) => {
            const Icon = cmd.icon;
            return (
              <button
                key={cmd.id}
                type="button"
                onClick={() => {
                  cmd.run();
                  onClose();
                  setQuery('');
                }}
                className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left text-xs font-medium text-slate-800 transition-colors hover:bg-teal-50/70 dark:text-slate-200 dark:hover:bg-teal-950/30"
              >
                <span className="flex items-center gap-2.5">
                  <Icon className="h-4 w-4 text-teal-700 dark:text-teal-400" />
                  <span>{cmd.label}</span>
                </span>
                <span className="font-mono text-[10px] text-slate-400">Open</span>
              </button>
            );
          })}
          {filteredCommands.length === 0 && (
            <div className="px-4 py-6 text-center text-xs text-slate-400">
              No matching command found.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
