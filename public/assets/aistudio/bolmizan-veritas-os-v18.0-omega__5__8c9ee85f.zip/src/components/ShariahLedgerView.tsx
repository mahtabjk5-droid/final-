import { useState } from 'react';
import {
  Clock,
  FileText,
  HeartHandshake,
  Link2,
  Mic,
  Printer,
  Share2,
  ShieldCheck,
  Sparkles,
  Volume2,
  X,
} from 'lucide-react';
import type {
  BranchId,
  ChainVerificationResult,
  CurrencyCode,
  LedgerEntry,
  LedgerEntryType,
  UiLanguage,
  VoiceParseResult,
} from '../../shared/types';
import { CURRENCY_METADATA } from '../../shared/rails';
import { formatCurrency } from '../utils/formatters';
import { apiFetch } from '../utils/sessionClient';
import { sufiSoundscape } from '../utils/sufiSoundscape';
import {
  enqueueOfflineAction,
  renderQrDataUrl,
  speakMultilingual,
  useCognitiveIntent,
} from '../utils/ttsAndOffline';
import { SignaturePad } from './SignaturePad';
import { SindhMizanEmblem } from './SindhMizanEmblem';

interface ShariahLedgerViewProps {
  entries: LedgerEntry[];
  chainVerification: ChainVerificationResult;
  businessName: string;
  language: UiLanguage;
  pardaActive: boolean;
  simulateOffline: boolean;
  onQueuedOffline: () => void;
  onOpenVoiceCapture?: () => void;
}

const MULTILINGUAL_SAMPLES: Array<{ label: string; text: string }> = [
  { label: 'اردو', text: 'محمد علی کو 14,500 روپے چینی اور گھی ادھار دیا' },
  { label: 'سنڌي', text: 'محبوب علي کي 14,500 جو اڌار ڏنو' },
  { label: 'العربية', text: 'عقد مرابحة إسلامي ٤٦٠٠ ريال تمور عجوة للتصدير' },
  { label: 'English', text: 'Murabaha wheat export contract 1850 USD to Dubai Marina' },
];

export function ShariahLedgerView({
  entries,
  chainVerification,
  businessName,
  language,
  pardaActive,
  simulateOffline,
  onQueuedOffline,
  onOpenVoiceCapture,
}: ShariahLedgerViewProps) {
  const [voiceInput, setVoiceInput] = useState(
    'Muhammad Ali ko 14,500 ka chini aur ghee udhaar diya'
  );
  const [parsing, setParsing] = useState(false);
  const [branchId, setBranchId] = useState<Exclude<BranchId, 'all'>>('sakrand_hq');
  const [entryType, setEntryType] = useState<LedgerEntryType>('udhaar_given');
  const [counterparty, setCounterparty] = useState('Muhammad Ali');
  const [amount, setAmount] = useState('14500');
  const [currency, setCurrency] = useState<CurrencyCode>('PKR');
  const [costBasisUsd, setCostBasisUsd] = useState('1000');
  const [murabahaMarkupUsd, setMurabahaMarkupUsd] = useState('120');
  const [itemsSummary, setItemsSummary] = useState('Chini 50kg & Cooking Ghee');
  const [dueDate, setDueDate] = useState(
    () => new Date(Date.now() + 15 * 86400_000).toISOString().slice(0, 10)
  );
  const [interestTest, setInterestTest] = useState('0');
  const [signatureDataUrl, setSignatureDataUrl] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ ok: boolean; text: string } | null>(null);
  const [verifySnapshot, setVerifySnapshot] = useState<ChainVerificationResult>(chainVerification);
  const [selectedBlockId, setSelectedBlockId] = useState<string | null>(
    () => entries[0]?.id ?? null
  );
  const [sealImgFailed, setSealImgFailed] = useState(false);
  const [receiptModal, setReceiptModal] = useState<{
    entry: LedgerEntry;
    qrDataUrl: string;
  } | null>(null);

  const { humanScore, recordKeystrokeOrTap, resetCadence } = useCognitiveIntent();

  const orderedAsc = [...entries].sort((a, b) => a.index - b.index);
  const inspectedBlock =
    entries.find((e) => e.id === selectedBlockId) ?? orderedAsc[orderedAsc.length - 1] ?? null;

  async function handleParseVoice() {
    setParsing(true);
    setFeedback(null);
    try {
      const res = await apiFetch('/api/voice/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transcript: voiceInput }),
      });
      if (!res.ok) throw new Error('Parse error');
      const parsed = (await res.json()) as VoiceParseResult;
      setCounterparty(parsed.customerName);
      setAmount(String(parsed.amount));
      setCurrency(parsed.currency);
      setEntryType(parsed.entryType);
      setItemsSummary(parsed.itemsSummary);
      if (parsed.dueDate) setDueDate(parsed.dueDate);
      setFeedback({
        ok: true,
        text: `Extracted via ${parsed.parserEngine} (detected ${parsed.languageDetected.toUpperCase()})`,
      });
    } catch {
      setFeedback({ ok: false, text: 'Voice parse unavailable offline; enter fields manually.' });
    } finally {
      setParsing(false);
    }
  }

  function handleMicCapture() {
    if (onOpenVoiceCapture) {
      onOpenVoiceCapture();
      return;
    }
    const win = window as unknown as {
      SpeechRecognition?: new () => {
        lang: string;
        onresult: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
        start: () => void;
      };
      webkitSpeechRecognition?: new () => {
        lang: string;
        onresult: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
        start: () => void;
      };
    };
    const SR = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SR) {
      setFeedback({
        ok: false,
        text: 'Browser SpeechRecognition unsupported here — edit text or choose a UTF-8 sample & click Parse.',
      });
      return;
    }
    const rec = new SR();
    rec.lang = language === 'ur' ? 'ur-PK' : language === 'ar' ? 'ar-SA' : 'en-PK';
    rec.onresult = (event) => {
      const text = event.results[0]?.[0]?.transcript || '';
      if (text) setVoiceInput(text);
    };
    rec.start();
  }

  async function handleCreateEntry(e: React.FormEvent) {
    e.preventDefault();
    setFeedback(null);

    if (Number(interestTest) > 0) {
      setFeedback({
        ok: false,
        text: 'Zero-Riba Shariah Gate Blocked Submission: Interest / late penalty rates must strictly be 0%.',
      });
      return;
    }

    setSubmitting(true);
    const isTradeContract = entryType === 'murabaha_contract' || entryType === 'salam_contract';
    const payload = {
      branchId,
      entryType,
      creditorName: entryType === 'udhaar_taken' ? counterparty : businessName,
      debtorName: entryType === 'udhaar_taken' ? businessName : counterparty,
      amount: Number(amount),
      currency,
      costBasisUsd: isTradeContract ? Number(costBasisUsd) : undefined,
      murabahaMarkupUsd: isTradeContract ? Number(murabahaMarkupUsd) : undefined,
      itemsSummary,
      dueDate: entryType === 'cash_sale' ? null : dueDate,
      language,
      voiceTranscript: voiceInput,
      signatureDataUrl,
      cognitiveHumanScore: humanScore,
      interestRate: Number(interestTest),
    };

    if (simulateOffline || !navigator.onLine) {
      enqueueOfflineAction({
        endpoint: '/api/ledger/entries',
        method: 'POST',
        body: payload,
        idempotencyKey: `off_led_${Date.now()}`,
        label: `${counterparty} (${formatCurrency(Number(amount), currency)})`,
      });
      onQueuedOffline();
      setFeedback({
        ok: true,
        text: 'Offline Mode: Entry safely queued in localStorage for auto-sync.',
      });
      setSubmitting(false);
      return;
    }

    try {
      const res = await apiFetch('/api/ledger/entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as {
        error?: string;
        entry?: LedgerEntry;
        chainVerification?: ChainVerificationResult;
      };
      if (!res.ok) {
        setFeedback({ ok: false, text: json.error || 'Rejected by ledger gate.' });
        return;
      }
      if (json.chainVerification) setVerifySnapshot(json.chainVerification);
      if (json.entry) setSelectedBlockId(json.entry.id);
      setSignatureDataUrl(null);
      resetCadence();
      sufiSoundscape.playSealChime();
      setFeedback({
        ok: true,
        text: `Block #${json.entry?.index} (${json.entry?.reference}) sealed onto SHA-256 chain.`,
      });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleVerifyChain() {
    const res = await apiFetch('/api/ledger/verify');
    if (res.ok) {
      const result = (await res.json()) as ChainVerificationResult;
      setVerifySnapshot(result);
    }
  }

  async function handleGrace15d(id: string) {
    await apiFetch(`/api/ledger/${id}/grace-15d`, { method: 'POST' });
  }

  async function handleSadqah(id: string) {
    await apiFetch(`/api/ledger/${id}/sadqah`, { method: 'POST' });
  }

  async function openEtoReceipt(entry: LedgerEntry) {
    const verificationPayload = JSON.stringify({
      issuer: 'SINDH-MIZAN OS™ (BolMizan VERITAS) · Sakrand, Sindh, Pakistan',
      act: 'ETO-2002 / UNCITRAL',
      ref: entry.reference,
      amount: entry.amount,
      currency: entry.currency,
      witnesses: entry.witnesses?.length ?? 0,
      hash: entry.hash,
    });
    const qrDataUrl = await renderQrDataUrl(verificationPayload);
    setReceiptModal({ entry, qrDataUrl });
  }

  function buildWhatsappShareHref(entry: LedgerEntry): string {
    const msg = `SINDH-MIZAN OS™ (Sakrand, Sindh HQ)\nRef: ${entry.reference} (0% Riba)\nCreditor: ${entry.creditorName}\nDebtor: ${entry.debtorName}\nAmount: ${formatCurrency(entry.amount, entry.currency)}\nGoods: ${entry.itemsSummary}\nOtaq Witnesses: ${entry.witnesses?.length ?? 0}\nSHA-256: ${entry.hash.slice(0, 20)}...`;
    return `https://wa.me/?text=${encodeURIComponent(msg)}`;
  }

  const intentWidth = Math.max(12, Math.min(100, humanScore));
  const fieldCls =
    'mt-1 w-full rounded-xl border border-stone-200 bg-[#F8F7F3] px-3 py-2 text-sm text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100 dark:focus:border-teal-400';

  return (
    <div className="space-y-6 veritas-enter">
      {/* SHA-256 Merkle DAG Strip */}
      <section className="space-y-4 rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-teal-600/30 bg-teal-700/10">
              <ShieldCheck
                className={`h-5 w-5 ${
                  verifySnapshot.intact ? 'text-teal-700 dark:text-teal-400' : 'text-[#9B1C2E] dark:text-rose-400'
                }`}
              />
            </div>
            <div>
              <h2 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
                Quran 2:282 &amp; 2:280 Shariah Smart Ledger + Murabaha / Salam
              </h2>
              <div className="font-mono text-xs text-stone-500 tabular-nums dark:text-stone-400">
                {verifySnapshot.verifiedBlocks}/{verifySnapshot.totalBlocks} SHA-256 blocks verified · Chain{' '}
                {verifySnapshot.intact ? 'INTACT' : 'BROKEN'}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleVerifyChain}
            className="rounded-xl border border-stone-200 bg-[#F8F7F3] px-3.5 py-2 text-xs font-semibold text-stone-800 transition-colors hover:border-teal-600/40 hover:bg-stone-100 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-200 dark:hover:bg-slate-800"
          >
            Re-Verify All SHA-256 Hashes
          </button>
        </div>

        {orderedAsc.length > 0 && (
          <div className="space-y-3 border-t border-stone-200 pt-4 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-stone-700 dark:text-stone-300">
                Merkle Hash Chain Explorer
              </span>
              <span className="font-mono text-[11px] text-stone-500 dark:text-stone-400">
                Genesis → Block #{orderedAsc[orderedAsc.length - 1]?.index}
              </span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {orderedAsc.map((blk, i) => {
                const selected = inspectedBlock?.id === blk.id;
                return (
                  <div key={blk.id} className="flex shrink-0 items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedBlockId(blk.id)}
                      className={`min-w-[148px] rounded-xl border px-3 py-2 text-left transition-colors ${
                        selected
                          ? 'border-teal-600 bg-teal-700/8 dark:border-teal-400 dark:bg-teal-500/12'
                          : 'border-stone-200 bg-[#F8F7F3] hover:border-teal-600/40 dark:border-slate-800 dark:bg-[#0B1117]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 font-mono text-[11px]">
                        <span className="font-bold text-stone-900 dark:text-stone-100">
                          #{blk.index}
                        </span>
                        <span className="text-stone-500 dark:text-stone-400">{blk.reference}</span>
                      </div>
                      <div className="mt-1 truncate text-xs font-medium text-stone-700 dark:text-stone-300">
                        {blk.debtorName}
                      </div>
                      <div className="mt-0.5 font-mono text-[10px] text-teal-700 dark:text-teal-400">
                        {blk.hash.slice(0, 12)}…
                      </div>
                    </button>
                    {i < orderedAsc.length - 1 && (
                      <Link2 className="h-3.5 w-3.5 shrink-0 text-stone-400" />
                    )}
                  </div>
                );
              })}
            </div>

            {inspectedBlock && (
              <div className="grid grid-cols-1 gap-2 rounded-xl border border-stone-200 bg-[#F8F7F3] p-3 font-mono text-[11px] sm:grid-cols-2 dark:border-slate-800 dark:bg-[#0B1117]">
                <div className="truncate">
                  <span className="text-stone-500">prevHash: </span>
                  <span className="text-stone-800 dark:text-stone-200">
                    {inspectedBlock.prevHash}
                  </span>
                </div>
                <div className="truncate">
                  <span className="text-stone-500">blockHash: </span>
                  <span className="text-teal-700 dark:text-teal-400">
                    {inspectedBlock.hash}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Multilingual Voice-to-Hisab & Murabaha/Salam Entry Form */}
      <form
        onSubmit={handleCreateEntry}
        className="space-y-4 rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]"
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-editorial text-xl font-bold text-stone-900 dark:text-stone-100">
              Multilingual Voice-to-Hisab &amp; Zero-Riba Contract Engine
            </h2>
            <p className="mt-0.5 text-xs text-stone-500 dark:text-stone-400">
              Urdu (اردو), Sindhi (سنڌي), Arabic (العربية) &amp; English · 0% Interest Mathematical Gate
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="w-44 rounded-xl border border-stone-200 bg-[#F8F7F3] px-2.5 py-1.5 dark:border-slate-800 dark:bg-[#0B1117]">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-stone-500 dark:text-stone-400">Human Cadence</span>
                <span className="font-mono font-semibold text-teal-700 tabular-nums dark:text-teal-400">
                  {humanScore}%
                </span>
              </div>
              <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-stone-200 dark:bg-slate-800">
                <div
                  className="h-full rounded-full bg-teal-600 transition-all duration-200 dark:bg-teal-400"
                  style={{ width: `${intentWidth}%` }}
                />
              </div>
            </div>

            <button
              type="button"
              onClick={handleMicCapture}
              aria-label="Bioluminescent Voice Orb"
              className="inline-flex items-center gap-2 rounded-xl border border-teal-600/35 bg-[#0D2327] px-3.5 py-2 text-xs font-semibold text-teal-200 transition-all hover:bg-[#133338]"
            >
              <span className="flex h-4 w-4 items-center justify-center rounded-full bg-teal-400 text-[#0D2327]">
                <Mic className="h-2.5 w-2.5" />
              </span>
              <span>Voice Orb</span>
            </button>
            <button
              type="button"
              disabled={parsing}
              onClick={handleParseVoice}
              className="inline-flex items-center gap-1.5 rounded-xl bg-teal-700 px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>{parsing ? 'Extracting...' : 'Parse with Gemini / UTF-8'}</span>
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-medium text-stone-500 dark:text-stone-400">
            Quick UTF-8 Samples:
          </span>
          {MULTILINGUAL_SAMPLES.map((sample) => (
            <button
              key={sample.label}
              type="button"
              onClick={() => {
                setVoiceInput(sample.text);
                recordKeystrokeOrTap();
              }}
              className="rounded-lg border border-stone-200 bg-[#F8F7F3] px-2.5 py-1 text-xs font-medium text-stone-700 hover:border-teal-600/40 dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-200"
            >
              {sample.label}
            </button>
          ))}
        </div>

        <input
          type="text"
          value={voiceInput}
          onChange={(e) => {
            setVoiceInput(e.target.value);
            recordKeystrokeOrTap();
          }}
          className="w-full rounded-xl border border-stone-200 bg-[#F8F7F3] px-3.5 py-2.5 text-sm text-stone-900 focus:border-teal-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
        />

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <div>
            <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
              Branch Hub
            </label>
            <select
              value={branchId}
              onChange={(e) => setBranchId(e.target.value as Exclude<BranchId, 'all'>)}
              className={fieldCls}
            >
              <option value="sakrand_hq">Sakrand Main HQ</option>
              <option value="karachi_port">Karachi Port</option>
              <option value="riyadh_hub">Riyadh Hub</option>
              <option value="dubai_marina">Dubai Marina</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
              Contract Type
            </label>
            <select
              value={entryType}
              onChange={(e) => setEntryType(e.target.value as LedgerEntryType)}
              className={fieldCls}
            >
              <option value="udhaar_given">Udhaar Given</option>
              <option value="udhaar_taken">Udhaar Taken</option>
              <option value="cash_sale">Cash Sale (Naqad)</option>
              <option value="payment_received">Payment Received</option>
              <option value="murabaha_contract">Murabaha (Cost-Plus)</option>
              <option value="salam_contract">Bay&apos; Salam (Forward)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
              Party Name
            </label>
            <input
              type="text"
              required
              value={counterparty}
              onChange={(e) => {
                setCounterparty(e.target.value);
                recordKeystrokeOrTap();
              }}
              className={fieldCls}
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
              Amount
            </label>
            <input
              type="number"
              required
              min="1"
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                recordKeystrokeOrTap();
              }}
              className={`${fieldCls} font-mono`}
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
              Currency
            </label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className={fieldCls}
            >
              {(Object.keys(CURRENCY_METADATA) as CurrencyCode[]).map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
              Riba / Interest % (0)
            </label>
            <input
              type="number"
              step="0.1"
              value={interestTest}
              onChange={(e) => setInterestTest(e.target.value)}
              className={`${fieldCls} font-mono`}
            />
          </div>
        </div>

        {(entryType === 'murabaha_contract' || entryType === 'salam_contract') && (
          <div className="grid grid-cols-1 gap-3 rounded-xl border border-teal-600/25 bg-teal-700/5 p-3.5 sm:grid-cols-2 dark:bg-teal-500/10">
            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Disclosed Asset Cost Basis (USD)
              </label>
              <input
                type="number"
                value={costBasisUsd}
                onChange={(e) => setCostBasisUsd(e.target.value)}
                className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3 py-1.5 font-mono text-xs dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                Fixed Disclosed Murabaha Profit Margin (USD)
              </label>
              <input
                type="number"
                value={murabahaMarkupUsd}
                onChange={(e) => setMurabahaMarkupUsd(e.target.value)}
                className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3 py-1.5 font-mono text-xs dark:border-slate-800 dark:bg-[#0B1117] dark:text-stone-100"
              />
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
              Goods / Trade Commodity Description
            </label>
            <input
              type="text"
              required
              value={itemsSummary}
              onChange={(e) => setItemsSummary(e.target.value)}
              className={fieldCls}
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-stone-600 dark:text-stone-300">
              Maturity / Due Date (Quran 2:282)
            </label>
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className={fieldCls}
            />
          </div>
        </div>

        <SignaturePad value={signatureDataUrl} onChange={setSignatureDataUrl} />

        {feedback && (
          <div
            className={`rounded-xl border px-4 py-2.5 text-xs font-medium ${
              feedback.ok
                ? 'border-teal-600/30 bg-teal-700/10 text-teal-800 dark:text-teal-300'
                : 'border-[#9B1C2E]/30 bg-[#9B1C2E]/10 text-[#9B1C2E] dark:text-rose-300'
            }`}
          >
            {feedback.text}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="rounded-xl bg-teal-700 px-5 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-60 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
        >
          {submitting ? 'Appending to SHA-256 Chain...' : 'Seal Zero-Riba Block onto Ledger'}
        </button>
      </form>

      {/* Immutable Ledger Table */}
      <div className="overflow-hidden rounded-xl border border-stone-200 bg-white dark:border-slate-800 dark:bg-[#111922]">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-stone-200 text-xs font-medium text-stone-500 dark:border-slate-800 dark:text-stone-400">
                <th className="px-4 py-3.5">Block / Hub</th>
                <th className="px-4 py-3.5">Creditor → Debtor</th>
                <th className="px-4 py-3.5">Goods &amp; Hash</th>
                <th className="px-4 py-3.5">Status / Due</th>
                <th className="px-4 py-3.5 text-right">Amount</th>
                <th className="px-4 py-3.5 text-right">Quran 2:280, WhatsApp &amp; ETO-2002</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200 dark:divide-slate-800">
              {entries.map((entry) => (
                <tr key={entry.id} className="transition-colors hover:bg-[#F8F7F3] dark:hover:bg-slate-800/30">
                  <td className="px-4 py-3.5 font-mono text-xs tabular-nums">
                    <div className="font-semibold text-stone-900 dark:text-stone-100">
                      #{entry.index} · {entry.reference}
                    </div>
                    <div className="text-[11px] text-stone-500 dark:text-stone-400">
                      {entry.entryType.replace('_', ' ')} · {entry.branchId}
                    </div>
                  </td>
                  <td className="px-4 py-3.5">
                    <div className="font-medium text-stone-900 dark:text-stone-100">
                      {entry.creditorName} → {entry.debtorName}
                    </div>
                    <div className="text-xs text-stone-500 dark:text-stone-400">
                      Intent {entry.cognitiveHumanScore}% human · {entry.witnesses?.length ?? 0} Otaq witness
                    </div>
                  </td>
                  <td className="px-4 py-3.5">
                    <div className="max-w-xs truncate text-xs font-medium text-stone-800 dark:text-stone-200">
                      {entry.itemsSummary}
                    </div>
                    <div className="font-mono text-[11px] text-stone-500 dark:text-stone-400">
                      sha256:{entry.hash.slice(0, 14)}…
                    </div>
                  </td>
                  <td className="px-4 py-3.5 text-xs">
                    <div
                      className={`font-medium capitalize ${
                        entry.status === 'settled' || entry.status === 'sadqah_forgiven'
                          ? 'text-teal-700 dark:text-teal-400'
                          : entry.status === 'grace_15d'
                            ? 'text-amber-700 dark:text-amber-400'
                            : 'text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      {entry.status.replace('_', ' ')}
                    </div>
                    <div className="text-[11px] text-stone-500 dark:text-stone-400">
                      {entry.graceExtendedUntil
                        ? `Grace to ${entry.graceExtendedUntil}`
                        : entry.dueDate
                          ? `Due ${entry.dueDate}`
                          : 'Immediate'}
                    </div>
                  </td>
                  <td
                    className={`px-4 py-3.5 text-right font-mono text-xs font-semibold tabular-nums text-stone-900 dark:text-stone-100 ${
                      pardaActive ? 'parda-blur' : ''
                    }`}
                  >
                    {formatCurrency(entry.amount, entry.currency)}
                  </td>
                  <td className="px-4 py-3.5 text-right">
                    <div className="inline-flex flex-wrap items-center justify-end gap-1.5">
                      <button
                        type="button"
                        onClick={() =>
                          speakMultilingual(
                            `${entry.debtorName}, ${entry.amount} ${entry.currency}, ${entry.itemsSummary}`,
                            entry.language
                          )
                        }
                        title="Read Aloud (TTS)"
                        className="rounded-lg border border-stone-200 p-1.5 text-stone-600 hover:bg-stone-100 dark:border-slate-800 dark:text-stone-300 dark:hover:bg-slate-800"
                      >
                        <Volume2 className="h-3.5 w-3.5" />
                      </button>

                      <a
                        href={buildWhatsappShareHref(entry)}
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Share Receipt via WhatsApp"
                        className="rounded-lg border border-stone-200 p-1.5 text-teal-700 hover:bg-stone-100 dark:border-slate-800 dark:text-teal-400 dark:hover:bg-slate-800"
                      >
                        <Share2 className="h-3.5 w-3.5" />
                      </a>

                      {entry.status === 'open' && (
                        <button
                          type="button"
                          onClick={() => handleGrace15d(entry.id)}
                          className="inline-flex items-center gap-1 rounded-lg border border-stone-200 px-2 py-1 text-[11px] font-medium text-stone-700 hover:bg-stone-100 dark:border-slate-800 dark:text-stone-300 dark:hover:bg-slate-800"
                        >
                          <Clock className="h-3 w-3 text-amber-600 dark:text-amber-400" />
                          <span>+15d Grace</span>
                        </button>
                      )}

                      {(entry.status === 'open' || entry.status === 'grace_15d') && (
                        <button
                          type="button"
                          onClick={() => handleSadqah(entry.id)}
                          className="inline-flex items-center gap-1 rounded-lg border border-stone-200 px-2 py-1 text-[11px] font-medium text-stone-700 hover:bg-stone-100 dark:border-slate-800 dark:text-stone-300 dark:hover:bg-slate-800"
                        >
                          <HeartHandshake className="h-3 w-3 text-teal-700 dark:text-teal-400" />
                          <span>Sadqah</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => openEtoReceipt(entry)}
                        className="inline-flex items-center gap-1 rounded-lg bg-teal-700 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
                      >
                        <FileText className="h-3 w-3" />
                        <span>ETO-2002</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ETO-2002 / UNCITRAL Legal Receipt Modal */}
      {receiptModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/70 p-4 backdrop-blur-sm dark:bg-[#0B1117]/80">
          <div className="veritas-enter w-full max-w-lg rounded-2xl border border-stone-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-[#111922]">
            <div className="no-print mb-4 flex items-center justify-between border-b border-stone-200 pb-3 dark:border-slate-800">
              <div className="font-editorial text-lg font-bold text-stone-900 dark:text-stone-100">
                ETO-2002 &amp; UNCITRAL Court-Admissible Receipt
              </div>
              <button
                type="button"
                onClick={() => setReceiptModal(null)}
                className="rounded-lg p-1 text-stone-500 hover:bg-stone-100 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  {!sealImgFailed ? (
                    <img
                      src="/src/assets/images/bolmizan_ledger_seal_1794552264992.jpg"
                      alt="BolMizan Legal Seal"
                      referrerPolicy="no-referrer"
                      onError={() => setSealImgFailed(true)}
                      className="h-14 w-14 shrink-0 rounded-xl border border-stone-200 object-cover dark:border-slate-700"
                    />
                  ) : (
                    <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-teal-700 text-white">
                      <ShieldCheck className="h-6 w-6" />
                    </div>
                  )}
                  <div>
                    <div className="font-display text-base font-bold text-stone-900 dark:text-stone-100">
                      SINDH-MIZAN OS™ · {businessName}
                    </div>
                    <div className="font-medium text-teal-700 dark:text-teal-400">
                      Sakrand, Sindh, Pakistan · ETO-2002 (Sec. 7) &amp; Quran 2:282
                    </div>
                    <div className="mt-1 font-mono text-stone-700 dark:text-stone-300">
                      Ref: {receiptModal.entry.reference} · Block #{receiptModal.entry.index}
                    </div>
                  </div>
                </div>
                <img
                  src={receiptModal.qrDataUrl}
                  alt="SHA-256 verification QR"
                  className="h-24 w-24 shrink-0 rounded-xl border border-stone-200 bg-white p-1"
                />
              </div>

              <div className="space-y-1.5 rounded-xl border border-stone-200 bg-[#F8F7F3] p-3 dark:border-slate-800 dark:bg-[#0B1117]">
                <div className="flex justify-between">
                  <span className="text-stone-500">Creditor:</span>
                  <span className="font-semibold text-stone-900 dark:text-stone-100">
                    {receiptModal.entry.creditorName}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Debtor / Buyer:</span>
                  <span className="font-semibold text-stone-900 dark:text-stone-100">
                    {receiptModal.entry.debtorName}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Amount (0% Riba):</span>
                  <span className="font-mono font-bold text-stone-900 dark:text-stone-100">
                    {formatCurrency(receiptModal.entry.amount, receiptModal.entry.currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Goods:</span>
                  <span className="text-stone-900 dark:text-stone-100">
                    {receiptModal.entry.itemsSummary}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Otaq Witnesses (Shahadah):</span>
                  <span className="font-mono font-semibold text-teal-700 dark:text-teal-400">
                    {receiptModal.entry.witnesses?.length
                      ? receiptModal.entry.witnesses.map((w) => w.witnessName).join(', ')
                      : 'Digital Seal Only'}
                  </span>
                </div>
              </div>

              <div>
                <div className="font-medium text-stone-600 dark:text-stone-400">
                  SHA-256 Cryptographic Seal:
                </div>
                <div className="mt-1 break-all rounded-xl bg-[#F8F7F3] p-2 font-mono text-[10px] text-stone-800 dark:bg-[#0B1117] dark:text-stone-300">
                  {receiptModal.entry.hash}
                </div>
              </div>

              {receiptModal.entry.signatureDataUrl && (
                <div>
                  <div className="mb-1 font-medium text-stone-600 dark:text-stone-400">
                    Witnessed Signature / Thumb Impression:
                  </div>
                  <img
                    src={receiptModal.entry.signatureDataUrl}
                    alt="Customer signature"
                    className="h-20 rounded-lg border border-stone-200 bg-white p-1"
                  />
                </div>
              )}

              <div className="flex items-center justify-between gap-3 rounded-xl border border-teal-600/25 bg-gradient-to-r from-[#9B1C2E]/8 via-amber-500/8 to-teal-700/10 px-4 py-3">
                <div className="flex items-center gap-3">
                  <SindhMizanEmblem size={44} />
                  <div>
                    <div className="font-display text-xs font-bold tracking-wide text-teal-800 dark:text-teal-300">
                      MOHENJO-DARO HOLOGRAPHIC &amp; ETO-2002 SEAL
                    </div>
                    <div className="text-[11px] text-stone-600 dark:text-stone-300">
                      0% Riba · Quran 2:282 · Issued from Sakrand, Sindh HQ
                    </div>
                  </div>
                </div>
                <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-label="Molten Gold Shariah Seal">
                  <circle cx="32" cy="32" r="28" fill="#F59E0B" fillOpacity="0.22" stroke="#F59E0B" strokeWidth="2.5" strokeDasharray="4 2" />
                  <circle cx="32" cy="32" r="20" fill="#F59E0B" />
                  <path d="M23 32 L29 38 L41 26" fill="none" stroke="#0D2327" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>

              <div className="no-print flex flex-wrap items-center justify-end gap-2 pt-2">
                <a
                  href={buildWhatsappShareHref(receiptModal.entry)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-xl border border-teal-600/35 bg-teal-700/10 px-3 py-2 text-xs font-semibold text-teal-800 hover:bg-teal-700/15 dark:text-teal-300"
                >
                  <Share2 className="h-3.5 w-3.5" />
                  <span>WhatsApp Receipt</span>
                </a>
                <button
                  type="button"
                  onClick={() =>
                    speakMultilingual(
                      `Legal receipt ${receiptModal.entry.reference}. ${receiptModal.entry.debtorName}, ${receiptModal.entry.amount} ${receiptModal.entry.currency}`,
                      receiptModal.entry.language
                    )
                  }
                  className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 px-3 py-2 text-xs font-medium text-stone-700 hover:bg-stone-100 dark:border-slate-800 dark:text-stone-200 dark:hover:bg-slate-800"
                >
                  <Volume2 className="h-3.5 w-3.5" />
                  <span>Read Aloud</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-teal-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950"
                >
                  <Printer className="h-3.5 w-3.5" />
                  <span>Print Receipt</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
