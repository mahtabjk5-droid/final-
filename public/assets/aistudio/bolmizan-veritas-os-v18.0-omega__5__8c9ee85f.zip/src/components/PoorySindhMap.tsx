import { useState } from 'react';
import { Compass, MapPin, Waves } from 'lucide-react';
import type { UiLanguage } from '../../shared/types';
import { formatCurrency } from '../utils/formatters';

interface SindhCityNode {
  id: string;
  name: string;
  localName: string;
  region: 'Upper Sindh' | 'Central Sindh' | 'Thar & East' | 'Laar & Coast';
  specialty: string;
  heritage: string;
  x: number;
  y: number;
  isHq?: boolean;
  isPort?: boolean;
}

const SINDH_DISTRICTS: SindhCityNode[] = [
  {
    id: 'kashmore',
    name: 'Kashmore',
    localName: 'ڪشمور',
    region: 'Upper Sindh',
    specialty: 'Guddu Barrage Agro Corridor',
    heritage: 'Northern Indus Gateway',
    x: 245,
    y: 44,
  },
  {
    id: 'jacobabad',
    name: 'Jacobabad',
    localName: 'جيڪب آباد',
    region: 'Upper Sindh',
    specialty: 'Rice & Grain Wholesale',
    heritage: 'Tri-Province Trade Junction',
    x: 175,
    y: 52,
  },
  {
    id: 'ghotki',
    name: 'Ghotki',
    localName: 'گھوٽڪي',
    region: 'Upper Sindh',
    specialty: 'Cotton, Wheat & Fertilizer Belt',
    heritage: 'Sachal & Bharchundi Heritage',
    x: 282,
    y: 78,
  },
  {
    id: 'shikarpur',
    name: 'Shikarpur',
    localName: 'شڪارپور',
    region: 'Upper Sindh',
    specialty: 'Historic Caravan Finance & Achar',
    heritage: 'Caravanserai Hundis Legacy',
    x: 186,
    y: 88,
  },
  {
    id: 'sukkur',
    name: 'Sukkur',
    localName: 'سکر',
    region: 'Upper Sindh',
    specialty: 'Dates Export & Barrage Logistics',
    heritage: 'Lansdowne Bridge · Sadh Belo',
    x: 235,
    y: 102,
  },
  {
    id: 'larkana',
    name: 'Larkana & Mohenjo-Daro',
    localName: 'لاڙڪاڻو · موئن جو دڙو',
    region: 'Upper Sindh',
    specialty: 'Guava, Rice & Ancient Weights',
    heritage: '2600 BCE Indus Seal Civilization',
    x: 152,
    y: 132,
  },
  {
    id: 'khairpur',
    name: 'Khairpur Mirs',
    localName: 'خيرپور ميرس',
    region: 'Upper Sindh',
    specialty: 'Aseel Dates & Handloom Textiles',
    heritage: 'Kot Diji Fort & Faiz Mahal',
    x: 242,
    y: 146,
  },
  {
    id: 'naushahro',
    name: 'Naushahro Feroze',
    localName: 'نوشهرو فيروز',
    region: 'Central Sindh',
    specialty: 'Wheat, Mango & Canal Produce',
    heritage: 'Heartland of Central Sindh',
    x: 210,
    y: 176,
  },
  {
    id: 'dadu',
    name: 'Dadu & Gorakh Hill',
    localName: 'دادو · گورک هل',
    region: 'Central Sindh',
    specialty: 'Khirthar Livestock & Eco-Trade',
    heritage: 'Gorakh Hill Station (5,688 ft)',
    x: 118,
    y: 196,
  },
  {
    id: 'sehwan',
    name: 'Sehwan Sharif',
    localName: 'سيوهڻ شريف',
    region: 'Central Sindh',
    specialty: 'Pilgrim Bazaar & Pottery Craft',
    heritage: 'Lal Shahbaz Qalandar Sanctuary',
    x: 144,
    y: 230,
  },
  {
    id: 'sakrand',
    name: 'Sakrand HQ',
    localName: 'سڪرنڊ مرڪز',
    region: 'Central Sindh',
    specialty: 'SINDH-MIZAN Sovereign Clearing Core',
    heritage: 'Global HQ · Mahtab Ali Jamali',
    x: 204,
    y: 226,
    isHq: true,
  },
  {
    id: 'nawabshah',
    name: 'Benazirabad',
    localName: 'نوابشاھ',
    region: 'Central Sindh',
    specialty: 'Sugarcane, Cotton & Flour Mills',
    heritage: 'Central Sindh Rail Nexus',
    x: 242,
    y: 220,
  },
  {
    id: 'sanghar',
    name: 'Sanghar',
    localName: 'سانگھڙ',
    region: 'Central Sindh',
    specialty: 'Chotiari Agro & Timber Markets',
    heritage: 'Hur Freedom Heritage',
    x: 282,
    y: 244,
  },
  {
    id: 'bhitshah',
    name: 'Bhit Shah & Matiari',
    localName: 'ڀٽ شاھ · مٽياري',
    region: 'Central Sindh',
    specialty: 'Ajrak Block-Print & Sur Tambura',
    heritage: 'Shah Abdul Latif Bhitai Shrine',
    x: 198,
    y: 266,
  },
  {
    id: 'hyderabad',
    name: 'Hyderabad & Jamshoro',
    localName: 'حيدرآباد · ڄامشورو',
    region: 'Central Sindh',
    specialty: 'Glass Bangles, Rilli & Tech Corridor',
    heritage: 'Pacca Qilla · Kotri Barrage',
    x: 186,
    y: 298,
  },
  {
    id: 'mirpurkhas',
    name: 'Mirpurkhas',
    localName: 'ميرپورخاص',
    region: 'Thar & East',
    specialty: 'Sindhri Mango Global Export Hub',
    heritage: 'Kahu-Jo-Daro Stupa',
    x: 258,
    y: 292,
  },
  {
    id: 'umerkot',
    name: 'Umerkot',
    localName: 'عمرڪوٽ',
    region: 'Thar & East',
    specialty: 'Chilies, Marui Embroidery & Livestock',
    heritage: 'Umerkot Fort · Folk Heritage',
    x: 314,
    y: 298,
  },
  {
    id: 'tharparkar',
    name: 'Mithi & Tharparkar',
    localName: 'مٺي · ٿرپارڪر',
    region: 'Thar & East',
    specialty: 'Rilli Quilts, Coal Power & Millet',
    heritage: 'Karoonjhar Hills · Nagarparkar',
    x: 306,
    y: 356,
  },
  {
    id: 'badin',
    name: 'Badin',
    localName: 'بدين',
    region: 'Laar & Coast',
    specialty: 'Sugarcane, Rice & Coastal Fisheries',
    heritage: 'Southern Laar Indus Delta',
    x: 236,
    y: 354,
  },
  {
    id: 'thatta',
    name: 'Thatta & Makli',
    localName: 'ٺٽو · مڪلي',
    region: 'Laar & Coast',
    specialty: 'Keenjhar Eco-Trade & Stone Craft',
    heritage: 'Shah Jahan Mosque · Makli',
    x: 164,
    y: 344,
  },
  {
    id: 'karachi',
    name: 'Karachi Port',
    localName: 'ڪراچي بندرگاھ',
    region: 'Laar & Coast',
    specialty: 'Maritime Export, SBP Raast & GCC Link',
    heritage: 'Arabian Sea Sovereign Gateway',
    x: 112,
    y: 346,
    isPort: true,
  },
];

interface PoorySindhMapProps {
  language: UiLanguage;
  sakrandVolumeUsd?: number;
  karachiVolumeUsd?: number;
  pardaActive?: boolean;
  compact?: boolean;
}

export function PoorySindhMap({
  language,
  sakrandVolumeUsd = 0,
  karachiVolumeUsd = 0,
  pardaActive = false,
  compact = false,
}: PoorySindhMapProps) {
  const [selectedId, setSelectedId] = useState<string>('sakrand');
  const [regionFilter, setRegionFilter] = useState<'All' | SindhCityNode['region']>('All');

  const activeNode = SINDH_DISTRICTS.find((d) => d.id === selectedId) ?? SINDH_DISTRICTS[10];
  const visibleNodes = SINDH_DISTRICTS.filter(
    (d) => regionFilter === 'All' || d.region === regionFilter
  );

  const titleText =
    language === 'sd'
      ? 'سڄو سنڌ — ڪشمور کان ڪراچي تائين'
      : language === 'ur'
        ? 'پورا سندھ — کشمور تا کراچی و تھرپارکر'
        : 'Poory Sindh — کشمور تا کراچی و تھرپارکر';

  return (
    <section className="overflow-hidden rounded-xl border border-stone-200 bg-white dark:border-slate-800 dark:bg-[#111922]">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-200 px-6 py-4 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 dark:text-teal-400">
            <Compass className="h-4 w-4" />
            <span>سڄو سنڌ Live Clearing &amp; Cultural Atlas · 21 Historic Districts</span>
          </div>
          <h2 className="mt-0.5 font-editorial text-2xl font-bold text-slate-900 dark:text-white">
            {titleText}
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-lg border border-stone-200 bg-[#F8F7F3] p-1 dark:border-slate-800 dark:bg-[#0B1117]">
          {(['All', 'Upper Sindh', 'Central Sindh', 'Thar & East', 'Laar & Coast'] as const).map(
            (reg) => (
              <button
                key={reg}
                type="button"
                onClick={() => setRegionFilter(reg)}
                className={`rounded-md px-2.5 py-1 text-xs font-semibold whitespace-nowrap transition-colors ${
                  regionFilter === reg
                    ? 'bg-teal-700 text-white dark:bg-teal-500 dark:text-slate-950'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                }`}
              >
                {reg}
              </button>
            )
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 divide-y divide-stone-200 lg:grid-cols-12 lg:divide-x lg:divide-y-0 dark:divide-slate-800">
        {/* Left 7 Cols: Topographic SVG Atlas of All Sindh + Indus River */}
        <div className="relative bg-[#0D2327] p-5 lg:col-span-7">
          <div className="mb-2 flex items-center justify-between font-mono text-[11px] text-teal-200/80">
            <span className="inline-flex items-center gap-1.5 text-teal-300">
              <Waves className="h-3.5 w-3.5" />
              <span>INDUS RIVER (سنڌو درياھ) · GUDDU → SUKKUR → KOTRI → DELTA</span>
            </span>
            <span className="text-amber-300">21 DISTRICTS</span>
          </div>

          <svg
            viewBox="0 0 420 400"
            role="img"
            aria-label="Interactive Map of All Sindh Districts along the Indus River"
            className={`w-full select-none ${compact ? 'h-64' : 'h-80 sm:h-[400px]'}`}
          >
            <defs>
              <linearGradient id="sindhLandGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#161433" />
                <stop offset="52%" stopColor="#0D192B" />
                <stop offset="100%" stopColor="#240914" />
              </linearGradient>
              <linearGradient id="indusRiverGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#38BDF8" />
                <stop offset="55%" stopColor="#10B981" />
                <stop offset="100%" stopColor="#F59E0B" />
              </linearGradient>
              <radialGradient id="sakrandHalo" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#F59E0B" stopOpacity="0.45" />
                <stop offset="100%" stopColor="#F59E0B" stopOpacity="0" />
              </radialGradient>
            </defs>

            <g stroke="#F59E0B" strokeOpacity="0.07" strokeWidth="0.7">
              <line x1="20" y1="80" x2="400" y2="80" />
              <line x1="20" y1="160" x2="400" y2="160" />
              <line x1="20" y1="240" x2="400" y2="240" />
              <line x1="20" y1="320" x2="400" y2="320" />
              <line x1="110" y1="20" x2="110" y2="385" />
              <line x1="210" y1="20" x2="210" y2="385" />
              <line x1="310" y1="20" x2="310" y2="385" />
            </g>

            {/* Full Sindh Geographic Silhouette */}
            <path
              d="M 162 42 L 246 28 L 304 68 L 284 128 L 266 176 L 304 236 L 348 292 L 340 374 L 274 378 L 228 368 L 176 364 L 138 368 L 96 352 L 106 318 L 128 282 L 106 238 L 98 184 L 128 134 L 146 84 Z"
              fill="url(#sindhLandGrad)"
              stroke="#F59E0B"
              strokeOpacity="0.58"
              strokeWidth="1.6"
            />

            <path
              d="M 275 236 Q 318 282 325 362"
              fill="none"
              stroke="#F59E0B"
              strokeOpacity="0.22"
              strokeWidth="1.2"
              strokeDasharray="4 4"
            />
            <path
              d="M 136 92 L 104 185 L 116 250 L 100 322"
              fill="none"
              stroke="#9F1239"
              strokeOpacity="0.45"
              strokeWidth="2"
              strokeDasharray="3 3"
            />

            {/* Flowing River Indus */}
            <path
              d="M 262 32 Q 252 72 232 104 Q 198 144 196 184 Q 192 224 196 264 Q 188 308 164 348 L 146 376"
              fill="none"
              stroke="url(#indusRiverGrad)"
              strokeWidth="4.2"
              strokeLinecap="round"
              opacity="0.88"
            />
            <path
              d="M 262 32 Q 252 72 232 104 Q 198 144 196 184 Q 192 224 196 264 Q 188 308 164 348 L 146 376"
              fill="none"
              stroke="#E0F2FE"
              strokeWidth="1.2"
              strokeDasharray="6 6"
              className="arc-travel"
            />

            <text x="50" y="64" fill="#94A3B8" fontSize="8.5" fontFamily="monospace">
              KHIRTHAR HILLS
            </text>
            <text x="305" y="198" fill="#FBBF24" fontSize="8.5" fontFamily="monospace" opacity="0.75">
              THARPARKAR
            </text>
            <text x="48" y="380" fill="#38BDF8" fontSize="8.5" fontFamily="monospace" opacity="0.85">
              ARABIAN SEA
            </text>

            {/* Clearing Arcs from Sakrand HQ */}
            {visibleNodes
              .filter((n) => !n.isHq)
              .map((node) => {
                const isSelected = activeNode.id === node.id;
                const midX = (204 + node.x) / 2 + (node.x > 204 ? -12 : 12);
                const midY = (226 + node.y) / 2 - 14;
                return (
                  <path
                    key={`arc_${node.id}`}
                    d={`M 204 226 Q ${midX} ${midY} ${node.x} ${node.y}`}
                    fill="none"
                    stroke={isSelected ? '#F59E0B' : '#10B981'}
                    strokeWidth={isSelected ? '1.8' : '0.85'}
                    strokeOpacity={isSelected ? '0.95' : '0.32'}
                    className="arc-travel"
                  />
                );
              })}

            <circle cx="204" cy="226" r="24" fill="url(#sakrandHalo)" />

            {visibleNodes.map((node) => {
              const isSelected = activeNode.id === node.id;
              const fill = node.isHq
                ? '#F59E0B'
                : node.isPort
                  ? '#38BDF8'
                  : isSelected
                    ? '#FBBF24'
                    : '#10B981';
              return (
                <g
                  key={node.id}
                  className="cursor-pointer"
                  onClick={() => setSelectedId(node.id)}
                >
                  {isSelected && (
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={node.isHq ? 11 : 9}
                      fill="none"
                      stroke="#FDE68A"
                      strokeWidth="1.2"
                    />
                  )}
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={node.isHq ? 6 : node.isPort ? 5 : 4}
                    fill={fill}
                    stroke="#0D2327"
                    strokeWidth="1.4"
                  />
                  <text
                    x={node.x + (node.x > 270 ? -6 : 7)}
                    y={node.y + 3}
                    textAnchor={node.x > 270 ? 'end' : 'start'}
                    fill={isSelected || node.isHq ? '#FEF3C7' : '#CBD5E1'}
                    fontSize={node.isHq ? '9.5' : '7.8'}
                    fontWeight={isSelected || node.isHq ? 'bold' : 'normal'}
                    fontFamily="sans-serif"
                  >
                    {node.name.split(' &')[0]}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Right 5 Cols: Selected District Inspector + District Grid */}
        <div className="flex flex-col justify-between p-6 lg:col-span-5">
          <div>
            <div className="flex items-center justify-between gap-2 text-xs">
              <span className="inline-flex items-center gap-1.5 font-mono font-semibold text-teal-700 dark:text-teal-400">
                <MapPin className="h-3.5 w-3.5" />
                <span>{activeNode.region}</span>
              </span>
              <span dir="rtl" className="font-semibold text-[#9B1C2E] dark:text-rose-400">
                {activeNode.localName}
              </span>
            </div>

            <h3 className="mt-2 font-editorial text-3xl font-bold text-slate-900 dark:text-white">
              {activeNode.name}
            </h3>

            <div className="mt-4 divide-y divide-stone-200 border-y border-stone-200 text-xs dark:divide-slate-800 dark:border-slate-800">
              <div className="flex items-start justify-between gap-3 py-2.5">
                <span className="text-slate-500 dark:text-slate-400">Trade Corridor</span>
                <span className="text-right font-semibold text-slate-900 dark:text-slate-100">
                  {activeNode.specialty}
                </span>
              </div>
              <div className="flex items-start justify-between gap-3 py-2.5">
                <span className="text-slate-500 dark:text-slate-400">Sindh Heritage</span>
                <span className="text-right font-medium text-[#9B1C2E] dark:text-rose-300">
                  {activeNode.heritage}
                </span>
              </div>
              <div className="flex items-start justify-between gap-3 py-2.5">
                <span className="text-slate-500 dark:text-slate-400">Cleared Hub Link</span>
                <span className={`text-right font-mono font-semibold text-teal-700 dark:text-teal-400 ${pardaActive ? 'parda-blur' : ''}`}>
                  {activeNode.id === 'karachi'
                    ? formatCurrency(karachiVolumeUsd, 'USD')
                    : formatCurrency(sakrandVolumeUsd, 'USD')}
                </span>
              </div>
            </div>

            <div className="mt-5">
              <div className="mb-2 text-[11px] font-semibold tracking-wider text-slate-500 uppercase dark:text-slate-400">
                Inspect Any District ({visibleNodes.length})
              </div>
              <div className="grid max-h-48 grid-cols-2 gap-1.5 overflow-y-auto pr-1 sm:grid-cols-3">
                {visibleNodes.map((node) => {
                  const selected = activeNode.id === node.id;
                  return (
                    <button
                      key={node.id}
                      type="button"
                      onClick={() => setSelectedId(node.id)}
                      className={`truncate rounded-md border px-2.5 py-1.5 text-left text-[11px] font-medium transition-colors ${
                        selected
                          ? 'border-teal-700 bg-teal-700 font-semibold text-white dark:border-teal-400 dark:bg-teal-500 dark:text-slate-950'
                          : 'border-stone-200 bg-[#F8F7F3] text-slate-700 hover:border-teal-600/50 dark:border-slate-800 dark:bg-[#0B1117] dark:text-slate-300'
                      }`}
                    >
                      {node.name.split(' &')[0]}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="mt-5 border-t border-stone-200 pt-3 text-[11px] text-slate-500 dark:border-slate-800 dark:text-slate-400">
            Unified via SBP Raast, 1LINK &amp; SHA-256 Zero-Riba Ledger from{' '}
            <strong className="text-slate-900 dark:text-teal-300">Sakrand HQ</strong> across all 21 Sindh districts.
          </div>
        </div>
      </div>
    </section>
  );
}
