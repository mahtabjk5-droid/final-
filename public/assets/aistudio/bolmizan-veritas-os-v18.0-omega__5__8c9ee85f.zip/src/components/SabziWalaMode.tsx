import { useState } from 'react';
import { MessageCircle, Mic, MicOff, PlusCircle, Sparkles, Volume2 } from 'lucide-react';
import type {
  CurrencyCode,
  LedgerEntryType,
  UiLanguage,
  VeritasBootstrapPayload,
  VoiceParseResult,
} from '../../shared/types';
import { formatCurrency } from '../utils/formatters';
import { UI_STRINGS } from '../utils/i18n';
import { apiFetch } from '../utils/sessionClient';
import {
  enqueueOfflineAction,
  speakMultilingual,
  useCognitiveIntent,
} from '../utils/ttsAndOffline';
import { SignaturePad } from './SignaturePad';

interface SabziWalaModeProps {
  data: VeritasBootstrapPayload;
  language: UiLanguage;
  pardaActive: boolean;
  simulateOffline: boolean;
  onQueuedOffline: () => void;
  onOpenVoiceCapture?: () => void;
}

const VOICE_PRESETS: Array<{ label: string; text: string }> = [
  { label: 'اردو ادھار', text: 'محمد علی کو 5000 روپے ادھار دئیے آلو پیاز' },
  { label: 'سنڌي کاتو', text: 'احمد خان کي 3500 رپيا چانور اوڌار ڏنا' },
  { label: 'Roman Urdu', text: 'Bilal ko 12000 PKR aata udhaar diya' },
  { label: 'العربية', text: 'تسجيل مبلغ ٣٢٠٠ ريال تمور للعميل طارق' },
];

export function SabziWalaMode({
  data,
  language,
  pardaActive,
  simulateOffline,
  onQueuedOffline,
  onOpenVoiceCapture,
}: SabziWalaModeProps) {
  const strings = UI_STRINGS[language];
  const [transcript, setTranscript] = useState('Bilal ko 2500 PKR sabzi udhaar diya');
  const [customerName, setCustomerName] = useState('Bilal');
  const [amount, setAmount] = useState('2500');
  const [currency, setCurrency] = useState<CurrencyCode>('PKR');
  const [entryType, setEntryType] = useState<LedgerEntryType>('udhaar_given');
  const [itemsSummary, setItemsSummary] = useState('Fresh sabzi & fruit crate');
  const [signatureDataUrl, setSignatureDataUrl] = useState<string | null>(null);
  const [listening, setListening] = useState(false);
  const [parsing, setParsing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const { humanScore, recordKeystrokeOrTap, resetCadence } = useCognitiveIntent();

  function handleVoiceDictation() {
    const win = window as unknown as {
      SpeechRecognition?: new () => {
        lang: string;
        interimResults: boolean;
        onresult: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
        onerror: () => void;
        onend: () => void;
        start: () => void;
      };
      webkitSpeechRecognition?: new () => {
        lang: string;
        interimResults: boolean;
        onresult: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
        onerror: () => void;
        onend: () => void;
        start: () => void;
      };
    };

    const SpeechRec = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SpeechRec) {
      setStatusMessage(
        'Direct mic dictation requires Chrome/Edge. Tap a quick Urdu/Sindhi phrase or edit below.'
      );
      return;
    }

    try {
      const rec = new SpeechRec();
      rec.lang = language === 'ur' ? 'ur-PK' : language === 'ar' ? 'ar-SA' : 'en-PK';
      rec.interimResults = false;
      setListening(true);
      rec.onresult = (event) => {
        const spoken = event.results[0]?.[0]?.transcript || '';
        if (spoken) {
          setTranscript(spoken);
          void parseTranscript(spoken);
        }
      };
      rec.onerror = () => setListening(false);
      rec.onend = () => setListening(false);
      rec.start();
    } catch {
      setListening(false);
    }
  }

  async function parseTranscript(textToParse = transcript) {
    setParsing(true);
    setStatusMessage(null);
    try {
      const res = await apiFetch('/api/ai-parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transcript: textToParse, languageHint: language }),
      });
      if (!res.ok) throw new Error('Parse failed');
      const parsed = (await res.json()) as VoiceParseResult;
      setCustomerName(parsed.customerName);
      setAmount(String(parsed.amount));
      setCurrency(parsed.currency);
      setEntryType(parsed.entryType);
      setItemsSummary(parsed.itemsSummary);
      setStatusMessage(`Parsed via ${parsed.parserEngine} (${parsed.languageDetected.toUpperCase()})`);
    } catch {
      setStatusMessage('Offline mode active — verify customer, amount, and save to offline queue.');
    } finally {
      setParsing(false);
    }
  }

  async function handleSaveEntry(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setStatusMessage(null);

    const payload = {
      entryType,
      creditorName: entryType === 'udhaar_taken' ? customerName : data.user.businessName,
      debtorName: entryType === 'udhaar_taken' ? data.user.businessName : customerName,
      amount: Number(amount),
      currency,
      itemsSummary,
      dueDate: new Date(Date.now() + 15 * 86400_000).toISOString().slice(0, 10),
      language,
      voiceTranscript: transcript,
      signatureDataUrl,
      cognitiveHumanScore: humanScore,
    };

    if (simulateOffline || !navigator.onLine) {
      enqueueOfflineAction({
        endpoint: '/api/ledger/entries',
        method: 'POST',
        body: payload,
        idempotencyKey: `off_led_${Date.now()}`,
        label: `${customerName} (${formatCurrency(Number(amount), currency)})`,
      });
      onQueuedOffline();
      setStatusMessage('Saved safely to Offline Queue — will sync automatically when back online.');
      setSaving(false);
      return;
    }

    try {
      const res = await apiFetch('/api/ledger/entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) {
        setStatusMessage(json.error || 'Could not save entry.');
        return;
      }
      resetCadence();
      setSignatureDataUrl(null);
      setStatusMessage('Entry cryptographically sealed onto SHA-256 Shariah Ledger.');
      speakMultilingual(`${customerName}, ${amount} ${currency}, ${itemsSummary}`, language);
    } catch {
      enqueueOfflineAction({
        endpoint: '/api/ledger/entries',
        method: 'POST',
        body: payload,
        idempotencyKey: `off_led_${Date.now()}`,
        label: `${customerName} (${formatCurrency(Number(amount), currency)})`,
      });
      onQueuedOffline();
      setStatusMessage('Connection interrupted — saved to Offline Sync Queue.');
    } finally {
      setSaving(false);
    }
  }

  const latestEntry = data.ledgerEntries[0];
  const whatsappText = latestEntry
    ? `BolMizan VERITAS Receipt (${latestEntry.reference} · 0% Riba)\n${latestEntry.debtorName}: ${formatCurrency(latestEntry.amount, latestEntry.currency)}\n${latestEntry.itemsSummary}\nSHA-256: ${latestEntry.hash.slice(0, 16)}...`
    : `BolMizan VERITAS Counter (${customerName}): ${formatCurrency(Number(amount) || 0, currency)} - ${itemsSummary}`;
  const whatsappHref = `https://wa.me/?text=${encodeURIComponent(whatsappText)}`;

  const fieldCls =
    'mt-1 w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm font-medium text-slate-900 focus:border-teal-700 focus:outline-none dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-100';

  return (
    <div className="space-y-6">
      {/* 3 Oversized Tactile Counter Slabs */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <button
          type="button"
          onClick={() => (onOpenVoiceCapture ? onOpenVoiceCapture() : handleVoiceDictation())}
          className="flex flex-col items-center justify-center gap-2 rounded-xl bg-teal-700 px-6 py-8 text-center text-white shadow-sm transition-colors hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
        >
          <Mic className="h-8 w-8" />
          <span className="font-editorial text-2xl font-bold">بول کر لکھیں / ڳالهائي لکو</span>
          <span className="text-xs font-medium opacity-90">Tap &amp; Speak Entry (MediaRecorder)</span>
        </button>

        <button
          type="button"
          onClick={() =>
            speakMultilingual(
              latestEntry
                ? `${latestEntry.debtorName}, ${latestEntry.amount} ${latestEntry.currency}, ${latestEntry.itemsSummary}`
                : `${customerName}, ${amount} ${currency}, ${itemsSummary}`,
              language
            )
          }
          className="flex flex-col items-center justify-center gap-2 rounded-xl bg-[#9B1C2E] px-6 py-8 text-center text-white shadow-sm transition-colors hover:bg-[#821626]"
        >
          <Volume2 className="h-8 w-8" />
          <span className="font-editorial text-2xl font-bold">سنیں / ٻڌو</span>
          <span className="text-xs font-medium opacity-90">Listen Receipt Aloud (TTS)</span>
        </button>

        <a
          href={whatsappHref}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center gap-2 rounded-xl border border-stone-200 bg-white px-6 py-8 text-center text-slate-900 shadow-sm transition-colors hover:bg-stone-50 dark:border-slate-800 dark:bg-[#111922] dark:text-white dark:hover:bg-slate-800/60"
        >
          <MessageCircle className="h-8 w-8 text-teal-700 dark:text-teal-400" />
          <span className="font-editorial text-2xl font-bold">واٹس ایپ رسید</span>
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Share Verified WhatsApp Receipt
          </span>
        </a>
      </div>

      {/* Hairline-Divided Lenay / Denay Counter */}
      <div className="grid grid-cols-1 divide-y divide-stone-200 overflow-hidden rounded-xl border border-stone-200 bg-white sm:grid-cols-2 sm:divide-x sm:divide-y-0 dark:divide-slate-800 dark:border-slate-800 dark:bg-[#111922]">
        <div className="p-6">
          <div className="text-sm font-semibold text-slate-600 dark:text-slate-300">
            Lenay Hain (لینا ہے · وٺڻا آهن)
          </div>
          <div
            className={`mt-2 font-mono text-3xl font-bold text-teal-700 tabular-nums sm:text-4xl dark:text-teal-400 ${
              pardaActive ? 'parda-blur' : ''
            }`}
          >
            {formatCurrency(data.metrics.openReceivablesPkr, 'PKR')}
          </div>
        </div>

        <div className="p-6">
          <div className="text-sm font-semibold text-slate-600 dark:text-slate-300">
            Denay Hain (دینا ہے · ڏيڻا آهن)
          </div>
          <div
            className={`mt-2 font-mono text-3xl font-bold text-[#9B1C2E] tabular-nums sm:text-4xl dark:text-rose-400 ${
              pardaActive ? 'parda-blur' : ''
            }`}
          >
            {formatCurrency(data.metrics.openPayablesPkr, 'PKR')}
          </div>
        </div>
      </div>

      {/* Voice-First Counter Form */}
      <form
        onSubmit={handleSaveEntry}
        className="space-y-5 rounded-xl border border-stone-200 bg-white p-6 dark:border-slate-800 dark:bg-[#111922]"
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-editorial text-2xl font-bold text-slate-900 dark:text-white">
              BolMizan Voice-to-Hisab Counter
            </h2>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              One-tap Urdu, Sindhi, Arabic, or English voice entry with automatic Read-Aloud confirmation
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleVoiceDictation}
              className={`inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-xs font-semibold transition-colors ${
                listening
                  ? 'border-rose-500 bg-rose-600 text-white'
                  : 'border-stone-300 bg-[#F8F7F3] text-slate-800 hover:border-teal-700 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-200'
              }`}
            >
              {listening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4 text-teal-700 dark:text-teal-400" />}
              <span>{listening ? 'Listening...' : 'Mic Dictation'}</span>
            </button>

            <button
              type="button"
              disabled={parsing}
              onClick={() => parseTranscript()}
              className="inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-500 dark:text-slate-950"
            >
              <Sparkles className="h-4 w-4" />
              <span>{parsing ? 'Parsing...' : strings.parseVoiceBtn}</span>
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {VOICE_PRESETS.map((preset) => (
            <button
              key={preset.label}
              type="button"
              onClick={() => {
                setTranscript(preset.text);
                void parseTranscript(preset.text);
              }}
              className="rounded-lg border border-stone-300 bg-[#F8F7F3] px-3 py-1.5 text-xs font-medium text-slate-700 hover:border-teal-700 dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-200"
            >
              {preset.label}
            </button>
          ))}
        </div>

        <textarea
          rows={2}
          value={transcript}
          onChange={(e) => {
            setTranscript(e.target.value);
            recordKeystrokeOrTap();
          }}
          placeholder={strings.voicePromptPlaceholder}
          className="w-full rounded-xl border border-stone-300 bg-white p-4 text-base text-slate-900 focus:border-teal-700 focus:outline-none dark:border-slate-700 dark:bg-[#0B1117] dark:text-slate-100"
        />

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Customer / Party Name
            </label>
            <input
              type="text"
              required
              value={customerName}
              onChange={(e) => {
                setCustomerName(e.target.value);
                recordKeystrokeOrTap();
              }}
              className={fieldCls}
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Amount ({currency})
            </label>
            <input
              type="number"
              required
              min="1"
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                recordKeystrokeOrTap();
              }}
              className={`${fieldCls} font-mono font-bold`}
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Type (Zero-Riba)
            </label>
            <select
              value={entryType}
              onChange={(e) => setEntryType(e.target.value as LedgerEntryType)}
              className={fieldCls}
            >
              <option value="udhaar_given">Udhaar Given (Lena)</option>
              <option value="udhaar_taken">Udhaar Taken (Dena)</option>
              <option value="cash_sale">Cash Sale (Naqad)</option>
              <option value="payment_received">Payment Received (Wasool)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Currency
            </label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className={fieldCls}
            >
              <option value="PKR">PKR (₨)</option>
              <option value="SAR">SAR (﷼)</option>
              <option value="AED">AED (د.إ)</option>
              <option value="USD">USD ($)</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Goods / Description
          </label>
          <input
            type="text"
            required
            value={itemsSummary}
            onChange={(e) => setItemsSummary(e.target.value)}
            className={fieldCls}
          />
        </div>

        <SignaturePad value={signatureDataUrl} onChange={setSignatureDataUrl} />

        {statusMessage && (
          <div className="rounded-lg border border-teal-200 bg-teal-50 px-4 py-3 text-xs font-medium text-teal-900 dark:border-teal-800 dark:bg-teal-950/40 dark:text-teal-200">
            {statusMessage}
          </div>
        )}

        <div className="flex flex-wrap gap-3">
          <button
            type="submit"
            disabled={saving}
            className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-teal-700 px-6 py-4 text-base font-bold text-white hover:bg-teal-800 disabled:opacity-60 dark:bg-teal-500 dark:text-slate-950 dark:hover:bg-teal-400"
          >
            <PlusCircle className="h-5 w-5" />
            <span>{saving ? 'Sealing Entry...' : 'Save & Seal on Ledger'}</span>
          </button>

          <button
            type="button"
            onClick={() =>
              speakMultilingual(`${customerName}, ${amount} ${currency}, ${itemsSummary}`, language)
            }
            className="inline-flex items-center gap-2 rounded-xl border border-stone-300 px-5 py-4 text-base font-bold text-slate-800 hover:bg-stone-100 dark:border-slate-700 dark:text-slate-100 dark:hover:bg-slate-800"
          >
            <Volume2 className="h-5 w-5 text-teal-700 dark:text-teal-400" />
            <span>{strings.readAloudBtn}</span>
          </button>
        </div>
      </form>

      {/* Hairline-Divided Recent Counter Feed */}
      <div className="divide-y divide-stone-200 overflow-hidden rounded-xl border border-stone-200 bg-white dark:divide-slate-800 dark:border-slate-800 dark:bg-[#111922]">
        {data.ledgerEntries.slice(0, 5).map((entry) => (
          <div
            key={entry.id}
            className="flex flex-wrap items-center justify-between gap-4 p-5"
          >
            <div>
              <div className="text-base font-bold text-slate-900 dark:text-white">
                {entry.debtorName}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                {entry.itemsSummary} · {entry.reference}
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div
                className={`font-mono text-xl font-bold text-slate-900 tabular-nums dark:text-teal-300 ${
                  pardaActive ? 'parda-blur' : ''
                }`}
              >
                {formatCurrency(entry.amount, entry.currency)}
              </div>
              <button
                type="button"
                onClick={() =>
                  speakMultilingual(
                    `${entry.debtorName}, ${entry.amount} ${entry.currency}, ${entry.itemsSummary}`,
                    entry.language
                  )
                }
                aria-label={`Read aloud ${entry.reference}`}
                className="rounded-lg border border-stone-300 p-2.5 text-slate-700 hover:bg-stone-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <Volume2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
