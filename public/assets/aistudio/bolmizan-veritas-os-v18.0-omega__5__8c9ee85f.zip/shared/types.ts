export type UiLanguage = 'en' | 'ur' | 'sd' | 'ar';

export type UiDisplayMode = 'command' | 'sabziwala';

export type WorkspaceRole =
  | 'founder'
  | 'merchant'
  | 'exporter'
  | 'product_manager'
  | 'marketer'
  | 'auditor';

export type NavSection =
  | 'overview'
  | 'ledger'
  | 'payments'
  | 'treasury'
  | 'mukasa'
  | 'zakat'
  | 'security';

export type BranchId = 'all' | 'sakrand_hq' | 'karachi_port' | 'riyadh_hub' | 'dubai_marina';

export type SaasTierId = 'mazdoor_free' | 'pro_trader' | 'enterprise_exporter';

export type CurrencyCode =
  | 'PKR'
  | 'USD'
  | 'SAR'
  | 'AED'
  | 'EUR'
  | 'GBP'
  | 'INR'
  | 'BRL'
  | 'CNY'
  | 'JPY'
  | 'KES';

export type PaymentRailId =
  | 'sbp_raast'
  | 'jazzcash'
  | 'easypaisa'
  | 'onelink_1bill'
  | 'sadapay_nayapay'
  | 'saudi_mada'
  | 'stc_pay'
  | 'uae_aani'
  | 'stripe_card'
  | 'apple_pay'
  | 'google_pay'
  | 'paypal'
  | 'sepa_instant'
  | 'fednow_ach'
  | 'uk_faster_payments'
  | 'india_upi'
  | 'brazil_pix'
  | 'wise_corridor'
  | 'mpesa'
  | 'usdc_base'
  | 'alipay_wechat';

export type RailCategory =
  | 'Pakistan & MENA'
  | 'Global Cards & Wallets'
  | 'International Bank Rails'
  | 'Web3 & APAC';

export interface PaymentRailDefinition {
  id: PaymentRailId;
  name: string;
  shortName: string;
  category: RailCategory;
  regions: string[];
  currencies: CurrencyCode[];
  settlementSla: string;
  baseFeePct: number;
  fixedFeeUsd: number;
  approvalRate: number;
  connectorType: 'stripe' | 'paypal' | 'local_clearing' | 'onchain';
  inputLabel: string;
  inputPlaceholder: string;
  inputHint: string;
  supportsQr?: 'emvco_raast' | 'zatca_tlv';
}

export interface WebAuthnStoredCredential {
  id: string;
  publicKeyBase64Url: string;
  counter: number;
  transports?: string[];
  createdAt: string;
}

export type AuthProviderKind =
  | 'password'
  | 'founder'
  | 'google'
  | 'whatsapp_otp'
  | 'phone_pin'
  | 'webauthn';

export interface UserPublicProfile {
  id: string;
  email: string;
  phone?: string;
  fullName: string;
  businessName: string;
  location: string;
  defaultRole: WorkspaceRole;
  subscriptionTier: SaasTierId;
  authProvider?: AuthProviderKind;
  passkeyCount: number;
  createdAt: string;
}

export type LedgerEntryType =
  | 'udhaar_given'
  | 'udhaar_taken'
  | 'cash_sale'
  | 'payment_received'
  | 'mukasa_settlement'
  | 'sadqah_maafi'
  | 'murabaha_contract'
  | 'salam_contract';

export type LedgerStatus = 'open' | 'grace_15d' | 'settled' | 'sadqah_forgiven';

export interface LedgerWitness {
  id: string;
  witnessName: string;
  witnessRole: string;
  otaqLocation: string;
  signedAt: string;
}

export interface LedgerEntry {
  id: string;
  index: number;
  reference: string;
  createdAt: string;
  branchId: Exclude<BranchId, 'all'>;
  entryType: LedgerEntryType;
  status: LedgerStatus;
  creditorName: string;
  debtorName: string;
  amount: number;
  currency: CurrencyCode;
  usdAmount: number;
  costBasisUsd?: number;
  murabahaMarkupUsd?: number;
  itemsSummary: string;
  dueDate: string | null;
  graceExtendedUntil: string | null;
  language: UiLanguage;
  voiceTranscript: string | null;
  signatureDataUrl: string | null;
  witnesses?: LedgerWitness[];
  cognitiveHumanScore: number;
  ribaFeeBlocked: boolean;
  piiRedacted: boolean;
  prevHash: string;
  hash: string;
}

export interface ChainVerificationResult {
  intact: boolean;
  totalBlocks: number;
  verifiedBlocks: number;
  brokenAtIndex: number | null;
  checkedAt: string;
}

export interface VoiceParseResult {
  transcript?: string;
  customerName: string;
  amount: number;
  currency: CurrencyCode;
  entryType: LedgerEntryType;
  itemsSummary: string;
  dueDate: string | null;
  languageDetected: UiLanguage;
  parserEngine: 'gemini-4-hydrogen' | 'offline-utf8-regex';
}

export interface PaymentTransaction {
  id: string;
  reference: string;
  createdAt: string;
  settledAt: string | null;
  branchId: Exclude<BranchId, 'all'>;
  amount: number;
  currency: CurrencyCode;
  usdAmount: number;
  feeUsd: number;
  netUsd: number;
  ujrahFeeUsd: number;
  fxRateUsed: number;
  railId: PaymentRailId;
  railName: string;
  connectorMode: 'stripe_live' | 'paypal_live' | 'sandbox_clearing';
  gatewayIntentId: string;
  status: 'settled' | 'processing' | 'refunded' | 'declined';
  customerName: string;
  customerEmail: string;
  customerCountry: string;
  maskedInstrument: string;
  paymentLinkId: string | null;
  utmSource: string | null;
  utmCampaign: string | null;
  creatorHandle: string | null;
  idempotencyKey: string;
  piiRedacted: boolean;
  qrPayload: string | null;
}

export interface PaymentLinkRecord {
  id: string;
  slug: string;
  title: string;
  description: string;
  amount: number;
  currency: CurrencyCode;
  active: boolean;
  allowedCategories: RailCategory[];
  utmSource: string;
  utmCampaign: string;
  creatorHandle: string;
  clicks: number;
  conversions: number;
  totalVolumeUsd: number;
  createdAt: string;
}

export interface WebhookEventRecord {
  id: string;
  eventType: string;
  transactionId: string;
  endpointUrl: string;
  signatureHeader: string;
  payloadJson: string;
  httpStatus: number;
  latencyMs: number;
  createdAt: string;
}

export interface FxRateSnapshot {
  base: 'USD';
  updatedAt: string;
  source: 'live_api' | 'cached_market';
  rates: Record<CurrencyCode, number>;
}

export interface DebtEdge {
  from: string;
  to: string;
  amountPkr: number;
  entryIds: string[];
}

export interface DebtCycleResult {
  id: string;
  participants: string[];
  offsetAmountPkr: number;
  edges: DebtEdge[];
}

export interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  category: string;
  branchId: Exclude<BranchId, 'all'>;
  expectedQty: number;
  dispatchedQty: number;
  actualRemainingQty: number;
  unitCostPkr: number;
  unitSellPkr: number;
  expiryDate: string;
  rescuedCount: number;
  updatedAt: string;
}

export interface ScamAnalysisResult {
  verdict: 'safe' | 'suspicious' | 'high_risk_scam';
  riskScore: number;
  detectedLanguage: UiLanguage;
  matchedSignals: string[];
  advisoryEn: string;
  advisoryUr: string;
}

export interface VolumeSeriesPoint {
  label: string;
  timestamp: string;
  volumeUsd: number;
  txCount: number;
}

export interface ZakatCalculationInput {
  cashAndBankPkr: number;
  tradeInventoryPkr: number;
  collectibleReceivablesPkr: number;
  shortTermLiabilitiesPkr: number;
  nisabThresholdPkr: number;
  calendarType: 'hijri' | 'solar';
  agriculturalProducePkr: number;
  irrigationType: 'irrigated' | 'rain_fed';
}

export interface ZakatCalculationOutput {
  netZakatableAssetsPkr: number;
  nisabMet: boolean;
  zakatRatePct: number;
  zakatDuePkr: number;
  ushrRatePct: number;
  ushrDuePkr: number;
  totalObligationPkr: number;
}

export type TreasuryEntryType =
  | 'saas_subscription'
  | 'ujrah_settlement'
  | 'ujrah_murabaha'
  | 'ujrah_expiry_rescue'
  | 'founder_withdrawal';

export interface TreasuryEntry {
  id: string;
  createdAt: string;
  type: TreasuryEntryType;
  description: string;
  amountUsd: number;
  amountPkr: number;
  railUsed: string;
  reference: string;
}

export interface FounderTreasuryState {
  founderName: string;
  founderEmail: string;
  hqLocation: string;
  mrrUsd: number;
  cumulativeUjrahUsd: number;
  availableBalanceUsd: number;
  totalWithdrawnUsd: number;
  activeProSubscribers: number;
  activeEnterpriseSubscribers: number;
  entries: TreasuryEntry[];
}

export interface MazdoorEscrowRecord {
  id: string;
  workerName: string;
  workerPhone: string;
  employerName: string;
  workDescription: string;
  dailyWagePkr: number;
  payoutRail: 'sbp_raast' | 'jazzcash' | 'easypaisa';
  branchId: Exclude<BranchId, 'all'>;
  status: 'locked' | 'released';
  lockedAt: string;
  releasedAt: string | null;
  releaseRef: string | null;
  language: UiLanguage;
}

export interface AmanatPassport {
  score: number;
  tier: string;
  verifiedChainBonus: number;
  witnessCount?: number;
  onTimeSettlementRatio: number;
  unlockCreditLimitPkr: number;
  zeroRibaVerified: boolean;
}

export interface MizanAdvisorReport {
  headline: string;
  insightSummary: string;
  urgentAction: string;
  politeReminderUr: string;
  politeReminderSd: string;
  generatedBy: 'gemini-4-hydrogen' | 'deterministic-shariah-engine';
  generatedAt: string;
}

export interface BranchSummary {
  id: Exclude<BranchId, 'all'>;
  name: string;
  city: string;
  country: string;
  txCount: number;
  volumeUsd: number;
}

export interface VeritasBootstrapPayload {
  user: UserPublicProfile;
  metrics: {
    grossVolumeUsd: number;
    netSettledUsd: number;
    totalTransactions: number;
    settledCount: number;
    approvalRatePct: number;
    openReceivablesPkr: number;
    openPayablesPkr: number;
    ledgerBlockCount: number;
    shrinkageLossPkr: number;
    expiringSoonCount: number;
    detectedCycleCount: number;
    activeLinksCount: number;
    escrowLockedPkr: number;
    escrowReleasedPkr: number;
  };
  ledgerEntries: LedgerEntry[];
  chainVerification: ChainVerificationResult;
  transactions: PaymentTransaction[];
  paymentLinks: PaymentLinkRecord[];
  webhooks: WebhookEventRecord[];
  inventory: InventoryItem[];
  debtCycles: DebtCycleResult[];
  mazdoorEscrows: MazdoorEscrowRecord[];
  treasury: FounderTreasuryState;
  amanatPassport: AmanatPassport;
  advisorReport: MizanAdvisorReport;
  branches: BranchSummary[];
  fx: FxRateSnapshot;
  volumeSeries: VolumeSeriesPoint[];
  killSwitchFrozen: boolean;
  liveStreamEnabled: boolean;
  connectedClients: number;
  connectors: {
    stripeConfigured: boolean;
    paypalConfigured: boolean;
    geminiConfigured: boolean;
  };
}

export type WsServerMessage =
  | { type: 'snapshot:init'; payload: VeritasBootstrapPayload }
  | {
      type: 'state:sync';
      payload: Omit<VeritasBootstrapPayload, 'user' | 'fx' | 'connectors'>;
    }
  | { type: 'fx:tick'; payload: FxRateSnapshot };
