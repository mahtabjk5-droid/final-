import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type {
  AmanatPassport,
  AuthProviderKind,
  BranchId,
  BranchSummary,
  ChainVerificationResult,
  CurrencyCode,
  FounderTreasuryState,
  InventoryItem,
  LedgerEntry,
  LedgerEntryType,
  LedgerWitness,
  MazdoorEscrowRecord,
  MizanAdvisorReport,
  PaymentLinkRecord,
  PaymentRailId,
  PaymentTransaction,
  SaasTierId,
  TreasuryEntry,
  UserPublicProfile,
  VeritasBootstrapPayload,
  VolumeSeriesPoint,
  WebAuthnStoredCredential,
  WebhookEventRecord,
  WorkspaceRole,
} from '../shared/types.js';
import { RAIL_BY_ID } from '../shared/rails.js';
import { analyzeInventoryItem, detectDebtCycles } from './debtAndInventory.js';
import { convertToPkr, convertToUsd, getFxSnapshot } from './fxEngine.js';
import { getConnectorReadiness, signWebhookPayload } from './paymentGateways.js';

export interface StoredUser extends UserPublicProfile {
  passwordSalt: string;
  passwordHash: string;
  pinSalt?: string;
  pinHash?: string;
  credentials: WebAuthnStoredCredential[];
}

export function normalizePhoneNumber(raw: string): string {
  const digits = raw.replace(/[^\d+]/g, '');
  if (digits.startsWith('+923') && digits.length === 13) {
    return `0${digits.slice(3)}`;
  }
  if (digits.startsWith('923') && digits.length === 12) {
    return `0${digits.slice(2)}`;
  }
  return digits.replace(/^\+/, '');
}

interface PersistedWalState {
  users: StoredUser[];
  ledgerEntries: LedgerEntry[];
  transactions: PaymentTransaction[];
  paymentLinks: PaymentLinkRecord[];
  webhooks: WebhookEventRecord[];
  inventory: InventoryItem[];
  mazdoorEscrows: MazdoorEscrowRecord[];
  treasury: FounderTreasuryState;
  idempotencyIndex: Record<string, string>;
  killSwitchFrozen: boolean;
  liveStreamEnabled: boolean;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const STATE_FILE = path.join(DATA_DIR, 'veritas-state.json');
const WAL_FILE = path.join(DATA_DIR, 'veritas.wal.ndjson');

const BRANCH_DIRECTORY: Record<
  Exclude<BranchId, 'all'>,
  { name: string; city: string; country: string }
> = {
  sakrand_hq: { name: 'Sakrand Main HQ', city: 'Sakrand, Sindh', country: 'Pakistan' },
  karachi_port: { name: 'Karachi Port Terminal', city: 'Karachi', country: 'Pakistan' },
  riyadh_hub: { name: 'Riyadh Trade Hub', city: 'Riyadh', country: 'Saudi Arabia' },
  dubai_marina: { name: 'Dubai Marina Desk', city: 'Dubai', country: 'United Arab Emirates' },
};

export function hashPasswordPbkdf2(password: string, saltHex?: string): {
  salt: string;
  hash: string;
} {
  const salt = saltHex || crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 120_000, 64, 'sha512').toString('hex');
  return { salt, hash };
}

export function verifyPasswordPbkdf2(password: string, salt: string, expectedHash: string): boolean {
  const derived = crypto.pbkdf2Sync(password, salt, 120_000, 64, 'sha512');
  const expectedBuf = Buffer.from(expectedHash, 'hex');
  if (derived.length !== expectedBuf.length) return false;
  return crypto.timingSafeEqual(derived, expectedBuf);
}

export function computeLedgerBlockHash(entry: {
  index: number;
  prevHash: string;
  reference: string;
  createdAt: string;
  entryType: LedgerEntryType;
  creditorName: string;
  debtorName: string;
  amount: number;
  currency: CurrencyCode;
  itemsSummary: string;
}): string {
  const canonical = [
    entry.index,
    entry.prevHash,
    entry.reference,
    entry.createdAt,
    entry.entryType,
    entry.creditorName,
    entry.debtorName,
    entry.amount,
    entry.currency,
    entry.itemsSummary,
  ].join('|');
  return crypto.createHash('sha256').update(canonical, 'utf8').digest('hex');
}

function computeUjrahFeeUsd(currency: CurrencyCode): number {
  if (currency === 'PKR') {
    return convertToUsd(25, 'PKR').usdAmount;
  }
  return 0.3;
}

function createSeedState(): PersistedWalState {
  const now = Date.now();
  const founderCreds = hashPasswordPbkdf2('Veritas@7860');
  const founderPin = hashPasswordPbkdf2('7860');
  const adminCreds = hashPasswordPbkdf2('Veritas@2026!');
  const mochiCreds = hashPasswordPbkdf2('Sakrand@7860');
  const mochiPin = hashPasswordPbkdf2('7860');

  const founderUser: StoredUser = {
    id: 'usr_founder_mahtab',
    email: 'mahtabjk123@gmail.com',
    phone: '03007860001',
    fullName: 'Mahtab Ali Jamali',
    businessName: 'SINDH-MIZAN Global HQ',
    location: 'Sakrand, Sindh, Pakistan',
    defaultRole: 'founder',
    subscriptionTier: 'enterprise_exporter',
    authProvider: 'founder',
    passkeyCount: 0,
    createdAt: new Date(now - 86400_000 * 30).toISOString(),
    passwordSalt: founderCreds.salt,
    passwordHash: founderCreds.hash,
    pinSalt: founderPin.salt,
    pinHash: founderPin.hash,
    credentials: [],
  };

  const operatorUser: StoredUser = {
    id: 'usr_veritas_admin',
    email: 'admin@bolmizan.pk',
    phone: '03008210002',
    fullName: 'Tariq Mehmood',
    businessName: 'Al-Noor Traders Sakrand',
    location: 'Sakrand, Sindh, Pakistan',
    defaultRole: 'merchant',
    subscriptionTier: 'pro_trader',
    authProvider: 'password',
    passkeyCount: 0,
    createdAt: new Date(now - 86400_000 * 14).toISOString(),
    passwordSalt: adminCreds.salt,
    passwordHash: adminCreds.hash,
    credentials: [],
  };

  const mochiWorkerUser: StoredUser = {
    id: 'usr_sakrand_mochi',
    email: 'khadim.mochi@sindhmizan.pk',
    phone: '03007860786',
    fullName: 'Khadim Hussain Mochi',
    businessName: 'Sakrand Chappal & Stitching Mart',
    location: 'Sakrand Bazaar, Sindh, Pakistan',
    defaultRole: 'merchant',
    subscriptionTier: 'mazdoor_free',
    authProvider: 'phone_pin',
    passkeyCount: 0,
    createdAt: new Date(now - 86400_000 * 10).toISOString(),
    passwordSalt: mochiCreds.salt,
    passwordHash: mochiCreds.hash,
    pinSalt: mochiPin.salt,
    pinHash: mochiPin.hash,
    credentials: [],
  };

  const rawLedgerInputs: Array<{
    minsAgo: number;
    branchId: Exclude<BranchId, 'all'>;
    entryType: LedgerEntryType;
    creditorName: string;
    debtorName: string;
    amount: number;
    currency: CurrencyCode;
    itemsSummary: string;
    language: 'en' | 'ur' | 'sd' | 'ar';
    voiceTranscript: string | null;
    dueDays: number | null;
    costBasisUsd?: number;
    murabahaMarkupUsd?: number;
  }> = [
    {
      minsAgo: 320,
      branchId: 'sakrand_hq',
      entryType: 'udhaar_given',
      creditorName: 'BolMizan Global HQ',
      debtorName: 'Sindh Agri Flour Mills',
      amount: 95000,
      currency: 'PKR',
      itemsSummary: 'Basmati Rice 25 Bags & Cotton Seed Cake',
      language: 'ur',
      voiceTranscript: 'سندھ ایگری فلور ملز کو 95,000 روپے کا چاول ادھار دیا',
      dueDays: 14,
    },
    {
      minsAgo: 260,
      branchId: 'karachi_port',
      entryType: 'udhaar_given',
      creditorName: 'Sindh Agri Flour Mills',
      debtorName: 'Indus Freight Carriers',
      amount: 68000,
      currency: 'PKR',
      itemsSummary: 'Sakrand-to-Karachi Port Container Dispatch',
      language: 'en',
      voiceTranscript: null,
      dueDays: 10,
    },
    {
      minsAgo: 210,
      branchId: 'karachi_port',
      entryType: 'udhaar_given',
      creditorName: 'Indus Freight Carriers',
      debtorName: 'BolMizan Global HQ',
      amount: 52000,
      currency: 'PKR',
      itemsSummary: 'Port Terminal Clearing & Wharfage Credit',
      language: 'en',
      voiceTranscript: null,
      dueDays: 12,
    },
    {
      minsAgo: 150,
      branchId: 'sakrand_hq',
      entryType: 'udhaar_given',
      creditorName: 'BolMizan Global HQ',
      debtorName: 'محبوب علي جمالي',
      amount: 14500,
      currency: 'PKR',
      itemsSummary: 'کھنڊ ۽ گيهه جا دٻا',
      language: 'sd',
      voiceTranscript: 'محبوب علي کي 14,500 جو اوڌار ڏنو',
      dueDays: 15,
    },
    {
      minsAgo: 90,
      branchId: 'riyadh_hub',
      entryType: 'murabaha_contract',
      creditorName: 'BolMizan Global HQ',
      debtorName: 'Riyadh Dates Import Co',
      amount: 4600,
      currency: 'SAR',
      itemsSummary: 'Murabaha Export Lot: Sindh Mango Pulp (Disclosed Cost + Fixed Margin)',
      language: 'ar',
      voiceTranscript: 'عقد مرابحة إسلامي بقيمة ٤٦٠٠ ريال لبضائع التصدير',
      dueDays: 30,
      costBasisUsd: 1080,
      murabahaMarkupUsd: 146.67,
    },
    {
      minsAgo: 45,
      branchId: 'dubai_marina',
      entryType: 'cash_sale',
      creditorName: 'BolMizan Global HQ',
      debtorName: 'Jebel Ali Textiles LLC',
      amount: 3200,
      currency: 'AED',
      itemsSummary: 'Sindhi Ajrak Heritage Textile Export Batch #18',
      language: 'en',
      voiceTranscript: null,
      dueDays: null,
    },
  ];

  const ledgerEntries: LedgerEntry[] = [];
  let prevHash = '0000000000000000000000000000000000000000000000000000000000000000';

  rawLedgerInputs.forEach((item, index) => {
    const createdAt = new Date(now - item.minsAgo * 60_000).toISOString();
    const reference = `VTS-${2010 + index}`;
    const { usdAmount } = convertToUsd(item.amount, item.currency);
    const hash = computeLedgerBlockHash({
      index,
      prevHash,
      reference,
      createdAt,
      entryType: item.entryType,
      creditorName: item.creditorName,
      debtorName: item.debtorName,
      amount: item.amount,
      currency: item.currency,
      itemsSummary: item.itemsSummary,
    });
    const seedWitnesses: LedgerWitness[] =
      index === 0
        ? [
            {
              id: 'wit_seed_1',
              witnessName: 'Haji Abdul Karim Jamali',
              witnessRole: 'Sakrand Grain Mandi Elder',
              otaqLocation: 'Sakrand Main Otaq, Sindh',
              signedAt: new Date(now - (item.minsAgo - 5) * 60_000).toISOString(),
            },
          ]
        : index === 3
          ? [
              {
                id: 'wit_seed_2',
                witnessName: 'Ustad Gulzar Mochi',
                witnessRole: 'Bazaar Artisan Witness (Shahadah)',
                otaqLocation: 'Sakrand Chappal Otaq, Sindh',
                signedAt: new Date(now - (item.minsAgo - 4) * 60_000).toISOString(),
              },
            ]
          : [];
    const entry: LedgerEntry = {
      id: `led_seed_${index + 1}`,
      index,
      reference,
      createdAt,
      branchId: item.branchId,
      entryType: item.entryType,
      status: item.entryType === 'cash_sale' ? 'settled' : 'open',
      creditorName: item.creditorName,
      debtorName: item.debtorName,
      amount: item.amount,
      currency: item.currency,
      usdAmount,
      costBasisUsd: item.costBasisUsd,
      murabahaMarkupUsd: item.murabahaMarkupUsd,
      itemsSummary: item.itemsSummary,
      dueDate: item.dueDays ? new Date(now + item.dueDays * 86400_000).toISOString().slice(0, 10) : null,
      graceExtendedUntil: null,
      language: item.language,
      voiceTranscript: item.voiceTranscript,
      signatureDataUrl: null,
      witnesses: seedWitnesses,
      cognitiveHumanScore: 96,
      ribaFeeBlocked: true,
      piiRedacted: false,
      prevHash,
      hash,
    };
    ledgerEntries.push(entry);
    prevHash = hash;
  });

  const inventory: InventoryItem[] = [
    {
      id: 'inv_1',
      sku: 'DAIRY-SKR-24',
      name: 'Sakrand Fresh Buffalo Milk Cartons (24-Pack)',
      category: 'Perishable Dairy',
      branchId: 'sakrand_hq',
      expectedQty: 140,
      dispatchedQty: 25,
      actualRemainingQty: 109,
      unitCostPkr: 3600,
      unitSellPkr: 4300,
      expiryDate: new Date(now + 11 * 86400_000).toISOString().slice(0, 10),
      rescuedCount: 0,
      updatedAt: new Date(now - 3600_000).toISOString(),
    },
    {
      id: 'inv_2',
      sku: 'PHARMA-KHI-500',
      name: 'Amoxicillin 500mg Pharmacy Lot',
      category: 'Medical',
      branchId: 'karachi_port',
      expectedQty: 80,
      dispatchedQty: 12,
      actualRemainingQty: 68,
      unitCostPkr: 950,
      unitSellPkr: 1350,
      expiryDate: new Date(now + 19 * 86400_000).toISOString().slice(0, 10),
      rescuedCount: 0,
      updatedAt: new Date(now - 7200_000).toISOString(),
    },
    {
      id: 'inv_3',
      sku: 'GRAIN-BAS-25',
      name: 'Sindh Super Kernel Basmati Rice (25kg)',
      category: 'Grains & Exports',
      branchId: 'dubai_marina',
      expectedQty: 220,
      dispatchedQty: 40,
      actualRemainingQty: 180,
      unitCostPkr: 7200,
      unitSellPkr: 8400,
      expiryDate: new Date(now + 180 * 86400_000).toISOString().slice(0, 10),
      rescuedCount: 2,
      updatedAt: new Date(now - 10800_000).toISOString(),
    },
  ];

  const mazdoorEscrows: MazdoorEscrowRecord[] = [
    {
      id: 'esc_1',
      workerName: 'الله ڈنو ملاح (Allah Dinu)',
      workerPhone: '03018874321',
      employerName: 'Sakrand Cold Storage Warehouse',
      workDescription: 'Full-day cotton & grain sack loading shift',
      dailyWagePkr: 2400,
      payoutRail: 'sbp_raast',
      branchId: 'sakrand_hq',
      status: 'locked',
      lockedAt: new Date(now - 4 * 3600_000).toISOString(),
      releasedAt: null,
      releaseRef: null,
      language: 'sd',
    },
    {
      id: 'esc_2',
      workerName: 'غلام مرتضیٰ (Ghulam Murtaza)',
      workerPhone: '03452109843',
      employerName: 'Karachi Port Export Depot #4',
      workDescription: 'Solar cold-room electrical maintenance day wage',
      dailyWagePkr: 3500,
      payoutRail: 'jazzcash',
      branchId: 'karachi_port',
      status: 'locked',
      lockedAt: new Date(now - 2 * 3600_000).toISOString(),
      releasedAt: null,
      releaseRef: null,
      language: 'ur',
    },
    {
      id: 'esc_3',
      workerName: 'نذير احمد لاکو (Nazeer Lakho)',
      workerPhone: '03127765410',
      employerName: 'Jamali Agri Farms Sakrand',
      workDescription: 'Wheat threshing & irrigation canal prep',
      dailyWagePkr: 2200,
      payoutRail: 'easypaisa',
      branchId: 'sakrand_hq',
      status: 'released',
      lockedAt: new Date(now - 26 * 3600_000).toISOString(),
      releasedAt: new Date(now - 18 * 3600_000).toISOString(),
      releaseRef: 'HAQ-90412',
      language: 'sd',
    },
  ];

  const paymentLinks: PaymentLinkRecord[] = [
    {
      id: 'lnk_raast_b2b',
      slug: 'sakrand-mandi-raast',
      title: 'Sakrand & Karachi Mandi Instant Settlement',
      description: 'Zero-Riba SBP Raast, JazzCash, Easypaisa & Global Cards.',
      amount: 45000,
      currency: 'PKR',
      active: true,
      allowedCategories: ['Pakistan & MENA', 'Global Cards & Wallets'],
      utmSource: 'whatsapp_sakrand',
      utmCampaign: 'raast_instant',
      creatorHandle: '@mahtab_jamali',
      clicks: 412,
      conversions: 58,
      totalVolumeUsd: 9420,
      createdAt: new Date(now - 86400_000 * 5).toISOString(),
    },
    {
      id: 'lnk_gulf_export',
      slug: 'ksa-uae-zatca-invoice',
      title: 'GCC Export Murabaha Invoice (ZATCA Phase-2)',
      description: 'Saudi Mada, STC Pay, UAE Aani & Wise multi-currency export clearing.',
      amount: 3800,
      currency: 'SAR',
      active: true,
      allowedCategories: ['Pakistan & MENA', 'International Bank Rails', 'Web3 & APAC'],
      utmSource: 'riyadh_trade_hub',
      utmCampaign: 'gcc_export',
      creatorHandle: '@bolmizan_hq',
      clicks: 215,
      conversions: 24,
      totalVolumeUsd: 24320,
      createdAt: new Date(now - 86400_000 * 3).toISOString(),
    },
  ];

  const seedPayments: Array<{
    minsAgo: number;
    branchId: Exclude<BranchId, 'all'>;
    amount: number;
    currency: CurrencyCode;
    railId: PaymentRailId;
    customerName: string;
    customerEmail: string;
    customerCountry: string;
    masked: string;
    utmSource: string;
  }> = [
    {
      minsAgo: 55,
      branchId: 'sakrand_hq',
      amount: 45000,
      currency: 'PKR',
      railId: 'sbp_raast',
      customerName: 'Usman Kiani',
      customerEmail: 'usman.kiani@sakrandagro.pk',
      customerCountry: 'Pakistan',
      masked: 'PK36 •••• 6702',
      utmSource: 'whatsapp_sakrand',
    },
    {
      minsAgo: 44,
      branchId: 'riyadh_hub',
      amount: 3800,
      currency: 'SAR',
      railId: 'stc_pay',
      customerName: 'Faisal Al-Harbi',
      customerEmail: 'faisal@jeddahtrade.sa',
      customerCountry: 'Saudi Arabia',
      masked: '+96650•••567',
      utmSource: 'riyadh_trade_hub',
    },
    {
      minsAgo: 34,
      branchId: 'karachi_port',
      amount: 1450,
      currency: 'EUR',
      railId: 'sepa_instant',
      customerName: 'Clara Weber',
      customerEmail: 'clara@hamburgimport.de',
      customerCountry: 'Germany',
      masked: 'DE89 •••• 3000',
      utmSource: 'partner_eu',
    },
    {
      minsAgo: 26,
      branchId: 'sakrand_hq',
      amount: 32500,
      currency: 'PKR',
      railId: 'jazzcash',
      customerName: 'Sanaullah Dahri',
      customerEmail: 'sana@benazirabad.pk',
      customerCountry: 'Pakistan',
      masked: '0300••••567',
      utmSource: 'whatsapp_sakrand',
    },
    {
      minsAgo: 18,
      branchId: 'dubai_marina',
      amount: 2100,
      currency: 'USD',
      railId: 'usdc_base',
      customerName: 'Kenji Sato',
      customerEmail: 'kenji@pacificdesk.sg',
      customerCountry: 'Singapore',
      masked: '0x71C7•••76F',
      utmSource: 'api_partner',
    },
    {
      minsAgo: 11,
      branchId: 'karachi_port',
      amount: 16800,
      currency: 'INR',
      railId: 'india_upi',
      customerName: 'Ananya Verma',
      customerEmail: 'ananya@mumbaispice.in',
      customerCountry: 'India',
      masked: 'an•••@okicici',
      utmSource: 'direct_checkout',
    },
    {
      minsAgo: 5,
      branchId: 'dubai_marina',
      amount: 2650,
      currency: 'AED',
      railId: 'uae_aani',
      customerName: 'Rashid Al-Maktoum',
      customerEmail: 'rashid@jebelali.ae',
      customerCountry: 'United Arab Emirates',
      masked: '+97150•••567',
      utmSource: 'dubai_trade',
    },
  ];

  const transactions: PaymentTransaction[] = [];
  const webhooks: WebhookEventRecord[] = [];
  const idempotencyIndex: Record<string, string> = {};

  seedPayments.forEach((p, idx) => {
    const rail = RAIL_BY_ID[p.railId];
    const { usdAmount, fxRateUsed } = convertToUsd(p.amount, p.currency);
    const feeUsd = Number(((usdAmount * rail.baseFeePct) / 100 + rail.fixedFeeUsd).toFixed(2));
    const ujrahFeeUsd = computeUjrahFeeUsd(p.currency);
    const netUsd = Number(Math.max(0, usdAmount - feeUsd).toFixed(2));
    const createdAt = new Date(now - p.minsAgo * 60_000).toISOString();
    const txId = `tx_seed_${idx + 1}`;
    const reference = `BMZ-${40200 + idx}`;
    const idemp = `idem_seed_${idx + 1}`;

    const tx: PaymentTransaction = {
      id: txId,
      reference,
      createdAt,
      settledAt: createdAt,
      branchId: p.branchId,
      amount: p.amount,
      currency: p.currency,
      usdAmount,
      feeUsd,
      netUsd,
      ujrahFeeUsd,
      fxRateUsed,
      railId: p.railId,
      railName: rail.shortName,
      connectorMode: 'sandbox_clearing',
      gatewayIntentId: `vts_${p.railId.slice(0, 4)}_seed${idx + 10}`,
      status: 'settled',
      customerName: p.customerName,
      customerEmail: p.customerEmail,
      customerCountry: p.customerCountry,
      maskedInstrument: p.masked,
      paymentLinkId: null,
      utmSource: p.utmSource,
      utmCampaign: 'veritas_omega_v18',
      creatorHandle: '@mahtab_jamali',
      idempotencyKey: idemp,
      piiRedacted: false,
      qrPayload: null,
    };
    transactions.unshift(tx);
    idempotencyIndex[idemp] = txId;

    const payloadJson = JSON.stringify({
      id: `evt_${txId}`,
      type: 'payment.settled',
      createdAt,
      data: { reference, usdAmount, ujrahFeeUsd, branchId: p.branchId, railId: p.railId },
    });
    webhooks.unshift({
      id: `wh_seed_${idx + 1}`,
      eventType: 'payment.settled',
      transactionId: txId,
      endpointUrl: 'https://hooks.merchant.internal/veritas',
      signatureHeader: signWebhookPayload(payloadJson),
      payloadJson,
      httpStatus: 200,
      latencyMs: 28 + idx * 5,
      createdAt,
    });
  });

  const treasuryEntries: TreasuryEntry[] = [
    {
      id: 'trs_1',
      createdAt: new Date(now - 7200_000).toISOString(),
      type: 'saas_subscription',
      description: '18x Enterprise Exporter Plans ($79/mo) & 70x Pro Trader Plans ($15/mo) MRR Settlement',
      amountUsd: 2472.0,
      amountPkr: convertToPkr(2472.0, 'USD'),
      railUsed: 'Stripe & SBP Raast',
      reference: 'SAAS-MRR-OMEGA',
    },
    {
      id: 'trs_2',
      createdAt: new Date(now - 3600_000).toISOString(),
      type: 'ujrah_murabaha',
      description: 'Fixed Shariah Ujrah Fee ($0.30/contract) — Riyadh Dates Murabaha Lot #44',
      amountUsd: 0.3,
      amountPkr: convertToPkr(0.3, 'USD'),
      railUsed: 'STC Pay / ZATCA',
      reference: 'UJR-MRB-2014',
    },
    {
      id: 'trs_3',
      createdAt: new Date(now - 1800_000).toISOString(),
      type: 'ujrah_settlement',
      description: 'Cross-Border Clearing Ujrah (SEPA, Aani, USDC Base, India UPI, STC Pay)',
      amountUsd: 1.5,
      amountPkr: convertToPkr(1.5, 'USD'),
      railUsed: '21-Rail Orchestrator',
      reference: 'UJR-CLR-5510',
    },
    {
      id: 'trs_4',
      createdAt: new Date(now - 600_000).toISOString(),
      type: 'ujrah_expiry_rescue',
      description: 'Maal-Guard B2B 30% Expiry Rescue Facilitation Ujrah (2 deals)',
      amountUsd: 0.6,
      amountPkr: convertToPkr(0.6, 'USD'),
      railUsed: 'Maal-Guard B2B',
      reference: 'UJR-RES-8841',
    },
  ];

  const treasury: FounderTreasuryState = {
    founderName: 'Mahtab Ali Jamali',
    founderEmail: 'mahtabjk123@gmail.com',
    hqLocation: 'Sakrand, Sindh, Pakistan',
    mrrUsd: 2472.0,
    cumulativeUjrahUsd: 2.4,
    availableBalanceUsd: 2474.4,
    totalWithdrawnUsd: 0,
    activeProSubscribers: 70,
    activeEnterpriseSubscribers: 18,
    entries: treasuryEntries,
  };

  return {
    users: [founderUser, operatorUser, mochiWorkerUser],
    ledgerEntries,
    transactions,
    paymentLinks,
    webhooks,
    inventory,
    mazdoorEscrows,
    treasury,
    idempotencyIndex,
    killSwitchFrozen: false,
    liveStreamEnabled: true,
  };
}

class WalLedgerStore {
  private state: PersistedWalState;
  private writeQueue: Promise<void> = Promise.resolve();

  constructor() {
    this.state = this.load();
  }

  private load(): PersistedWalState {
    try {
      if (fs.existsSync(STATE_FILE)) {
        const raw = fs.readFileSync(STATE_FILE, 'utf8');
        const parsed = JSON.parse(raw) as PersistedWalState;
        if (
          Array.isArray(parsed.users) &&
          Array.isArray(parsed.ledgerEntries) &&
          Array.isArray(parsed.mazdoorEscrows) &&
          parsed.treasury
        ) {
          // Backfill pre-seeded worker phone login & default Otaq witness metadata if migrating from prior state
          if (!parsed.users.some((u) => normalizePhoneNumber(u.phone || '') === '03007860786')) {
            const mochiCreds = hashPasswordPbkdf2('Sakrand@7860');
            const mochiPin = hashPasswordPbkdf2('7860');
            parsed.users.push({
              id: 'usr_sakrand_mochi',
              email: 'khadim.mochi@sindhmizan.pk',
              phone: '03007860786',
              fullName: 'Khadim Hussain Mochi',
              businessName: 'Sakrand Chappal & Stitching Mart',
              location: 'Sakrand Bazaar, Sindh, Pakistan',
              defaultRole: 'merchant',
              subscriptionTier: 'mazdoor_free',
              authProvider: 'phone_pin',
              passkeyCount: 0,
              createdAt: new Date().toISOString(),
              passwordSalt: mochiCreds.salt,
              passwordHash: mochiCreds.hash,
              pinSalt: mochiPin.salt,
              pinHash: mochiPin.hash,
              credentials: [],
            });
          }
          const founder = parsed.users.find((u) => u.email.toLowerCase() === 'mahtabjk123@gmail.com');
          if (founder && !founder.pinHash) {
            const pinPair = hashPasswordPbkdf2('7860');
            founder.pinSalt = pinPair.salt;
            founder.pinHash = pinPair.hash;
            founder.phone = founder.phone || '03007860001';
            founder.authProvider = founder.authProvider || 'founder';
          }
          return parsed;
        }
      }
    } catch {
      // Fallback to clean v18 OMEGA seed
    }
    const seed = createSeedState();
    this.writeAtomicSync(seed, 'wal:init:v18_omega');
    return seed;
  }

  private writeAtomicSync(target: PersistedWalState, walEvent: string) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const walLine = JSON.stringify({ ts: new Date().toISOString(), event: walEvent }) + '\n';
      fs.appendFileSync(WAL_FILE, walLine, 'utf8');
      const tmp = `${STATE_FILE}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(target, null, 2), 'utf8');
      fs.renameSync(tmp, STATE_FILE);
    } catch {
      // Safe fallback
    }
  }

  private enqueuePersist(walEvent: string): Promise<void> {
    this.writeQueue = this.writeQueue.then(() => {
      this.writeAtomicSync(this.state, walEvent);
    });
    return this.writeQueue;
  }

  // --- Auth & Users ---
  findUserByEmail(email: string): StoredUser | undefined {
    const clean = email.trim().toLowerCase();
    return this.state.users.find((u) => u.email.toLowerCase() === clean);
  }

  findUserByPhone(phone: string): StoredUser | undefined {
    const normalized = normalizePhoneNumber(phone);
    if (!normalized) return undefined;
    return this.state.users.find((u) => normalizePhoneNumber(u.phone || '') === normalized);
  }

  findUserById(id: string): StoredUser | undefined {
    return this.state.users.find((u) => u.id === id);
  }

  toPublicUser(user: StoredUser): UserPublicProfile {
    return {
      id: user.id,
      email: user.email,
      phone: user.phone,
      fullName: user.fullName,
      businessName: user.businessName,
      location: user.location || 'Sakrand, Sindh, Pakistan',
      defaultRole: user.defaultRole,
      subscriptionTier: user.subscriptionTier || 'mazdoor_free',
      authProvider: user.authProvider || 'password',
      passkeyCount: user.credentials.length,
      createdAt: user.createdAt,
    };
  }

  async registerUser(params: {
    email: string;
    password: string;
    fullName: string;
    businessName: string;
    location: string;
    defaultRole: WorkspaceRole;
    phone?: string;
    authProvider?: AuthProviderKind;
  }): Promise<StoredUser> {
    const { salt, hash } = hashPasswordPbkdf2(params.password);
    const user: StoredUser = {
      id: `usr_${crypto.randomBytes(5).toString('hex')}`,
      email: params.email.trim().toLowerCase(),
      phone: params.phone ? normalizePhoneNumber(params.phone) : undefined,
      fullName: params.fullName.trim(),
      businessName: params.businessName.trim(),
      location: params.location.trim(),
      defaultRole: params.defaultRole,
      subscriptionTier: 'mazdoor_free',
      authProvider: params.authProvider || 'password',
      passkeyCount: 0,
      createdAt: new Date().toISOString(),
      passwordSalt: salt,
      passwordHash: hash,
      credentials: [],
    };
    this.state.users.push(user);
    await this.enqueuePersist(`auth:register:${user.id}`);
    return user;
  }

  async loginOrRegisterGoogle(params: {
    email: string;
    fullName: string;
    businessName?: string;
    location?: string;
  }): Promise<StoredUser> {
    const existing = this.findUserByEmail(params.email);
    if (existing) {
      return existing;
    }
    const randomPw = crypto.randomBytes(24).toString('hex');
    const user = await this.registerUser({
      email: params.email,
      password: randomPw,
      fullName: params.fullName,
      businessName: params.businessName?.trim() || `${params.fullName.trim()} Trade Desk`,
      location: params.location?.trim() || 'Sakrand, Sindh, Pakistan',
      defaultRole: 'merchant',
      authProvider: 'google',
    });
    return user;
  }

  async loginOrRegisterPhoneOtp(params: {
    phone: string;
    fullName?: string;
    businessName?: string;
    location?: string;
  }): Promise<StoredUser> {
    const normalized = normalizePhoneNumber(params.phone);
    const existing = this.findUserByPhone(normalized);
    if (existing) {
      return existing;
    }
    const randomPw = crypto.randomBytes(24).toString('hex');
    const cleanName = params.fullName?.trim() || `Sindh Trader ${normalized.slice(-4)}`;
    return this.registerUser({
      email: `wa_${normalized}@sindhmizan.pk`,
      phone: normalized,
      password: randomPw,
      fullName: cleanName,
      businessName: params.businessName?.trim() || `${cleanName} Shop`,
      location: params.location?.trim() || 'Sakrand, Sindh, Pakistan',
      defaultRole: 'merchant',
      authProvider: 'whatsapp_otp',
    });
  }

  async loginOrRegisterPhonePin(params: {
    phone: string;
    pin: string;
    fullName?: string;
    businessName?: string;
    location?: string;
  }): Promise<StoredUser | { error: string }> {
    const normalized = normalizePhoneNumber(params.phone);
    const existing = this.findUserByPhone(normalized);
    if (existing) {
      if (existing.pinSalt && existing.pinHash) {
        const ok = verifyPasswordPbkdf2(params.pin, existing.pinSalt, existing.pinHash);
        if (!ok) {
          return { error: 'Incorrect mobile PIN. Please try again.' };
        }
        return existing;
      }
      // First time setting mobile PIN for an existing phone account
      const pinPair = hashPasswordPbkdf2(params.pin);
      existing.pinSalt = pinPair.salt;
      existing.pinHash = pinPair.hash;
      await this.enqueuePersist(`auth:phone_pin_bind:${existing.id}`);
      return existing;
    }

    const randomPw = crypto.randomBytes(24).toString('hex');
    const pinPair = hashPasswordPbkdf2(params.pin);
    const cleanName = params.fullName?.trim() || `Mazdoor ${normalized.slice(-4)}`;
    const user = await this.registerUser({
      email: `mob_${normalized}@sindhmizan.pk`,
      phone: normalized,
      password: randomPw,
      fullName: cleanName,
      businessName: params.businessName?.trim() || `${cleanName} Bazaar`,
      location: params.location?.trim() || 'Sakrand, Sindh, Pakistan',
      defaultRole: 'merchant',
      authProvider: 'phone_pin',
    });
    user.pinSalt = pinPair.salt;
    user.pinHash = pinPair.hash;
    await this.enqueuePersist(`auth:phone_pin_create:${user.id}`);
    return user;
  }

  async upgradeUserSubscription(
    userId: string,
    tierId: SaasTierId,
    railId: PaymentRailId
  ): Promise<{ user: UserPublicProfile; treasury: FounderTreasuryState } | null> {
    const user = this.findUserById(userId);
    if (!user) return null;

    const priceMap: Record<SaasTierId, number> = {
      mazdoor_free: 0,
      pro_trader: 15,
      enterprise_exporter: 79,
    };

    const prevTier = user.subscriptionTier;
    user.subscriptionTier = tierId;

    if (tierId !== 'mazdoor_free' && prevTier !== tierId) {
      const feeUsd = priceMap[tierId];
      if (tierId === 'pro_trader') this.state.treasury.activeProSubscribers += 1;
      if (tierId === 'enterprise_exporter') this.state.treasury.activeEnterpriseSubscribers += 1;

      this.state.treasury.mrrUsd =
        this.state.treasury.activeProSubscribers * 15 +
        this.state.treasury.activeEnterpriseSubscribers * 79;
      this.state.treasury.availableBalanceUsd = Number(
        (this.state.treasury.availableBalanceUsd + feeUsd).toFixed(2)
      );

      this.state.treasury.entries.unshift({
        id: `trs_${crypto.randomBytes(4).toString('hex')}`,
        createdAt: new Date().toISOString(),
        type: 'saas_subscription',
        description: `SaaS Upgrade (${user.fullName}) → ${tierId.replace('_', ' ')}`,
        amountUsd: feeUsd,
        amountPkr: convertToPkr(feeUsd, 'USD'),
        railUsed: RAIL_BY_ID[railId]?.shortName || 'SBP Raast',
        reference: `SAAS-${crypto.randomBytes(2).toString('hex').toUpperCase()}`,
      });
    }

    await this.enqueuePersist(`saas:upgrade:${user.id}:${tierId}`);
    return { user: this.toPublicUser(user), treasury: this.state.treasury };
  }

  async withdrawFounderTreasury(params: {
    amountUsd: number;
    railId: PaymentRailId;
    destinationInput: string;
  }): Promise<FounderTreasuryState | { error: string }> {
    if (params.amountUsd > this.state.treasury.availableBalanceUsd) {
      return {
        error: `Requested $${params.amountUsd.toFixed(2)} exceeds available balance ($${this.state.treasury.availableBalanceUsd.toFixed(2)}).`,
      };
    }

    const debit = Number(params.amountUsd.toFixed(2));
    this.state.treasury.availableBalanceUsd = Number(
      (this.state.treasury.availableBalanceUsd - debit).toFixed(2)
    );
    this.state.treasury.totalWithdrawnUsd = Number(
      (this.state.treasury.totalWithdrawnUsd + debit).toFixed(2)
    );

    const maskedDest =
      params.destinationInput.length > 8
        ? `${params.destinationInput.slice(0, 4)}•••${params.destinationInput.slice(-4)}`
        : params.destinationInput;

    this.state.treasury.entries.unshift({
      id: `trs_${crypto.randomBytes(4).toString('hex')}`,
      createdAt: new Date().toISOString(),
      type: 'founder_withdrawal',
      description: `Founder Payout to Mahtab Ali Jamali (${maskedDest})`,
      amountUsd: -debit,
      amountPkr: -convertToPkr(debit, 'USD'),
      railUsed: RAIL_BY_ID[params.railId]?.shortName || params.railId,
      reference: `WDR-${Math.floor(10000 + Math.random() * 89000)}`,
    });

    await this.enqueuePersist(`treasury:withdraw:${debit}`);
    return this.state.treasury;
  }

  private creditUjrahToTreasury(
    type: TreasuryEntry['type'],
    amountUsd: number,
    description: string,
    railUsed: string,
    reference: string
  ) {
    const clean = Number(amountUsd.toFixed(2));
    if (clean <= 0) return;
    this.state.treasury.cumulativeUjrahUsd = Number(
      (this.state.treasury.cumulativeUjrahUsd + clean).toFixed(2)
    );
    this.state.treasury.availableBalanceUsd = Number(
      (this.state.treasury.availableBalanceUsd + clean).toFixed(2)
    );
    this.state.treasury.entries.unshift({
      id: `trs_${crypto.randomBytes(4).toString('hex')}`,
      createdAt: new Date().toISOString(),
      type,
      description,
      amountUsd: clean,
      amountPkr: convertToPkr(clean, 'USD'),
      railUsed,
      reference,
    });
    if (this.state.treasury.entries.length > 80) {
      this.state.treasury.entries = this.state.treasury.entries.slice(0, 80);
    }
  }

  async addUserWebAuthnCredential(
    userId: string,
    credential: WebAuthnStoredCredential
  ): Promise<void> {
    const user = this.findUserById(userId);
    if (!user) return;
    user.credentials.push(credential);
    user.passkeyCount = user.credentials.length;
    await this.enqueuePersist(`auth:passkey_add:${user.id}`);
  }

  async updateCredentialCounter(userId: string, credId: string, newCounter: number): Promise<void> {
    const user = this.findUserById(userId);
    if (!user) return;
    const cred = user.credentials.find((c) => c.id === credId);
    if (cred) {
      cred.counter = newCounter;
      await this.enqueuePersist(`auth:passkey_counter:${user.id}`);
    }
  }

  // --- Shariah Smart Ledger ---
  verifyHashChain(): ChainVerificationResult {
    const entries = [...this.state.ledgerEntries].sort((a, b) => a.index - b.index);
    let expectedPrev = '0000000000000000000000000000000000000000000000000000000000000000';
    let verifiedBlocks = 0;

    for (let i = 0; i < entries.length; i++) {
      const e = entries[i];
      const recomputed = computeLedgerBlockHash({
        index: e.index,
        prevHash: expectedPrev,
        reference: e.reference,
        createdAt: e.createdAt,
        entryType: e.entryType,
        creditorName: e.creditorName,
        debtorName: e.debtorName,
        amount: e.amount,
        currency: e.currency,
        itemsSummary: e.itemsSummary,
      });

      if (e.prevHash !== expectedPrev || e.hash !== recomputed) {
        return {
          intact: false,
          totalBlocks: entries.length,
          verifiedBlocks,
          brokenAtIndex: e.index,
          checkedAt: new Date().toISOString(),
        };
      }
      expectedPrev = e.hash;
      verifiedBlocks += 1;
    }

    return {
      intact: true,
      totalBlocks: entries.length,
      verifiedBlocks,
      brokenAtIndex: null,
      checkedAt: new Date().toISOString(),
    };
  }

  async appendLedgerEntry(params: {
    branchId?: Exclude<BranchId, 'all'>;
    entryType: LedgerEntryType;
    creditorName: string;
    debtorName: string;
    amount: number;
    currency: CurrencyCode;
    costBasisUsd?: number;
    murabahaMarkupUsd?: number;
    itemsSummary: string;
    dueDate: string | null;
    language: 'en' | 'ur' | 'sd' | 'ar';
    voiceTranscript: string | null;
    signatureDataUrl: string | null;
    cognitiveHumanScore: number;
  }): Promise<LedgerEntry> {
    const sorted = [...this.state.ledgerEntries].sort((a, b) => a.index - b.index);
    const last = sorted[sorted.length - 1];
    const index = last ? last.index + 1 : 0;
    const prevHash = last
      ? last.hash
      : '0000000000000000000000000000000000000000000000000000000000000000';

    const createdAt = new Date().toISOString();
    const reference = `VTS-${2010 + index}`;
    const { usdAmount } = convertToUsd(params.amount, params.currency);

    const hash = computeLedgerBlockHash({
      index,
      prevHash,
      reference,
      createdAt,
      entryType: params.entryType,
      creditorName: params.creditorName,
      debtorName: params.debtorName,
      amount: params.amount,
      currency: params.currency,
      itemsSummary: params.itemsSummary,
    });

    const entry: LedgerEntry = {
      id: `led_${crypto.randomBytes(5).toString('hex')}`,
      index,
      reference,
      createdAt,
      branchId: params.branchId || 'sakrand_hq',
      entryType: params.entryType,
      status:
        params.entryType === 'cash_sale' ||
        params.entryType === 'payment_received' ||
        params.entryType === 'mukasa_settlement'
          ? 'settled'
          : params.entryType === 'sadqah_maafi'
            ? 'sadqah_forgiven'
            : 'open',
      creditorName: params.creditorName,
      debtorName: params.debtorName,
      amount: params.amount,
      currency: params.currency,
      usdAmount,
      costBasisUsd: params.costBasisUsd,
      murabahaMarkupUsd: params.murabahaMarkupUsd,
      itemsSummary: params.itemsSummary,
      dueDate: params.dueDate,
      graceExtendedUntil: null,
      language: params.language,
      voiceTranscript: params.voiceTranscript,
      signatureDataUrl: params.signatureDataUrl,
      cognitiveHumanScore: params.cognitiveHumanScore,
      ribaFeeBlocked: true,
      piiRedacted: false,
      prevHash,
      hash,
    };

    this.state.ledgerEntries.push(entry);

    if (params.entryType === 'murabaha_contract' || params.entryType === 'salam_contract') {
      this.creditUjrahToTreasury(
        'ujrah_murabaha',
        0.3,
        `Flat Trade Contract Ujrah (${entry.reference})`,
        'Murabaha / Salam Engine',
        `UJR-${entry.reference}`
      );
    }

    await this.enqueuePersist(`ledger:append:${entry.reference}`);
    return entry;
  }

  async addLedgerWitness(
    entryId: string,
    witness: { witnessName: string; witnessRole: string; otaqLocation: string }
  ): Promise<LedgerEntry | null> {
    const entry = this.state.ledgerEntries.find((e) => e.id === entryId);
    if (!entry) return null;
    if (!Array.isArray(entry.witnesses)) {
      entry.witnesses = [];
    }
    entry.witnesses.push({
      id: `wit_${crypto.randomBytes(4).toString('hex')}`,
      witnessName: witness.witnessName.trim(),
      witnessRole: witness.witnessRole.trim(),
      otaqLocation: witness.otaqLocation.trim(),
      signedAt: new Date().toISOString(),
    });
    await this.enqueuePersist(`ledger:witness:${entry.reference}`);
    return entry;
  }

  async grantGracePeriod15Days(entryId: string): Promise<LedgerEntry | null> {
    const entry = this.state.ledgerEntries.find((e) => e.id === entryId);
    if (!entry) return null;
    const baseMs = entry.dueDate ? Math.max(Date.now(), Date.parse(entry.dueDate)) : Date.now();
    const extendedDate = new Date(baseMs + 15 * 86400_000).toISOString().slice(0, 10);
    entry.status = 'grace_15d';
    entry.graceExtendedUntil = extendedDate;
    await this.enqueuePersist(`ledger:grace15d:${entry.reference}`);
    return entry;
  }

  async convertToSadqahMaafi(entryId: string): Promise<LedgerEntry | null> {
    const entry = this.state.ledgerEntries.find((e) => e.id === entryId);
    if (!entry) return null;
    entry.status = 'sadqah_forgiven';
    await this.appendLedgerEntry({
      branchId: entry.branchId,
      entryType: 'sadqah_maafi',
      creditorName: entry.creditorName,
      debtorName: entry.debtorName,
      amount: entry.amount,
      currency: entry.currency,
      itemsSummary: `Quran 2:280 Sadqah / Maafi forgiveness for ${entry.reference}`,
      dueDate: null,
      language: entry.language,
      voiceTranscript: null,
      signatureDataUrl: entry.signatureDataUrl,
      cognitiveHumanScore: 100,
    });
    return entry;
  }

  async settleMukasaCycle(cycleId: string): Promise<{
    settledAmountPkr: number;
    participants: string[];
  } | null> {
    const cycles = detectDebtCycles(this.state.ledgerEntries);
    const target = cycles.find((c) => c.id === cycleId);
    if (!target) return null;

    for (const edge of target.edges) {
      for (const entryId of edge.entryIds) {
        const entry = this.state.ledgerEntries.find((e) => e.id === entryId);
        if (!entry) continue;
        const pkrVal = convertToPkr(entry.amount, entry.currency);
        if (pkrVal <= target.offsetAmountPkr) {
          entry.status = 'settled';
        }
      }
    }

    await this.appendLedgerEntry({
      branchId: 'sakrand_hq',
      entryType: 'mukasa_settlement',
      creditorName: target.participants[0],
      debtorName: target.participants.join(' → '),
      amount: target.offsetAmountPkr,
      currency: 'PKR',
      itemsSummary: `Zero-Cash Mukasa Cycle Offset (${target.participants.join(' → ')})`,
      dueDate: null,
      language: 'en',
      voiceTranscript: null,
      signatureDataUrl: null,
      cognitiveHumanScore: 100,
    });

    return {
      settledAmountPkr: target.offsetAmountPkr,
      participants: target.participants,
    };
  }

  // --- Haq-e-Mazdoor Daily-Wage & Kisan Escrow Vault ---
  async createMazdoorEscrow(input: {
    workerName: string;
    workerPhone: string;
    employerName: string;
    workDescription: string;
    dailyWagePkr: number;
    payoutRail: 'sbp_raast' | 'jazzcash' | 'easypaisa';
    branchId: Exclude<BranchId, 'all'>;
    language: 'en' | 'ur' | 'sd' | 'ar';
  }): Promise<MazdoorEscrowRecord> {
    const escrow: MazdoorEscrowRecord = {
      id: `esc_${crypto.randomBytes(4).toString('hex')}`,
      workerName: input.workerName,
      workerPhone: input.workerPhone,
      employerName: input.employerName,
      workDescription: input.workDescription,
      dailyWagePkr: Math.round(input.dailyWagePkr),
      payoutRail: input.payoutRail,
      branchId: input.branchId,
      status: 'locked',
      lockedAt: new Date().toISOString(),
      releasedAt: null,
      releaseRef: null,
      language: input.language,
    };
    this.state.mazdoorEscrows.unshift(escrow);
    await this.enqueuePersist(`escrow:lock:${escrow.id}`);
    return escrow;
  }

  async releaseMazdoorEscrow(escrowId: string): Promise<MazdoorEscrowRecord | null> {
    const escrow = this.state.mazdoorEscrows.find((e) => e.id === escrowId);
    if (!escrow || escrow.status === 'released') return null;
    escrow.status = 'released';
    escrow.releasedAt = new Date().toISOString();
    escrow.releaseRef = `HAQ-${Math.floor(10000 + Math.random() * 89000)}`;

    // Record worker-honoring release onto SHA-256 ledger (0% fee)
    await this.appendLedgerEntry({
      branchId: escrow.branchId,
      entryType: 'payment_received',
      creditorName: escrow.workerName,
      debtorName: escrow.employerName,
      amount: escrow.dailyWagePkr,
      currency: 'PKR',
      itemsSummary: `Haq-e-Mazdoor Instant Wage Release (${escrow.payoutRail.toUpperCase()} · ${escrow.releaseRef})`,
      dueDate: null,
      language: escrow.language,
      voiceTranscript: null,
      signatureDataUrl: null,
      cognitiveHumanScore: 100,
    });

    await this.enqueuePersist(`escrow:release:${escrow.id}`);
    return escrow;
  }

  // --- Payments & Webhooks ---
  getTransactionByIdempotency(key: string): PaymentTransaction | null {
    const id = this.state.idempotencyIndex[key];
    if (!id) return null;
    return this.state.transactions.find((t) => t.id === id) ?? null;
  }

  async recordPaymentTransaction(tx: PaymentTransaction): Promise<WebhookEventRecord> {
    const ujrah = tx.ujrahFeeUsd ?? computeUjrahFeeUsd(tx.currency);
    const enriched: PaymentTransaction = { ...tx, ujrahFeeUsd: ujrah };

    this.state.transactions.unshift(enriched);
    if (this.state.transactions.length > 250) {
      this.state.transactions = this.state.transactions.slice(0, 250);
    }
    this.state.idempotencyIndex[enriched.idempotencyKey] = enriched.id;

    if (enriched.paymentLinkId) {
      const link = this.state.paymentLinks.find((l) => l.id === enriched.paymentLinkId);
      if (link) {
        link.clicks += 1;
        link.conversions += 1;
        link.totalVolumeUsd = Number((link.totalVolumeUsd + enriched.usdAmount).toFixed(2));
      }
    }

    if (enriched.status === 'settled') {
      this.creditUjrahToTreasury(
        'ujrah_settlement',
        ujrah,
        `Flat Rail Ujrah (${enriched.railName} · ${enriched.reference})`,
        enriched.railName,
        `UJR-${enriched.reference}`
      );
    }

    const webhook = this.pushWebhook('payment.settled', enriched.id, {
      reference: enriched.reference,
      amount: enriched.amount,
      currency: enriched.currency,
      usdAmount: enriched.usdAmount,
      ujrahFeeUsd: ujrah,
      branchId: enriched.branchId,
      railId: enriched.railId,
      status: enriched.status,
    });

    await this.enqueuePersist(`tx:record:${enriched.reference}`);
    return webhook;
  }

  async refundPaymentTransaction(txId: string): Promise<PaymentTransaction | null> {
    const tx = this.state.transactions.find((t) => t.id === txId);
    if (!tx) return null;
    if (tx.status !== 'refunded') {
      tx.status = 'refunded';
      this.pushWebhook('payment.refunded', tx.id, {
        reference: tx.reference,
        refundedUsd: tx.usdAmount,
      });
      await this.enqueuePersist(`tx:refund:${tx.reference}`);
    }
    return tx;
  }

  async redactPaymentPii(txId: string): Promise<PaymentTransaction | null> {
    const tx = this.state.transactions.find((t) => t.id === txId);
    if (!tx) return null;
    tx.customerName = '[REDACTED GDPR]';
    tx.customerEmail = 'redacted@privacy.invalid';
    tx.maskedInstrument = '•••• ••••';
    tx.piiRedacted = true;
    this.pushWebhook('compliance.pii_redacted', tx.id, { transactionId: tx.id });
    await this.enqueuePersist(`gdpr:redact:${tx.reference}`);
    return tx;
  }

  async createPaymentLink(
    input: Omit<
      PaymentLinkRecord,
      'id' | 'slug' | 'active' | 'clicks' | 'conversions' | 'totalVolumeUsd' | 'createdAt'
    >
  ): Promise<PaymentLinkRecord> {
    const slugBase = input.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 32);
    const link: PaymentLinkRecord = {
      ...input,
      id: `lnk_${crypto.randomBytes(4).toString('hex')}`,
      slug: `${slugBase || 'offer'}-${crypto.randomBytes(2).toString('hex')}`,
      active: true,
      clicks: 0,
      conversions: 0,
      totalVolumeUsd: 0,
      createdAt: new Date().toISOString(),
    };
    this.state.paymentLinks.unshift(link);
    await this.enqueuePersist(`link:create:${link.id}`);
    return link;
  }

  async togglePaymentLink(id: string): Promise<PaymentLinkRecord | null> {
    const link = this.state.paymentLinks.find((l) => l.id === id);
    if (!link) return null;
    link.active = !link.active;
    await this.enqueuePersist(`link:toggle:${link.id}`);
    return link;
  }

  // --- Maal-Guard Inventory ---
  async addInventoryItem(
    input: Omit<InventoryItem, 'id' | 'rescuedCount' | 'updatedAt'>
  ): Promise<InventoryItem> {
    const item: InventoryItem = {
      ...input,
      id: `inv_${crypto.randomBytes(4).toString('hex')}`,
      rescuedCount: 0,
      updatedAt: new Date().toISOString(),
    };
    this.state.inventory.unshift(item);
    await this.enqueuePersist(`inventory:add:${item.sku}`);
    return item;
  }

  async adjustInventoryActual(id: string, actualRemainingQty: number): Promise<InventoryItem | null> {
    const item = this.state.inventory.find((i) => i.id === id);
    if (!item) return null;
    item.actualRemainingQty = Math.max(0, actualRemainingQty);
    item.updatedAt = new Date().toISOString();
    await this.enqueuePersist(`inventory:adjust:${item.sku}`);
    return item;
  }

  async triggerInventoryExpiryRescue(id: string): Promise<InventoryItem | null> {
    const item = this.state.inventory.find((i) => i.id === id);
    if (!item) return null;
    item.rescuedCount = (item.rescuedCount || 0) + 1;
    item.updatedAt = new Date().toISOString();

    this.creditUjrahToTreasury(
      'ujrah_expiry_rescue',
      0.3,
      `Maal-Guard B2B 30% Rescue Facilitation (${item.sku})`,
      'Maal-Guard B2B Exchange',
      `UJR-RES-${crypto.randomBytes(2).toString('hex').toUpperCase()}`
    );

    await this.enqueuePersist(`inventory:rescue:${item.sku}`);
    return item;
  }

  // --- Kill Switch & Live Stream ---
  isKillSwitchFrozen(): boolean {
    return this.state.killSwitchFrozen;
  }

  async setKillSwitchFrozen(frozen: boolean): Promise<boolean> {
    this.state.killSwitchFrozen = frozen;
    await this.enqueuePersist(`security:killswitch:${frozen}`);
    return this.state.killSwitchFrozen;
  }

  isLiveStreamEnabled(): boolean {
    return this.state.liveStreamEnabled;
  }

  async setLiveStreamEnabled(enabled: boolean): Promise<boolean> {
    this.state.liveStreamEnabled = enabled;
    await this.enqueuePersist(`stream:toggle:${enabled}`);
    return this.state.liveStreamEnabled;
  }

  private pushWebhook(
    eventType: string,
    transactionId: string,
    data: Record<string, unknown>
  ): WebhookEventRecord {
    const createdAt = new Date().toISOString();
    const payloadJson = JSON.stringify({
      id: `evt_${crypto.randomBytes(5).toString('hex')}`,
      type: eventType,
      createdAt,
      data,
    });
    const wh: WebhookEventRecord = {
      id: `wh_${crypto.randomBytes(5).toString('hex')}`,
      eventType,
      transactionId,
      endpointUrl: 'https://hooks.merchant.internal/veritas',
      signatureHeader: signWebhookPayload(payloadJson),
      payloadJson,
      httpStatus: 200,
      latencyMs: 24 + Math.floor(Math.random() * 32),
      createdAt,
    };
    this.state.webhooks.unshift(wh);
    if (this.state.webhooks.length > 60) {
      this.state.webhooks = this.state.webhooks.slice(0, 60);
    }
    return wh;
  }

  // --- Dynamic Computed Analytics ---
  computeMetrics(): VeritasBootstrapPayload['metrics'] {
    const txs = this.state.transactions;
    const validTxs = txs.filter((t) => t.status !== 'declined' && t.status !== 'refunded');
    const grossVolumeUsd = Number(validTxs.reduce((s, t) => s + t.usdAmount, 0).toFixed(2));
    const netSettledUsd = Number(validTxs.reduce((s, t) => s + t.netUsd, 0).toFixed(2));
    const settledCount = txs.filter((t) => t.status === 'settled').length;
    const declinedCount = txs.filter((t) => t.status === 'declined').length;
    const approvalRatePct = txs.length
      ? Number((((txs.length - declinedCount) / txs.length) * 100).toFixed(1))
      : 100;

    let openReceivablesPkr = 0;
    let openPayablesPkr = 0;
    for (const entry of this.state.ledgerEntries) {
      if (entry.status !== 'open' && entry.status !== 'grace_15d') continue;
      const pkr = convertToPkr(entry.amount, entry.currency);
      if (entry.entryType === 'udhaar_given' || entry.entryType === 'murabaha_contract') {
        openReceivablesPkr += pkr;
      }
      if (entry.entryType === 'udhaar_taken' || entry.entryType === 'salam_contract') {
        openPayablesPkr += pkr;
      }
    }

    let shrinkageLossPkr = 0;
    let expiringSoonCount = 0;
    for (const item of this.state.inventory) {
      const analysis = analyzeInventoryItem(item);
      shrinkageLossPkr += analysis.shrinkageLossPkr;
      if (analysis.expiringSoon) expiringSoonCount += 1;
    }

    const escrowLockedPkr = this.state.mazdoorEscrows
      .filter((e) => e.status === 'locked')
      .reduce((s, e) => s + e.dailyWagePkr, 0);
    const escrowReleasedPkr = this.state.mazdoorEscrows
      .filter((e) => e.status === 'released')
      .reduce((s, e) => s + e.dailyWagePkr, 0);

    const debtCycles = detectDebtCycles(this.state.ledgerEntries);

    return {
      grossVolumeUsd,
      netSettledUsd,
      totalTransactions: txs.length,
      settledCount,
      approvalRatePct,
      openReceivablesPkr,
      openPayablesPkr,
      ledgerBlockCount: this.state.ledgerEntries.length,
      shrinkageLossPkr,
      expiringSoonCount,
      detectedCycleCount: debtCycles.length,
      activeLinksCount: this.state.paymentLinks.filter((l) => l.active).length,
      escrowLockedPkr,
      escrowReleasedPkr,
    };
  }

  computeAmanatPassport(): AmanatPassport {
    const chain = this.verifyHashChain();
    const settledRatio = this.state.ledgerEntries.length
      ? this.state.ledgerEntries.filter(
          (l) => l.status === 'settled' || l.status === 'sadqah_forgiven'
        ).length / this.state.ledgerEntries.length
      : 1;
    const witnessCount = this.state.ledgerEntries.reduce(
      (sum, entry) => sum + (entry.witnesses?.length ?? 0),
      0
    );
    const witnessBoost = Math.min(85, witnessCount * 12);
    const txBoost = Math.min(180, this.state.transactions.length * 14);
    const verifiedChainBonus = chain.intact ? 350 : 0;
    const rawScore = Math.min(
      1000,
      Math.round(300 + verifiedChainBonus + settledRatio * 140 + txBoost + witnessBoost)
    );

    const tier =
      rawScore >= 850
        ? 'Platinum Amanat Crown'
        : rawScore >= 700
          ? 'Gold Siddiq Tier'
          : 'Verified Halal Merchant';

    return {
      score: rawScore,
      tier,
      verifiedChainBonus,
      witnessCount,
      onTimeSettlementRatio: Number((settledRatio * 100).toFixed(1)),
      unlockCreditLimitPkr: rawScore * 2500,
      zeroRibaVerified: chain.intact,
    };
  }

  computeBranches(): BranchSummary[] {
    return (Object.keys(BRANCH_DIRECTORY) as Array<Exclude<BranchId, 'all'>>).map((id) => {
      const meta = BRANCH_DIRECTORY[id];
      const matchingTxs = this.state.transactions.filter(
        (t) => t.branchId === id && t.status !== 'declined'
      );
      const volumeUsd = Number(matchingTxs.reduce((s, t) => s + t.usdAmount, 0).toFixed(2));
      return {
        id,
        name: meta.name,
        city: meta.city,
        country: meta.country,
        txCount: matchingTxs.length,
        volumeUsd,
      };
    });
  }

  buildDeterministicAdvisor(): MizanAdvisorReport {
    const metrics = this.computeMetrics();
    const passport = this.computeAmanatPassport();
    const topOpen = this.state.ledgerEntries.find(
      (e) => e.status === 'open' && e.entryType === 'udhaar_given'
    );
    const debtor = topOpen?.debtorName || 'Bilal Traders';

    return {
      headline: `Amanat ${passport.score}/1000 · ${metrics.detectedCycleCount} Mukasa Loop & ${metrics.expiringSoonCount} Perishable Batches`,
      insightSummary: `Sakrand HQ & GCC hubs show PKR ${metrics.openReceivablesPkr.toLocaleString()} open receivables vs PKR ${metrics.openPayablesPkr.toLocaleString()} payables. Zero-fee Haq-e-Mazdoor vault protects PKR ${metrics.escrowLockedPkr.toLocaleString()}.`,
      urgentAction:
        metrics.detectedCycleCount > 0
          ? 'Run 1-Click Zero-Cash Mukasa Offset in Clearinghouse to settle PKR circular debt immediately.'
          : 'Dispatch polite Quran 2:280 Urdu/Sindhi WhatsApp reminders & activate Maal-Guard B2B rescue.',
      politeReminderUr: `السلام علیکم ${debtor}، بول میزان امانت لیجر کے مطابق آپ کا حساب واجب الادا ہے۔ سہولت کے مطابق راست سے ادائیگی فرما دیں یا قرآن 2:280 کے تحت 15 دن کی مہلت حاصل کریں۔`,
      politeReminderSd: `السلام عليڪم ${debtor}، بول ميزان امانت حساب موجب اوهان جو اوڌار واجب الادا آهي. جيڪڏهن سهولت هجي ته راست ذريعي ادائگي ڪريو، يا قرآن 2:280 تحت 15 ڏينهن جي مهلت وٺو.`,
      generatedBy: 'deterministic-shariah-engine',
      generatedAt: new Date().toISOString(),
    };
  }

  computeVolumeSeries(): VolumeSeriesPoint[] {
    const buckets = 12;
    const now = Date.now();
    const bucketMs = 5 * 60_000;
    const points: VolumeSeriesPoint[] = [];

    for (let i = buckets - 1; i >= 0; i--) {
      const endMs = now - i * bucketMs;
      const startMs = endMs - bucketMs;
      const matchingTxs = this.state.transactions.filter((t) => {
        const ts = Date.parse(t.createdAt);
        return ts >= startMs && ts < endMs && t.status !== 'declined';
      });
      const matchingLedger = this.state.ledgerEntries.filter((l) => {
        const ts = Date.parse(l.createdAt);
        return ts >= startMs && ts < endMs;
      });

      const vol = Number(
        (
          matchingTxs.reduce((s, t) => s + t.usdAmount, 0) +
          matchingLedger.reduce((s, l) => s + l.usdAmount, 0)
        ).toFixed(2)
      );
      const d = new Date(endMs);
      points.push({
        label: `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`,
        timestamp: d.toISOString(),
        volumeUsd: vol,
        txCount: matchingTxs.length + matchingLedger.length,
      });
    }
    return points;
  }

  getSyncSlice(connectedClients: number) {
    return {
      metrics: this.computeMetrics(),
      ledgerEntries: [...this.state.ledgerEntries].sort((a, b) => b.index - a.index),
      chainVerification: this.verifyHashChain(),
      transactions: this.state.transactions.slice(0, 80),
      paymentLinks: this.state.paymentLinks,
      webhooks: this.state.webhooks.slice(0, 30),
      inventory: this.state.inventory,
      debtCycles: detectDebtCycles(this.state.ledgerEntries),
      mazdoorEscrows: this.state.mazdoorEscrows,
      treasury: this.state.treasury,
      amanatPassport: this.computeAmanatPassport(),
      advisorReport: this.buildDeterministicAdvisor(),
      branches: this.computeBranches(),
      volumeSeries: this.computeVolumeSeries(),
      killSwitchFrozen: this.state.killSwitchFrozen,
      liveStreamEnabled: this.state.liveStreamEnabled,
      connectedClients,
    };
  }

  getBootstrapForUser(user: StoredUser, connectedClients: number): VeritasBootstrapPayload {
    return {
      user: this.toPublicUser(user),
      fx: getFxSnapshot(),
      connectors: getConnectorReadiness(),
      ...this.getSyncSlice(connectedClients),
    };
  }

  getExportPackage() {
    return {
      exportedAt: new Date().toISOString(),
      hq: 'BolMizan Global HQ · Sakrand, Sindh, Pakistan',
      founder: 'Mahtab Ali Jamali (mahtabjk123@gmail.com)',
      chainVerification: this.verifyHashChain(),
      ledgerEntries: this.state.ledgerEntries,
      transactions: this.state.transactions,
      mazdoorEscrows: this.state.mazdoorEscrows,
      treasury: this.state.treasury,
      inventory: this.state.inventory,
    };
  }
}

export const walStore = new WalLedgerStore();
