import type {
  DebtCycleResult,
  DebtEdge,
  InventoryItem,
  LedgerEntry,
  ZakatCalculationInput,
  ZakatCalculationOutput,
} from '../shared/types.js';
import { convertToPkr } from './fxEngine.js';

export function detectDebtCycles(entries: LedgerEntry[]): DebtCycleResult[] {
  const openDebts = entries.filter(
    (e) =>
      (e.entryType === 'udhaar_given' || e.entryType === 'udhaar_taken') &&
      (e.status === 'open' || e.status === 'grace_15d')
  );

  // Directed graph: edge A -> B means A owes B
  const edgeMap = new Map<string, DebtEdge>();
  const nodes = new Set<string>();

  for (const entry of openDebts) {
    const pkr = convertToPkr(entry.amount, entry.currency);
    if (pkr <= 0) continue;

    // debtor owes creditor
    const from = entry.debtorName.trim();
    const to = entry.creditorName.trim();
    if (!from || !to || from === to) continue;

    nodes.add(from);
    nodes.add(to);

    const key = `${from}→${to}`;
    const existing = edgeMap.get(key);
    if (existing) {
      existing.amountPkr += pkr;
      existing.entryIds.push(entry.id);
    } else {
      edgeMap.set(key, { from, to, amountPkr: pkr, entryIds: [entry.id] });
    }
  }

  const adjacency = new Map<string, DebtEdge[]>();
  for (const edge of edgeMap.values()) {
    const list = adjacency.get(edge.from) || [];
    list.push(edge);
    adjacency.set(edge.from, list);
  }

  const cycles: DebtCycleResult[] = [];
  const seenSignatures = new Set<string>();
  const sortedNodes = Array.from(nodes).sort();

  function dfs(start: string, current: string, path: string[], edges: DebtEdge[], visited: Set<string>) {
    const outgoing = adjacency.get(current) || [];
    for (const edge of outgoing) {
      if (edge.to === start && path.length >= 2) {
        const cycleEdges = [...edges, edge];
        const minEdge = Math.min(...cycleEdges.map((e) => e.amountPkr));
        if (minEdge > 0) {
          const canonical = [...path].sort().join('|');
          if (!seenSignatures.has(canonical)) {
            seenSignatures.add(canonical);
            cycles.push({
              id: `cyc_${cycles.length + 1}_${canonical.slice(0, 12).replace(/[^a-zA-Z0-9]/g, '')}`,
              participants: [...path, start],
              offsetAmountPkr: Math.round(minEdge),
              edges: cycleEdges,
            });
          }
        }
      } else if (!visited.has(edge.to) && path.length < 5) {
        visited.add(edge.to);
        dfs(start, edge.to, [...path, edge.to], [...edges, edge], visited);
        visited.delete(edge.to);
      }
    }
  }

  for (const startNode of sortedNodes) {
    const visited = new Set<string>([startNode]);
    dfs(startNode, startNode, [startNode], [], visited);
  }

  return cycles;
}

export function analyzeInventoryItem(item: InventoryItem) {
  const expectedRemaining = Math.max(0, item.expectedQty - item.dispatchedQty);
  const missingUnits = Math.max(0, expectedRemaining - item.actualRemainingQty);
  const shrinkageLossPkr = missingUnits * item.unitCostPkr;

  const daysToExpiry = Math.ceil(
    (Date.parse(item.expiryDate) - Date.now()) / 86_400_000
  );
  const expiringSoon = daysToExpiry <= 30;
  const rescuePricePkr = Math.round(item.unitSellPkr * 0.7);
  const totalValueAtRiskPkr = item.actualRemainingQty * item.unitCostPkr;

  const whatsappRescueOffer = `BolMizan Maal-Guard B2B Flash Offer: ${item.actualRemainingQty} units of ${item.name} (${item.sku}) expiring ${item.expiryDate} available at 30% rescue discount — PKR ${rescuePricePkr.toLocaleString()}/unit (Zero-Riba instant Raast/Cash settlement).`;

  return {
    expectedRemaining,
    missingUnits,
    shrinkageLossPkr,
    daysToExpiry,
    expiringSoon,
    rescuePricePkr,
    totalValueAtRiskPkr,
    whatsappRescueOffer,
  };
}

export function calculateAaoifiZakat(input: ZakatCalculationInput): ZakatCalculationOutput {
  const netZakatableAssetsPkr = Math.max(
    0,
    input.cashAndBankPkr +
      input.tradeInventoryPkr +
      input.collectibleReceivablesPkr -
      input.shortTermLiabilitiesPkr
  );

  const nisabMet = netZakatableAssetsPkr >= input.nisabThresholdPkr;
  const zakatRatePct = input.calendarType === 'hijri' ? 2.5 : 2.577;
  const zakatDuePkr = nisabMet
    ? Math.round((netZakatableAssetsPkr * zakatRatePct) / 100)
    : 0;

  const ushrRatePct = input.irrigationType === 'rain_fed' ? 10 : 5;
  const ushrDuePkr = Math.round((Math.max(0, input.agriculturalProducePkr) * ushrRatePct) / 100);

  return {
    netZakatableAssetsPkr,
    nisabMet,
    zakatRatePct,
    zakatDuePkr,
    ushrRatePct,
    ushrDuePkr,
    totalObligationPkr: zakatDuePkr + ushrDuePkr,
  };
}
