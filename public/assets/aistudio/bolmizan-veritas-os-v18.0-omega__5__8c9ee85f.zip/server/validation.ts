import { z } from 'zod';
import type { CurrencyCode, PaymentRailId } from '../shared/types.js';
import { RAIL_BY_ID } from '../shared/rails.js';

export const CURRENCY_ENUM = z.enum([
  'PKR',
  'USD',
  'SAR',
  'AED',
  'EUR',
  'GBP',
  'INR',
  'BRL',
  'CNY',
  'JPY',
  'KES',
]);

export const RAIL_ENUM = z.enum([
  'sbp_raast',
  'jazzcash',
  'easypaisa',
  'onelink_1bill',
  'sadapay_nayapay',
  'saudi_mada',
  'stc_pay',
  'uae_aani',
  'stripe_card',
  'apple_pay',
  'google_pay',
  'paypal',
  'sepa_instant',
  'fednow_ach',
  'uk_faster_payments',
  'india_upi',
  'brazil_pix',
  'wise_corridor',
  'mpesa',
  'usdc_base',
  'alipay_wechat',
]);

export const BRANCH_ENUM = z.enum([
  'sakrand_hq',
  'karachi_port',
  'riyadh_hub',
  'dubai_marina',
]);

export const registerSchema = z.object({
  email: z.string().trim().email().max(120),
  password: z.string().min(8).max(128),
  fullName: z.string().trim().min(2).max(80),
  businessName: z.string().trim().min(2).max(80),
  location: z.string().trim().min(2).max(80).default('Sakrand, Sindh, Pakistan'),
  defaultRole: z
    .enum([
      'founder',
      'merchant',
      'exporter',
      'product_manager',
      'marketer',
      'auditor',
    ])
    .default('merchant'),
});

export const loginSchema = z.object({
  email: z.string().trim().email().max(120),
  password: z.string().min(1).max(128),
});

export const googleAuthSchema = z.object({
  email: z.string().trim().email().max(120),
  fullName: z.string().trim().min(2).max(80),
  businessName: z.string().trim().min(2).max(80).optional(),
  location: z.string().trim().min(2).max(80).optional(),
});

export const whatsappOtpRequestSchema = z.object({
  phone: z.string().trim().min(8).max(22),
});

export const whatsappOtpVerifySchema = z.object({
  phone: z.string().trim().min(8).max(22),
  code: z.string().trim().regex(/^\d{6}$/, 'Enter the 6-digit WhatsApp OTP code.'),
  fullName: z.string().trim().min(2).max(80).optional(),
  businessName: z.string().trim().min(2).max(80).optional(),
  location: z.string().trim().min(2).max(80).optional(),
});

export const phonePinAuthSchema = z.object({
  phone: z.string().trim().min(8).max(22),
  pin: z.string().trim().regex(/^\d{4,8}$/, 'PIN must be 4 to 8 digits.'),
  fullName: z.string().trim().min(2).max(80).optional(),
  businessName: z.string().trim().min(2).max(80).optional(),
  location: z.string().trim().min(2).max(80).optional(),
});

export const ledgerWitnessSchema = z.object({
  witnessName: z.string().trim().min(2).max(80),
  witnessRole: z.string().trim().min(2).max(80).default('Sakrand Otaq Elder / Merchant'),
  otaqLocation: z.string().trim().min(2).max(80).default('Sakrand Bazaar Otaq, Sindh'),
});

export const createLedgerEntrySchema = z.object({
  branchId: BRANCH_ENUM.default('sakrand_hq'),
  entryType: z.enum([
    'udhaar_given',
    'udhaar_taken',
    'cash_sale',
    'payment_received',
    'murabaha_contract',
    'salam_contract',
  ]),
  creditorName: z.string().trim().min(2).max(80),
  debtorName: z.string().trim().min(2).max(80),
  amount: z.number().finite().positive().max(100_000_000),
  currency: CURRENCY_ENUM,
  costBasisUsd: z.number().nonnegative().optional(),
  murabahaMarkupUsd: z.number().nonnegative().optional(),
  itemsSummary: z.string().trim().min(2).max(200),
  dueDate: z.string().trim().max(40).nullable().optional(),
  language: z.enum(['en', 'ur', 'sd', 'ar']).default('en'),
  voiceTranscript: z.string().trim().max(400).nullable().optional(),
  signatureDataUrl: z.string().max(150_000).nullable().optional(),
  cognitiveHumanScore: z.number().min(0).max(100).default(92),
  interestRate: z.number().optional(),
  lateFee: z.number().optional(),
  ribaMultiplier: z.number().optional(),
});

export const checkoutRequestSchema = z.object({
  branchId: BRANCH_ENUM.default('sakrand_hq'),
  amount: z.number().finite().positive().max(10_000_000),
  currency: CURRENCY_ENUM,
  railId: RAIL_ENUM,
  instrumentInput: z.string().trim().min(3).max(128),
  customerName: z.string().trim().min(2).max(80),
  customerEmail: z.string().trim().email().max(120),
  customerCountry: z.string().trim().min(2).max(60),
  paymentLinkId: z.string().trim().max(64).nullable().optional(),
  utmSource: z.string().trim().max(64).nullable().optional(),
  utmCampaign: z.string().trim().max(64).nullable().optional(),
  creatorHandle: z.string().trim().max(64).nullable().optional(),
  interestRate: z.number().optional(),
  lateFee: z.number().optional(),
});

export const createLinkSchema = z.object({
  title: z.string().trim().min(3).max(80),
  description: z.string().trim().min(3).max(200),
  amount: z.number().finite().positive().max(5_000_000),
  currency: CURRENCY_ENUM,
  allowedCategories: z
    .array(
      z.enum([
        'Pakistan & MENA',
        'Global Cards & Wallets',
        'International Bank Rails',
        'Web3 & APAC',
      ])
    )
    .min(1),
  utmSource: z.string().trim().max(64).default('direct'),
  utmCampaign: z.string().trim().max(64).default('veritas_launch'),
  creatorHandle: z.string().trim().max(64).default('@bolmizan_hq'),
});

export const createInventorySchema = z.object({
  branchId: BRANCH_ENUM.default('sakrand_hq'),
  sku: z.string().trim().min(2).max(32),
  name: z.string().trim().min(2).max(80),
  category: z.string().trim().min(2).max(40),
  expectedQty: z.number().int().nonnegative(),
  dispatchedQty: z.number().int().nonnegative(),
  actualRemainingQty: z.number().int().nonnegative(),
  unitCostPkr: z.number().positive(),
  unitSellPkr: z.number().positive(),
  expiryDate: z.string().trim().min(8).max(30),
});

export const createEscrowSchema = z.object({
  workerName: z.string().trim().min(2).max(80),
  workerPhone: z.string().trim().min(10).max(20),
  employerName: z.string().trim().min(2).max(80),
  workDescription: z.string().trim().min(3).max(160),
  dailyWagePkr: z.number().finite().positive().max(1_000_000),
  payoutRail: z.enum(['sbp_raast', 'jazzcash', 'easypaisa']).default('sbp_raast'),
  branchId: BRANCH_ENUM.default('sakrand_hq'),
  language: z.enum(['en', 'ur', 'sd', 'ar']).default('sd'),
});

export const saasUpgradeSchema = z.object({
  tierId: z.enum(['mazdoor_free', 'pro_trader', 'enterprise_exporter']),
  railId: RAIL_ENUM.default('sbp_raast'),
});

export const founderWithdrawSchema = z.object({
  amountUsd: z.number().finite().positive().max(10_000_000),
  railId: z.enum(['sbp_raast', 'jazzcash', 'wise_corridor', 'stripe_card', 'usdc_base']),
  destinationInput: z.string().trim().min(4).max(128),
  pin: z.string().trim().min(4).max(12),
});

export function assertZeroRibaCompliant(payload: {
  interestRate?: number;
  lateFee?: number;
  ribaMultiplier?: number;
  itemsSummary?: string;
}): { ok: boolean; reason?: string } {
  if ((payload.interestRate ?? 0) > 0 || (payload.lateFee ?? 0) > 0 || (payload.ribaMultiplier ?? 0) > 0) {
    return {
      ok: false,
      reason: 'Zero-Riba Shariah Gate: Interest rates, late penalties, and compounding riba fees are strictly prohibited.',
    };
  }
  const text = (payload.itemsSummary || '').toLowerCase();
  if (/\b(riba|interest\s*fee|late\s*penalty|usury|sood|سود)\b/i.test(text)) {
    return {
      ok: false,
      reason: 'Zero-Riba Shariah Gate: Transaction description contains prohibited riba/interest penalty wording.',
    };
  }
  return { ok: true };
}

export function passesLuhnCheck(rawDigits: string): boolean {
  const digits = rawDigits.replace(/[\s-]/g, '');
  if (!/^\d{13,19}$/.test(digits)) return false;
  let sum = 0;
  let shouldDouble = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  return sum % 10 === 0;
}

export function passesIbanMod97(rawIban: string): boolean {
  const iban = rawIban.replace(/\s+/g, '').toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(iban)) return false;
  const rearranged = iban.slice(4) + iban.slice(0, 4);
  let numericStr = '';
  for (const ch of rearranged) {
    const code = ch.charCodeAt(0);
    numericStr += code >= 65 && code <= 90 ? String(code - 55) : ch;
  }
  let remainder = 0;
  for (let i = 0; i < numericStr.length; i++) {
    remainder = (remainder * 10 + Number(numericStr[i])) % 97;
  }
  return remainder === 1;
}

export function passesAbaRoutingChecksum(routingAndAccount: string): boolean {
  const parts = routingAndAccount.split(':').map((s) => s.trim());
  if (parts.length !== 2) return false;
  const [routing, account] = parts;
  if (!/^\d{9}$/.test(routing) || !/^\d{4,17}$/.test(account)) return false;
  const d = routing.split('').map(Number);
  const checksum =
    3 * (d[0] + d[3] + d[6]) + 7 * (d[1] + d[4] + d[7]) + (d[2] + d[5] + d[8]);
  return checksum % 10 === 0;
}

export function validateRailInstrument(
  railId: PaymentRailId,
  currency: CurrencyCode,
  input: string
): { valid: boolean; reason?: string; masked: string } {
  const rail = RAIL_BY_ID[railId];
  if (!rail) {
    return { valid: false, reason: 'Unsupported payment rail.', masked: '****' };
  }
  if (!rail.currencies.includes(currency)) {
    return {
      valid: false,
      reason: `${rail.shortName} supports ${rail.currencies.join(', ')}, not ${currency}.`,
      masked: '****',
    };
  }

  const trimmed = input.trim();

  switch (railId) {
    case 'stripe_card':
    case 'saudi_mada': {
      const digits = trimmed.replace(/[\s-]/g, '');
      if (!passesLuhnCheck(digits)) {
        return {
          valid: false,
          reason: 'Card number failed Luhn checksum validation (try 4242 4242 4242 4242).',
          masked: '****',
        };
      }
      return { valid: true, masked: `•••• ${digits.slice(-4)}` };
    }
    case 'sbp_raast':
    case 'sadapay_nayapay': {
      const clean = trimmed.replace(/[\s-]/g, '').toUpperCase();
      if (/^PK\d{2}[A-Z0-9]{20}$/.test(clean) && passesIbanMod97(clean)) {
        return { valid: true, masked: `${clean.slice(0, 4)} •••• ${clean.slice(-4)}` };
      }
      if (/^(\+92|0)3\d{9}$/.test(clean)) {
        return { valid: true, masked: `${clean.slice(0, 4)}••••${clean.slice(-3)}` };
      }
      return {
        valid: false,
        reason: 'Enter valid 24-char PK IBAN (Mod-97) or 03XXXXXXXXX mobile Raast ID.',
        masked: 'Raast',
      };
    }
    case 'jazzcash':
    case 'easypaisa': {
      const digits = trimmed.replace(/[\s-]/g, '');
      if (!/^(\+92|0)3\d{9}$/.test(digits)) {
        return {
          valid: false,
          reason: 'Invalid Pakistan mobile wallet MSISDN (expected 03XXXXXXXXX).',
          masked: 'PKR Wallet',
        };
      }
      return { valid: true, masked: `${digits.slice(0, 4)}••••${digits.slice(-3)}` };
    }
    case 'onelink_1bill': {
      const digits = trimmed.replace(/\s+/g, '');
      if (!/^\d{14,20}$/.test(digits)) {
        return {
          valid: false,
          reason: '1LINK 1BILL voucher must be 14–20 numeric digits.',
          masked: '1BILL',
        };
      }
      return { valid: true, masked: `1BILL ••••${digits.slice(-4)}` };
    }
    case 'stc_pay': {
      const digits = trimmed.replace(/[\s-]/g, '');
      if (!/^(\+966|0)5\d{8}$/.test(digits)) {
        return {
          valid: false,
          reason: 'Invalid Saudi STC Pay mobile (+9665XXXXXXXX or 05XXXXXXXX).',
          masked: 'STC',
        };
      }
      return { valid: true, masked: `${digits.slice(0, 6)}•••${digits.slice(-3)}` };
    }
    case 'uae_aani': {
      const clean = trimmed.replace(/[\s-]/g, '').toUpperCase();
      if (/^AE\d{21}$/.test(clean) && passesIbanMod97(clean)) {
        return { valid: true, masked: `${clean.slice(0, 4)} •••• ${clean.slice(-4)}` };
      }
      if (/^(\+971|0)5\d{8}$/.test(clean)) {
        return { valid: true, masked: `${clean.slice(0, 6)}•••${clean.slice(-3)}` };
      }
      return {
        valid: false,
        reason: 'Enter valid UAE mobile (+9715XXXXXXXX) or AE IBAN.',
        masked: 'Aani',
      };
    }
    case 'sepa_instant': {
      const clean = trimmed.replace(/\s+/g, '').toUpperCase();
      if (!passesIbanMod97(clean)) {
        return {
          valid: false,
          reason: 'Invalid European IBAN (Mod-97 checksum failed; e.g. DE89370400440532013000).',
          masked: 'IBAN',
        };
      }
      return { valid: true, masked: `${clean.slice(0, 4)} •••• ${clean.slice(-4)}` };
    }
    case 'fednow_ach': {
      if (!passesAbaRoutingChecksum(trimmed)) {
        return {
          valid: false,
          reason: 'Invalid ABA routing:account format (e.g. 021000021:984002145).',
          masked: 'ACH',
        };
      }
      const [routing, acct] = trimmed.split(':').map((s) => s.trim());
      return { valid: true, masked: `ABA ${routing.slice(0, 4)}•••• / ••${acct.slice(-4)}` };
    }
    case 'uk_faster_payments': {
      const match = /^(\d{2}-?\d{2}-?\d{2}):(\d{8})$/.exec(trimmed);
      if (!match) {
        return {
          valid: false,
          reason: 'Invalid UK Faster Payments format (expected XX-XX-XX:12345678).',
          masked: 'FPS',
        };
      }
      return { valid: true, masked: `${match[1]} / ••••${match[2].slice(-4)}` };
    }
    case 'india_upi': {
      if (!/^[a-zA-Z0-9._-]{2,64}@[a-zA-Z0-9]{2,32}$/.test(trimmed)) {
        return {
          valid: false,
          reason: 'Invalid UPI VPA format (expected handle@bank).',
          masked: 'UPI',
        };
      }
      const [user, bank] = trimmed.split('@');
      return { valid: true, masked: `${user.slice(0, 2)}•••@${bank}` };
    }
    case 'mpesa': {
      const digits = trimmed.replace(/[\s-]/g, '');
      if (!/^(\+254|0)[17]\d{8}$/.test(digits)) {
        return {
          valid: false,
          reason: 'Invalid Kenya M-Pesa phone (+2547XXXXXXXX).',
          masked: 'M-Pesa',
        };
      }
      return { valid: true, masked: `${digits.slice(0, 6)}•••${digits.slice(-3)}` };
    }
    case 'usdc_base': {
      if (!/^0x[a-fA-F0-9]{40}$/.test(trimmed)) {
        return {
          valid: false,
          reason: 'Invalid EVM wallet address (expected 42-char 0x hex string).',
          masked: '0x...',
        };
      }
      return { valid: true, masked: `${trimmed.slice(0, 6)}•••${trimmed.slice(-4)}` };
    }
    case 'paypal': {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
        return { valid: false, reason: 'Please enter a valid PayPal email.', masked: 'Email' };
      }
      const [name, domain] = trimmed.split('@');
      return { valid: true, masked: `${name.slice(0, 2)}•••@${domain}` };
    }
    default:
      return { valid: true, masked: `${trimmed.slice(0, 5)}•••${trimmed.slice(-3)}` };
  }
}
