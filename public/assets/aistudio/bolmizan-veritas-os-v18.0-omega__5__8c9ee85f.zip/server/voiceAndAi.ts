import { GoogleGenAI, Type } from '@google/genai';
import type {
  CurrencyCode,
  LedgerEntryType,
  ScamAnalysisResult,
  UiLanguage,
  VoiceParseResult,
} from '../shared/types.js';

const geminiKey = process.env.GEMINI_API_KEY?.trim() || '';
const hasGeminiKey = Boolean(geminiKey && geminiKey !== 'MY_GEMINI_API_KEY');

const ai = hasGeminiKey
  ? new GoogleGenAI({
      apiKey: geminiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

function normalizeIndicDigits(input: string): string {
  const urduDigits = '۰۱۲۳۴۵۶۷۸۹';
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  return input.replace(/[۰-۹٠-٩]/g, (ch) => {
    const uIdx = urduDigits.indexOf(ch);
    if (uIdx >= 0) return String(uIdx);
    const aIdx = arabicDigits.indexOf(ch);
    if (aIdx >= 0) return String(aIdx);
    return ch;
  });
}

function detectLanguage(text: string): UiLanguage {
  if (/[\u067B\u067D\u0680\u0683\u0684\u068A\u068D\u068F\u0699\u06B3\u06B5\u06BB\u06FE]/.test(text)) {
    return 'sd';
  }
  if (/[\u0679\u067E\u0686\u0688\u0691\u0698\u06BA\u06C1\u06D2]/.test(text)) {
    return 'ur';
  }
  if (/[\u0600-\u06FF]/.test(text)) {
    return 'ar';
  }
  return 'en';
}

export interface ParseVoiceInput {
  transcript?: string;
  audioBase64?: string;
  mimeType?: string;
  languageHint?: UiLanguage;
}

const OFFLINE_AUDIO_DEFAULTS: Record<
  UiLanguage,
  { transcript: string; customerName: string; itemsSummary: string; currency: CurrencyCode; amount: number }
> = {
  ur: {
    transcript: 'محمد علی کو 5,000 روپے راشن اور آٹا ادھار دیا (وائس نوٹ ڈرافٹ)',
    customerName: 'محمد علی',
    itemsSummary: 'راشن اور آٹا — وائس نوٹ اندراج',
    currency: 'PKR',
    amount: 5000,
  },
  sd: {
    transcript: 'محبوب علي کي 5,000 روپيا راشن جو اڌار ڏنو (وائس نوٽ مسودو)',
    customerName: 'محبوب علي',
    itemsSummary: 'راشن ۽ اناج — وائس نوٽ',
    currency: 'PKR',
    amount: 5000,
  },
  ar: {
    transcript: 'محمد عبد الله — 500 ريال تمور ومواد غذائية بالآجل (مسودة صوتية)',
    customerName: 'محمد عبد الله',
    itemsSummary: 'تمور ومواد غذائية — تسجيل صوتي',
    currency: 'SAR',
    amount: 500,
  },
  en: {
    transcript: 'Counter voice note draft — review customer, amount, and goods before sealing',
    customerName: 'Muhammad Ali',
    itemsSummary: 'Trade goods & supplies (voice recording)',
    currency: 'PKR',
    amount: 5000,
  },
};

export function offlineParseVoiceToHisab(
  transcript: string,
  languageHint: UiLanguage = 'en'
): VoiceParseResult {
  const trimmed = transcript.trim();
  if (!trimmed) {
    const preset = OFFLINE_AUDIO_DEFAULTS[languageHint] ?? OFFLINE_AUDIO_DEFAULTS.en;
    const dueDt = new Date(Date.now() + 15 * 86400_000).toISOString().slice(0, 10);
    return {
      transcript: preset.transcript,
      customerName: preset.customerName,
      amount: preset.amount,
      currency: preset.currency,
      entryType: 'udhaar_given',
      itemsSummary: preset.itemsSummary,
      dueDate: dueDt,
      languageDetected: languageHint,
      parserEngine: 'offline-utf8-regex',
    };
  }

  const normalized = normalizeIndicDigits(trimmed);
  const languageDetected = detectLanguage(normalized);

  // Extract currency
  let currency: CurrencyCode = 'PKR';
  if (/\b(usd|dollar|dollars|\$)\b/i.test(normalized)) currency = 'USD';
  else if (/\b(sar|riyal|riyals|ريال)\b/i.test(normalized)) currency = 'SAR';
  else if (/\b(aed|dirham|درهم)\b/i.test(normalized)) currency = 'AED';
  else if (/\b(eur|euro|€)\b/i.test(normalized)) currency = 'EUR';
  else if (/\b(gbp|pound|£)\b/i.test(normalized)) currency = 'GBP';
  else if (/\b(inr|₹)\b/i.test(normalized)) currency = 'INR';

  // Extract amount
  const numMatches = normalized.match(/\d[\d,]*(?:\.\d+)?/g);
  const amount = numMatches
    ? Number(numMatches[0].replace(/,/g, '')) || 1000
    : 1000;

  // Determine entry type across Urdu, Sindhi, Arabic, and English
  let entryType: LedgerEntryType = 'udhaar_given';
  if (/(wapas|wasool|received|paid|milyo|مليا|وصول|استلم|دفع|نقد\s*آیا)/i.test(normalized)) {
    entryType = 'payment_received';
  } else if (/(cash\s*sale|naqad|نقد|نقدو|كاش)/i.test(normalized)) {
    entryType = 'cash_sale';
  } else if (/(liya|borrowed|payable|اوڌارو\s*ورتو|ادھار\s*لیا|استدان)/i.test(normalized)) {
    entryType = 'udhaar_taken';
  } else if (/(udhaar|udhar|ادھار|ادھارو|اوڌارو|دين|credit|diya)/i.test(normalized)) {
    entryType = 'udhaar_given';
  }

  // Extract customer name cleanly (Unicode-safe postposition boundaries)
  let customerName = 'Walk-in Counter Customer';
  const toMatch = normalized.match(
    /^([A-Za-z\u0600-\u06FF\s]{2,36}?)\s+(?:ko|to|se|sy|کي|کان|کو|إلى|من)(?=\s|$)/i
  );
  const fromMatch = normalized.match(
    /(?:^|\s)(?:from|to|customer|naam|نام|نالو|على)\s+([A-Za-z\u0600-\u06FF\s]{2,32})/i
  );
  if (toMatch?.[1]) {
    customerName = toMatch[1].trim();
  } else if (fromMatch?.[1]) {
    customerName = fromMatch[1].trim();
  } else {
    const words = normalized.replace(/\d[\d,]*(?:\.\d+)?/g, '').trim().split(/\s+/).slice(0, 2);
    if (words.length >= 1 && words[0].length >= 2) {
      customerName = words.join(' ');
    }
  }

  // Extract items summary
  const stripped = normalized
    .replace(customerName, '')
    .replace(
      /(?:^|\s)(?:ko|ka|ki|ke|diya|liya|udhaar|udhar|rupees|pkr|usd|sar|aed|کو|کا|کی|روپے|ادھار|دیا|اوڌارو|اوڌار|ڏنو|کي|روپيا)(?=\s|$)/gi,
      ' '
    )
    .replace(/\d[\d,]*(?:\.\d+)?/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  const itemsSummary = stripped.length >= 3 ? stripped : 'General trade goods & supplies';

  let dueDate: string | null = null;
  if (entryType === 'udhaar_given' || entryType === 'udhaar_taken') {
    const dt = new Date(Date.now() + 15 * 86400_000);
    dueDate = dt.toISOString().slice(0, 10);
  }

  return {
    transcript: trimmed,
    customerName,
    amount,
    currency,
    entryType,
    itemsSummary,
    dueDate,
    languageDetected,
    parserEngine: 'offline-utf8-regex',
  };
}

export async function parseVoiceToHisab(
  input: string | ParseVoiceInput
): Promise<VoiceParseResult> {
  const normalizedInput: ParseVoiceInput =
    typeof input === 'string' ? { transcript: input } : input;

  const transcript = (normalizedInput.transcript || '').trim();
  const languageHint: UiLanguage = normalizedInput.languageHint || 'en';
  const rawAudio = (normalizedInput.audioBase64 || '').trim();
  const cleanAudioBase64 = rawAudio.replace(/^data:[^;]+;base64,/, '');
  const cleanMimeType =
    (normalizedInput.mimeType || 'audio/webm').split(';')[0].trim() || 'audio/webm';

  if (!ai) {
    return offlineParseVoiceToHisab(transcript, languageHint);
  }

  try {
    const parts: Array<
      { inlineData: { mimeType: string; data: string } } | { text: string }
    > = [];

    if (cleanAudioBase64) {
      parts.push({
        inlineData: {
          mimeType: cleanMimeType,
          data: cleanAudioBase64,
        },
      });
    }

    parts.push({
      text: cleanAudioBase64
        ? `Listen carefully to this merchant audio recording (UI language hint: ${languageHint}${transcript ? `, supplementary note: "${transcript}"` : ''}). Transcribe what was spoken verbatim into "transcript" preserving original Urdu (اردو), Sindhi (سنڌي), Arabic (العربية), or English UTF-8 script, and extract the structured Shariah trade ledger details.`
        : `Extract structured Shariah trade ledger details from this multilingual merchant voice/text note (Urdu, Sindhi, Arabic, or English): "${transcript}"`,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: { parts },
      config: {
        systemInstruction:
          'You parse Pakistani, Arab, and global merchant voice recordings and bookkeeping notes into structured JSON. Preserve original customer names cleanly in UTF-8. Map credit given to udhaar_given, credit borrowed to udhaar_taken, cash sales to cash_sale, repayments to payment_received, Murabaha trade to murabaha_contract, and Salam forward agricultural purchases to salam_contract. Default currency to PKR if unspecified.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            transcript: { type: Type.STRING },
            customerName: { type: Type.STRING },
            amount: { type: Type.NUMBER },
            currency: {
              type: Type.STRING,
              description: 'One of PKR, USD, SAR, AED, EUR, GBP, INR, BRL, CNY, JPY, KES',
            },
            entryType: {
              type: Type.STRING,
              description:
                'One of udhaar_given, udhaar_taken, cash_sale, payment_received, murabaha_contract, salam_contract',
            },
            itemsSummary: { type: Type.STRING },
            dueDate: { type: Type.STRING, nullable: true },
            languageDetected: { type: Type.STRING, description: 'One of en, ur, sd, ar' },
          },
          required: [
            'transcript',
            'customerName',
            'amount',
            'currency',
            'entryType',
            'itemsSummary',
            'languageDetected',
          ],
        },
      },
    });

    const raw = (response.text ?? '').trim();
    const parsed = JSON.parse(raw) as Partial<VoiceParseResult>;
    const validCurrencies = new Set<CurrencyCode>([
      'PKR',
      'USD',
      'SAR',
      'AED',
      'EUR',
      'GBP',
      'INR',
      'BRL',
      'CNY',
      'JPY',
      'KES',
    ]);
    const validTypes = new Set<LedgerEntryType>([
      'udhaar_given',
      'udhaar_taken',
      'cash_sale',
      'payment_received',
      'murabaha_contract',
      'salam_contract',
    ]);
    const validLangs = new Set<UiLanguage>(['en', 'ur', 'sd', 'ar']);
    const resolvedTranscript = (parsed.transcript || transcript || '').trim();

    return {
      transcript: resolvedTranscript,
      customerName: parsed.customerName?.trim() || 'Counter Customer',
      amount: typeof parsed.amount === 'number' && parsed.amount > 0 ? parsed.amount : 1000,
      currency: validCurrencies.has(parsed.currency as CurrencyCode)
        ? (parsed.currency as CurrencyCode)
        : 'PKR',
      entryType: validTypes.has(parsed.entryType as LedgerEntryType)
        ? (parsed.entryType as LedgerEntryType)
        : 'udhaar_given',
      itemsSummary:
        parsed.itemsSummary?.trim() ||
        resolvedTranscript.slice(0, 80) ||
        'Trade goods & supplies',
      dueDate: parsed.dueDate || null,
      languageDetected: validLangs.has(parsed.languageDetected as UiLanguage)
        ? (parsed.languageDetected as UiLanguage)
        : resolvedTranscript
          ? detectLanguage(resolvedTranscript)
          : languageHint,
      parserEngine: 'gemini-4-hydrogen',
    };
  } catch {
    return offlineParseVoiceToHisab(transcript, languageHint);
  }
}

export function analyzeScamMessage(message: string): ScamAnalysisResult {
  const clean = normalizeIndicDigits(message.trim());
  const detectedLanguage = detectLanguage(clean);
  const matchedSignals: string[] = [];
  let score = 0;

  const patterns: Array<{ regex: RegExp; weight: number; label: string }> = [
    {
      regex: /\b(otp|pin|mpin|cvv|passcode)\b|او\s*ٹی\s*پی|پن\s*کوڈ|خفیہ\s*کوڈ|پاسورڊ|او\s*ٽي\s*پي/i,
      weight: 42,
      label: 'OTP / Secret PIN harvesting request',
    },
    {
      regex: /(bisp|ehsaas|8171|benazir|بینظیر|احساس\s*پروگرام|امداد|بينظير\s*انڪم)/i,
      weight: 35,
      label: 'Fake BISP / Ehsaas 8171 relief impersonation',
    },
    {
      regex: /(lottery|prize|jeeto|winner|انعام|لاٹری|نڪتو\s*آهي|مبارک|جيتيا|جائزہ|فائز)/i,
      weight: 32,
      label: 'Fraudulent lottery / prize claim lure',
    },
    {
      regex: /(account\s*block|suspended|kyc\s*expire|اکاؤنٹ\s*بند|بلاڪ|تصدیق\s*کریں|fbr|sbp|raast\s*verify|حساب\s*معلق)/i,
      weight: 35,
      label: 'Fake bank / SBP / FBR account suspension threat',
    },
    {
      regex: /(https?:\/\/(?![a-z0-9-]+\.(gov\.pk|sbp\.org\.pk))[^\s]+|bit\.ly|tinyurl)/i,
      weight: 28,
      label: 'Unverified shortened or external phishing URL',
    },
    {
      regex: /(jazzcash\s*agent|easypaisa\s*helpline|03\d{9}.*send\s*fee|فیس\s*بھیجیں|چارجز\s*جمع)/i,
      weight: 30,
      label: 'Advance-fee wallet transfer demand',
    },
  ];

  for (const rule of patterns) {
    if (rule.regex.test(clean)) {
      score += rule.weight;
      matchedSignals.push(rule.label);
    }
  }

  const riskScore = Math.min(100, score);
  const verdict: ScamAnalysisResult['verdict'] =
    riskScore >= 55 ? 'high_risk_scam' : riskScore >= 25 ? 'suspicious' : 'safe';

  const advisoryEn =
    verdict === 'high_risk_scam'
      ? 'HIGH RISK SCAM DETECTED: Never share your OTP, MPIN, or pay release fees. Official SBP Raast, BISP (8171 only), and banks never ask for PIN codes.'
      : verdict === 'suspicious'
        ? 'SUSPICIOUS MESSAGE: Verify directly via official bank helpline before clicking links or transferring funds.'
        : 'NO KNOWN PHISHING PATTERNS DETECTED: Always verify sender identity before sending funds.';

  const advisoryUr =
    verdict === 'high_risk_scam'
      ? 'خبردار! یہ خطرناک فراڈ پیغام ہے۔ اپنا OTP، پن کوڈ یا کوئی فیس ہرگز نہ بھیجیں۔ بینک اور 8171 کبھی خفیہ کوڈ نہیں مانگتے۔'
      : verdict === 'suspicious'
        ? 'مشتبہ پیغام: کسی بھی لنک پر کلک کرنے یا رقم بھیجنے سے پہلے بینک کی آفیشل ہیلپ لائن سے تصدیق کریں۔'
        : 'کوئی معروف فراڈ علامت نہیں ملی، تاہم رقم بھیجنے سے پہلے وصول کنندہ کی تصدیق ضرور کریں۔';

  return {
    verdict,
    riskScore,
    detectedLanguage,
    matchedSignals,
    advisoryEn,
    advisoryUr,
  };
}

export async function generateMizanAdvisorReport(context: {
  openReceivablesPkr: number;
  openPayablesPkr: number;
  detectedCycleCount: number;
  expiringSoonCount: number;
  escrowLockedPkr: number;
  amanatScore: number;
  topDebtorName: string;
}): Promise<{
  headline: string;
  insightSummary: string;
  urgentAction: string;
  politeReminderUr: string;
  politeReminderSd: string;
  generatedBy: 'gemini-4-hydrogen' | 'deterministic-shariah-engine';
  generatedAt: string;
}> {
  const fallback = {
    headline: `Amanat ${context.amanatScore}/1000 · ${context.detectedCycleCount} Mukasa Loop & ${context.expiringSoonCount} Expiry Windows Ready`,
    insightSummary: `You hold PKR ${context.openReceivablesPkr.toLocaleString()} in open Shariah receivables vs PKR ${context.openPayablesPkr.toLocaleString()} payables, plus PKR ${context.escrowLockedPkr.toLocaleString()} protected in Haq-e-Mazdoor wage vaults.`,
    urgentAction:
      context.detectedCycleCount > 0
        ? 'Execute 1-click Zero-Cash Mukasa Cycle Offset to liberate working capital without touching bank liquidity.'
        : context.expiringSoonCount > 0
          ? 'Trigger Maal-Guard 30% B2B Flash Rescue on perishable batches to convert impending loss into Halal cash.'
          : `Send gentle Quran 2:280 reminder to ${context.topDebtorName} with optional 15-day empathy grace.`,
    politeReminderUr: `السلام علیکم ${context.topDebtorName} صاحب، امید ہے آپ خیریت سے ہوں گے۔ بول میزان لیجر کے مطابق آپ کا ادھار حساب واجب الادا ہے؛ اگر سہولت ہو تو راست/کیش سے ادائیگی فرما دیں، ورنہ قرآن 2:280 کے تحت 15 دن کی مہلت حاضر ہے۔ جزاک اللہ۔`,
    politeReminderSd: `السلام عليڪم ${context.topDebtorName} صاحب، اميد آهي اوهان خيريت سان هوندا. بول ميزان حساب موجب اوهان جو اوڌار واجب الادا آهي؛ جيڪڏهن سهولت هجي ته راست ذريعي موڪليو، نه ته قرآن 2:280 موجب 15 ڏينهن جي مهلت موجود آهي.`,
    generatedBy: 'deterministic-shariah-engine' as const,
    generatedAt: new Date().toISOString(),
  };

  if (!ai) {
    return fallback;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Analyze this live merchant state for BolMizan VERITAS OS (Sakrand, Sindh HQ): Open Receivables PKR ${context.openReceivablesPkr}, Payables PKR ${context.openPayablesPkr}, Mukasa Cycles ${context.detectedCycleCount}, Expiring Batches ${context.expiringSoonCount}, Mazdoor Escrow PKR ${context.escrowLockedPkr}, Amanat Score ${context.amanatScore}/1000, Primary Debtor ${context.topDebtorName}.`,
      config: {
        systemInstruction:
          'You are Mizan-Advisor, a Shariah FinTech strategist. Return concise actionable strategy plus dignified, empathetic Quran 2:280 payment reminders in pure UTF-8 Urdu and Sindhi scripts.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            headline: { type: Type.STRING },
            insightSummary: { type: Type.STRING },
            urgentAction: { type: Type.STRING },
            politeReminderUr: { type: Type.STRING },
            politeReminderSd: { type: Type.STRING },
          },
          required: [
            'headline',
            'insightSummary',
            'urgentAction',
            'politeReminderUr',
            'politeReminderSd',
          ],
        },
      },
    });
    const parsed = JSON.parse((response.text ?? '').trim()) as Partial<typeof fallback>;
    return {
      headline: parsed.headline || fallback.headline,
      insightSummary: parsed.insightSummary || fallback.insightSummary,
      urgentAction: parsed.urgentAction || fallback.urgentAction,
      politeReminderUr: parsed.politeReminderUr || fallback.politeReminderUr,
      politeReminderSd: parsed.politeReminderSd || fallback.politeReminderSd,
      generatedBy: 'gemini-4-hydrogen',
      generatedAt: new Date().toISOString(),
    };
  } catch {
    return fallback;
  }
}

