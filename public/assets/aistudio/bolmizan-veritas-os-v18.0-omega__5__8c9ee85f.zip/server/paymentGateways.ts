import crypto from 'node:crypto';
import Stripe from 'stripe';
import type { CurrencyCode, PaymentRailId } from '../shared/types.js';
import { RAIL_BY_ID } from '../shared/rails.js';
import { convertToUsd } from './fxEngine.js';
import { buildSbpRaastEmvQr, buildZatcaPhase2TlvBase64 } from './qrAndProtocols.js';

const stripeKey = process.env.STRIPE_SECRET_KEY?.trim() || '';
const paypalClientId = process.env.PAYPAL_CLIENT_ID?.trim() || '';
const paypalClientSecret = process.env.PAYPAL_CLIENT_SECRET?.trim() || '';
const webhookSecret =
  process.env.VERITAS_WEBHOOK_SECRET?.trim() || 'whsec_veritas_dev_change_in_prod';

const stripeClient = stripeKey ? new Stripe(stripeKey) : null;

export function getConnectorReadiness() {
  return {
    stripeConfigured: Boolean(stripeClient),
    paypalConfigured: Boolean(paypalClientId && paypalClientSecret),
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY?.trim() && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'),
  };
}

export function signWebhookPayload(payloadJson: string): string {
  const timestamp = Math.floor(Date.now() / 1000);
  const signedBody = `${timestamp}.${payloadJson}`;
  const hmac = crypto.createHmac('sha256', webhookSecret).update(signedBody).digest('hex');
  return `t=${timestamp},v1=${hmac}`;
}

export function verifyWebhookSignature(payloadJson: string, signatureHeader: string): boolean {
  const parts = Object.fromEntries(
    signatureHeader.split(',').map((item) => {
      const idx = item.indexOf('=');
      return idx > 0 ? [item.slice(0, idx).trim(), item.slice(idx + 1).trim()] : ['', ''];
    })
  );
  const timestamp = parts.t;
  const providedSig = parts.v1;
  if (!timestamp || !providedSig || !/^[a-f0-9]{64}$/i.test(providedSig)) {
    return false;
  }

  const expectedHex = crypto
    .createHmac('sha256', webhookSecret)
    .update(`${timestamp}.${payloadJson}`)
    .digest('hex');

  const expectedBuf = Buffer.from(expectedHex, 'hex');
  const providedBuf = Buffer.from(providedSig, 'hex');
  if (expectedBuf.length !== providedBuf.length) return false;
  return crypto.timingSafeEqual(expectedBuf, providedBuf);
}

export interface GatewayExecutionResult {
  connectorMode: 'stripe_live' | 'paypal_live' | 'sandbox_clearing';
  gatewayIntentId: string;
  status: 'settled' | 'processing';
  usdAmount: number;
  feeUsd: number;
  netUsd: number;
  fxRateUsed: number;
  qrPayload: string | null;
}

export async function executePaymentGateway(params: {
  amount: number;
  currency: CurrencyCode;
  railId: PaymentRailId;
  instrumentInput: string;
  customerEmail: string;
  businessName: string;
  reference: string;
  idempotencyKey: string;
}): Promise<GatewayExecutionResult> {
  const rail = RAIL_BY_ID[params.railId];
  const { usdAmount, fxRateUsed } = convertToUsd(params.amount, params.currency);
  const feeUsd = Number(((usdAmount * rail.baseFeePct) / 100 + rail.fixedFeeUsd).toFixed(2));
  const netUsd = Number(Math.max(0, usdAmount - feeUsd).toFixed(2));

  let qrPayload: string | null = null;
  if (rail.supportsQr === 'emvco_raast') {
    qrPayload = buildSbpRaastEmvQr({
      merchantName: params.businessName,
      city: 'Karachi',
      raastId: params.instrumentInput,
      amount: params.amount,
      currency: params.currency,
      reference: params.reference,
    });
  } else if (rail.supportsQr === 'zatca_tlv') {
    qrPayload = buildZatcaPhase2TlvBase64({
      sellerName: params.businessName,
      vatNumber: '310122393500003',
      timestampIso: new Date().toISOString(),
      totalAmountSar: params.amount,
    });
  }

  if (stripeClient && rail.connectorType === 'stripe') {
    const zeroDecimalCurrencies = new Set<CurrencyCode>(['JPY']);
    const unitAmount = zeroDecimalCurrencies.has(params.currency)
      ? Math.round(params.amount)
      : Math.round(params.amount * 100);

    const intent = await stripeClient.paymentIntents.create(
      {
        amount: unitAmount,
        currency: params.currency.toLowerCase(),
        receipt_email: params.customerEmail,
        description: `BolMizan ${params.reference} (${rail.shortName})`,
        metadata: { railId: params.railId, reference: params.reference },
        automatic_payment_methods: { enabled: true, allow_redirects: 'never' },
      },
      { idempotencyKey: params.idempotencyKey }
    );

    return {
      connectorMode: 'stripe_live',
      gatewayIntentId: intent.id,
      status: intent.status === 'succeeded' ? 'settled' : 'processing',
      usdAmount,
      feeUsd,
      netUsd,
      fxRateUsed,
      qrPayload,
    };
  }

  if (paypalClientId && paypalClientSecret && rail.connectorType === 'paypal') {
    const paypalBase =
      process.env.PAYPAL_ENV === 'live'
        ? 'https://api-m.paypal.com'
        : 'https://api-m.sandbox.paypal.com';

    const authHeader = Buffer.from(`${paypalClientId}:${paypalClientSecret}`).toString('base64');
    const tokenRes = await fetch(`${paypalBase}/v1/oauth2/token`, {
      method: 'POST',
      headers: {
        Authorization: `Basic ${authHeader}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'grant_type=client_credentials',
    });

    if (tokenRes.ok) {
      const tokenData = (await tokenRes.json()) as { access_token: string };
      const orderRes = await fetch(`${paypalBase}/v2/checkout/orders`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${tokenData.access_token}`,
          'Content-Type': 'application/json',
          'PayPal-Request-Id': params.idempotencyKey,
        },
        body: JSON.stringify({
          intent: 'CAPTURE',
          purchase_units: [
            {
              reference_id: params.reference,
              amount: {
                currency_code: params.currency,
                value: params.amount.toFixed(params.currency === 'JPY' ? 0 : 2),
              },
            },
          ],
        }),
      });

      if (orderRes.ok) {
        const orderData = (await orderRes.json()) as { id: string; status: string };
        return {
          connectorMode: 'paypal_live',
          gatewayIntentId: orderData.id,
          status: orderData.status === 'COMPLETED' ? 'settled' : 'processing',
          usdAmount,
          feeUsd,
          netUsd,
          fxRateUsed,
          qrPayload,
        };
      }
    }
  }

  const clearingDigest = crypto
    .createHash('sha256')
    .update(`${params.reference}:${params.idempotencyKey}:${params.railId}`)
    .digest('hex')
    .slice(0, 16);

  return {
    connectorMode: 'sandbox_clearing',
    gatewayIntentId: `vts_${params.railId.slice(0, 4)}_${clearingDigest}`,
    status: params.railId === 'wise_corridor' ? 'processing' : 'settled',
    usdAmount,
    feeUsd,
    netUsd,
    fxRateUsed,
    qrPayload,
  };
}
