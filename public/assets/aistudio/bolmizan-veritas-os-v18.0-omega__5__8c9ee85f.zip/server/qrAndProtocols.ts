import type { CurrencyCode, PaymentTransaction } from '../shared/types.js';
import { CURRENCY_METADATA } from '../shared/rails.js';

function emvTag(id: string, value: string): string {
  const len = String(Buffer.byteLength(value, 'utf8')).padStart(2, '0');
  return `${id}${len}${value}`;
}

function crc16CcittFalse(input: string): string {
  let crc = 0xffff;
  const bytes = Buffer.from(input, 'utf8');
  for (const byte of bytes) {
    crc ^= byte << 8;
    for (let bit = 0; bit < 8; bit++) {
      if ((crc & 0x8000) !== 0) {
        crc = ((crc << 1) ^ 0x1021) & 0xffff;
      } else {
        crc = (crc << 1) & 0xffff;
      }
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

export function buildSbpRaastEmvQr(params: {
  merchantName: string;
  city: string;
  raastId: string;
  amount: number;
  currency: CurrencyCode;
  reference: string;
}): string {
  const merchantAccountInfo =
    emvTag('00', 'pk.gov.sbp.raast') + emvTag('01', params.raastId.slice(0, 34));
  const additionalData = emvTag('01', params.reference.slice(0, 25));
  const numericCurrency = CURRENCY_METADATA[params.currency]?.isoNumeric || '586';

  const bodyWithoutCrc =
    emvTag('00', '01') +
    emvTag('01', '12') +
    emvTag('26', merchantAccountInfo) +
    emvTag('52', '5411') +
    emvTag('53', numericCurrency) +
    emvTag('54', params.amount.toFixed(CURRENCY_METADATA[params.currency]?.decimals ?? 2)) +
    emvTag('58', 'PK') +
    emvTag('59', params.merchantName.slice(0, 25)) +
    emvTag('60', params.city.slice(0, 15)) +
    emvTag('62', additionalData) +
    '6304';

  const crc = crc16CcittFalse(bodyWithoutCrc);
  return `${bodyWithoutCrc}${crc}`;
}

function tlvChunk(tag: number, value: string): Buffer {
  const valBuf = Buffer.from(value, 'utf8');
  return Buffer.concat([Buffer.from([tag, valBuf.length]), valBuf]);
}

export function buildZatcaPhase2TlvBase64(params: {
  sellerName: string;
  vatNumber: string;
  timestampIso: string;
  totalAmountSar: number;
}): string {
  const vatAmount = (params.totalAmountSar * 0.15) / 1.15;
  const payload = Buffer.concat([
    tlvChunk(1, params.sellerName.slice(0, 60)),
    tlvChunk(2, params.vatNumber),
    tlvChunk(3, params.timestampIso),
    tlvChunk(4, params.totalAmountSar.toFixed(2)),
    tlvChunk(5, vatAmount.toFixed(2)),
  ]);
  return payload.toString('base64');
}

function escapeXml(val: string): string {
  return val
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

export function buildIso20022Pain001Xml(transactions: PaymentTransaction[], businessName: string): string {
  const nowIso = new Date().toISOString();
  const totalAmount = transactions.reduce((s, t) => s + t.amount, 0).toFixed(2);
  const txBlocks = transactions
    .slice(0, 50)
    .map(
      (tx) => `      <CdtTrfTxInf>
        <PmtId>
          <InstrId>${escapeXml(tx.reference)}</InstrId>
          <EndToEndId>${escapeXml(tx.id)}</EndToEndId>
        </PmtId>
        <Amt>
          <InstdAmt Ccy="${escapeXml(tx.currency)}">${tx.amount.toFixed(2)}</InstdAmt>
        </Amt>
        <Cdtr>
          <Nm>${escapeXml(tx.customerName)}</Nm>
        </Cdtr>
        <RmtInf>
          <Ustrd>${escapeXml(`${tx.railName} · ${tx.branchId} · ${tx.gatewayIntentId}`)}</Ustrd>
        </RmtInf>
      </CdtTrfTxInf>`
    )
    .join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.03">
  <CstmrCdtTrfInitn>
    <GrpHdr>
      <MsgId>BOLMIZAN-OMEGA-${Date.now()}</MsgId>
      <CreDtTm>${nowIso}</CreDtTm>
      <NbOfTxs>${transactions.slice(0, 50).length}</NbOfTxs>
      <CtrlSum>${totalAmount}</CtrlSum>
      <InitgPty>
        <Nm>${escapeXml(businessName || 'BolMizan Global HQ · Sakrand, Sindh')}</Nm>
      </InitgPty>
    </GrpHdr>
    <PmtInf>
      <PmtInfId>VERITAS-SAKRAND-HQ</PmtInfId>
      <PmtMtd>TRF</PmtMtd>
      <ReqdExctnDt>${nowIso.slice(0, 10)}</ReqdExctnDt>
${txBlocks}
    </PmtInf>
  </CstmrCdtTrfInitn>
</Document>`;
}
