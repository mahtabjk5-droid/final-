import type { CurrencyCode, FxRateSnapshot } from '../shared/types.js';

const BASELINE_RATES: Record<CurrencyCode, number> = {
  USD: 1,
  PKR: 278.4,
  SAR: 3.75,
  AED: 3.6725,
  EUR: 0.924,
  GBP: 0.786,
  INR: 84.35,
  BRL: 5.76,
  CNY: 7.21,
  JPY: 153.8,
  KES: 129.4,
};

let cachedRates: Record<CurrencyCode, number> = { ...BASELINE_RATES };
let lastFetchMs = 0;
let lastSource: 'live_api' | 'cached_market' = 'cached_market';

const CACHE_TTL_MS = 5 * 60 * 1000;

export async function refreshLiveFxRates(): Promise<FxRateSnapshot> {
  const now = Date.now();
  if (now - lastFetchMs < CACHE_TTL_MS && lastFetchMs > 0) {
    return getFxSnapshot();
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3500);
    const res = await fetch('https://open.er-api.com/v6/latest/USD', {
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (res.ok) {
      const json = (await res.json()) as {
        result?: string;
        rates?: Record<string, number>;
      };
      if (json.result === 'success' && json.rates) {
        const next: Record<CurrencyCode, number> = { ...cachedRates };
        (Object.keys(BASELINE_RATES) as CurrencyCode[]).forEach((code) => {
          const val = json.rates?.[code];
          if (typeof val === 'number' && Number.isFinite(val) && val > 0) {
            next[code] = val;
          }
        });
        cachedRates = next;
        lastFetchMs = now;
        lastSource = 'live_api';
      }
    }
  } catch {
    lastFetchMs = now;
  }

  return getFxSnapshot();
}

export function tickFxRatesMicro(): FxRateSnapshot {
  const next: Record<CurrencyCode, number> = { ...cachedRates };
  (Object.keys(next) as CurrencyCode[]).forEach((code) => {
    if (code === 'USD' || code === 'SAR' || code === 'AED') return;
    const jitter = (Math.random() - 0.5) * 0.0016;
    next[code] = Number((next[code] * (1 + jitter)).toFixed(code === 'PKR' || code === 'JPY' ? 2 : 4));
  });
  cachedRates = next;
  return getFxSnapshot();
}

export function getFxSnapshot(): FxRateSnapshot {
  return {
    base: 'USD',
    updatedAt: new Date().toISOString(),
    source: lastSource,
    rates: { ...cachedRates },
  };
}

export function convertToUsd(amount: number, currency: CurrencyCode): {
  usdAmount: number;
  fxRateUsed: number;
} {
  const rate = cachedRates[currency] || BASELINE_RATES[currency] || 1;
  return {
    usdAmount: Number((amount / rate).toFixed(2)),
    fxRateUsed: rate,
  };
}

export function convertToPkr(amount: number, currency: CurrencyCode): number {
  if (currency === 'PKR') return amount;
  const { usdAmount } = convertToUsd(amount, currency);
  const pkrPerUsd = cachedRates.PKR || BASELINE_RATES.PKR;
  return Number((usdAmount * pkrPerUsd).toFixed(0));
}
