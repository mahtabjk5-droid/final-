import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { walStore, type StoredUser } from './walStore.js';

const SESSION_SECRET =
  process.env.AUTH_SESSION_SECRET?.trim() || 'veritas_dev_session_secret_change_in_prod';
export const SESSION_COOKIE_NAME = 'veritas_session';

interface SessionPayload {
  uid: string;
  exp: number;
}

export function createSessionToken(userId: string): string {
  const payload: SessionPayload = {
    uid: userId,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(token: string): SessionPayload | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, providedSig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');

  const bufA = Buffer.from(providedSig, 'utf8');
  const bufB = Buffer.from(expectedSig, 'utf8');
  if (bufA.length !== bufB.length || !crypto.timingSafeEqual(bufA, bufB)) {
    return null;
  }

  try {
    const parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as SessionPayload;
    if (!parsed.uid || typeof parsed.exp !== 'number' || parsed.exp < Date.now()) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export function parseCookieHeader(cookieHeader: string | undefined): Record<string, string> {
  if (!cookieHeader) return {};
  const result: Record<string, string> = {};
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0) {
      const k = part.slice(0, idx).trim();
      const v = decodeURIComponent(part.slice(idx + 1).trim());
      result[k] = v;
    }
  }
  return result;
}

export function extractUserFromRequest(req: Request): StoredUser | null {
  const cookies = parseCookieHeader(req.headers.cookie);
  const bearer = req.header('Authorization')?.replace(/^Bearer\s+/i, '').trim();
  const token = cookies[SESSION_COOKIE_NAME] || bearer;
  if (!token) return null;

  const payload = verifySessionToken(token);
  if (!payload) return null;
  return walStore.findUserById(payload.uid) ?? null;
}

export interface AuthedRequest extends Request {
  authUser?: StoredUser;
}

export function requireAuth(req: AuthedRequest, res: Response, next: NextFunction): void {
  const user = extractUserFromRequest(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }
  req.authUser = user;
  next();
}

export function isHttpsRequest(req?: Request): boolean {
  if (!req) return process.env.NODE_ENV === 'production';
  if (req.secure) return true;
  const proto = req.get('x-forwarded-proto');
  if (proto && proto.split(',')[0].trim().toLowerCase() === 'https') return true;
  const origin = req.get('origin') || req.get('referer') || '';
  if (origin.startsWith('https://')) return true;
  return process.env.NODE_ENV === 'production';
}

export function setSessionCookie(res: Response, userId: string, req?: Request): string {
  const token = createSessionToken(userId);
  const secure = isHttpsRequest(req);
  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: secure ? 'none' : 'lax',
    secure,
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: '/',
  });
  return token;
}

export function clearSessionCookie(res: Response, req?: Request): void {
  const secure = isHttpsRequest(req);
  res.clearCookie(SESSION_COOKIE_NAME, {
    path: '/',
    sameSite: secure ? 'none' : 'lax',
    secure,
  });
}
