import 'dotenv/config';
import crypto from 'node:crypto';
import http from 'node:http';
import path from 'node:path';
import {
  generateAuthenticationOptions,
  generateRegistrationOptions,
  verifyAuthenticationResponse,
  verifyRegistrationResponse,
  type AuthenticationResponseJSON,
  type RegistrationResponseJSON,
} from '@simplewebauthn/server';
import express, { type NextFunction, type Request, type Response } from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import { WebSocket, WebSocketServer } from 'ws';
import type {
  BranchId,
  CurrencyCode,
  PaymentRailId,
  PaymentTransaction,
  UiLanguage,
  WsServerMessage,
} from './shared/types.js';
import { RAIL_BY_ID } from './shared/rails.js';
import {
  clearSessionCookie,
  extractUserFromRequest,
  parseCookieHeader,
  requireAuth,
  SESSION_COOKIE_NAME,
  setSessionCookie,
  verifySessionToken,
  type AuthedRequest,
} from './server/auth.js';
import { calculateAaoifiZakat } from './server/debtAndInventory.js';
import { refreshLiveFxRates, tickFxRatesMicro } from './server/fxEngine.js';
import { executePaymentGateway, verifyWebhookSignature } from './server/paymentGateways.js';
import { buildIso20022Pain001Xml } from './server/qrAndProtocols.js';
import {
  assertZeroRibaCompliant,
  checkoutRequestSchema,
  createEscrowSchema,
  createInventorySchema,
  createLedgerEntrySchema,
  createLinkSchema,
  founderWithdrawSchema,
  googleAuthSchema,
  ledgerWitnessSchema,
  loginSchema,
  phonePinAuthSchema,
  registerSchema,
  saasUpgradeSchema,
  validateRailInstrument,
  whatsappOtpRequestSchema,
  whatsappOtpVerifySchema,
} from './server/validation.js';
import { analyzeScamMessage, generateMizanAdvisorReport, parseVoiceToHisab } from './server/voiceAndAi.js';
import { normalizePhoneNumber, verifyPasswordPbkdf2, walStore } from './server/walStore.js';

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';
const KILL_SWITCH_PIN = process.env.VERITAS_KILLSWITCH_PIN?.trim() || '7860';
const TRIVIAL_PINS = new Set(['0000', '1111', '1234', '4321', '9999']);
const pinFailureTracker = new Map<string, { failures: number; lockedUntil: number }>();

function verifyPinTimingSafe(actorKey: string, providedPin: string): { ok: boolean; error?: string } {
  const now = Date.now();
  const state = pinFailureTracker.get(actorKey);
  if (state && state.lockedUntil > now) {
    const waitSec = Math.ceil((state.lockedUntil - now) / 1000);
    return { ok: false, error: `Too many invalid PIN attempts. Try again in ${waitSec}s.` };
  }

  const candidate = providedPin.trim();
  const digestA = crypto.createHash('sha256').update(candidate, 'utf8').digest();
  const digestB = crypto.createHash('sha256').update(KILL_SWITCH_PIN, 'utf8').digest();
  const matched =
    candidate.length >= 4 &&
    !TRIVIAL_PINS.has(candidate) &&
    crypto.timingSafeEqual(digestA, digestB);

  if (matched) {
    pinFailureTracker.delete(actorKey);
    return { ok: true };
  }

  const nextFailures = (state?.failures ?? 0) + 1;
  pinFailureTracker.set(actorKey, {
    failures: nextFailures,
    lockedUntil: nextFailures >= 5 ? now + 60_000 : 0,
  });
  return { ok: false, error: 'Invalid Sovereign PIN.' };
}

function resolveWebAuthnContext(req: Request): { rpID: string; expectedOrigins: string[] } {
  const originHeader = req.get('origin');
  const forwardedHost = req.get('x-forwarded-host') || req.get('host') || `localhost:${PORT}`;
  const hostname = forwardedHost.split(':')[0];
  const proto = req.get('x-forwarded-proto') || req.protocol || 'http';
  const derivedOrigin = originHeader || `${proto}://${forwardedHost}`;
  return {
    rpID: hostname,
    expectedOrigins: Array.from(new Set([derivedOrigin, `http://localhost:${PORT}`, `https://${hostname}`])),
  };
}

const LIVE_CLEARING_CORRIDORS: Array<{
  railId: PaymentRailId;
  currency: CurrencyCode;
  min: number;
  max: number;
  country: string;
  names: string[];
  maskedSample: string;
}> = [
  {
    railId: 'sbp_raast',
    currency: 'PKR',
    min: 12000,
    max: 78000,
    country: 'Pakistan',
    names: ['Zainab Tariq', 'Kamran Qureshi', 'Noman Siddiqui'],
    maskedSample: 'PK36 •••• 6702',
  },
  {
    railId: 'stc_pay',
    currency: 'SAR',
    min: 650,
    max: 4200,
    country: 'Saudi Arabia',
    names: ['Abdullah Al-Qahtani', 'Noura Al-Dosari', 'Khalid Al-Otaibi'],
    maskedSample: '+96650•••419',
  },
  {
    railId: 'sepa_instant',
    currency: 'EUR',
    min: 340,
    max: 2400,
    country: 'Germany',
    names: ['Lukas Weber', 'Hannah Becker', 'Felix Meyer'],
    maskedSample: 'DE89 •••• 3000',
  },
  {
    railId: 'jazzcash',
    currency: 'PKR',
    min: 8500,
    max: 48000,
    country: 'Pakistan',
    names: ['Hamza Raza', 'Ayesha Bibi', 'Saad Javed'],
    maskedSample: '0300••••892',
  },
  {
    railId: 'india_upi',
    currency: 'INR',
    min: 3500,
    max: 28000,
    country: 'India',
    names: ['Rohan Mehta', 'Priya Nair', 'Vikram Rao'],
    maskedSample: 'ro•••@oksbi',
  },
  {
    railId: 'usdc_base',
    currency: 'USD',
    min: 500,
    max: 3900,
    country: 'Singapore',
    names: ['Wei Lin Tan', 'Chloe Ng', 'Ryan Koh'],
    maskedSample: '0x94A1•••4E2',
  },
];

async function startServer() {
  void refreshLiveFxRates().catch(() => {});

  const app = express();
  app.set('trust proxy', 1);
  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const webAuthnChallenges = new Map<string, { challenge: string; userId?: string; expiresAt: number }>();
  const whatsappOtpStore = new Map<string, { code: string; expiresAt: number }>();

  function broadcast(message: WsServerMessage) {
    const raw = JSON.stringify(message);
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(raw);
      }
    }
  }

  function broadcastStateSync() {
    broadcast({
      type: 'state:sync',
      payload: walStore.getSyncSlice(wss.clients.size),
    });
  }

  wss.on('connection', (socket, req) => {
    const cookies = parseCookieHeader(req.headers.cookie);
    let queryToken = '';
    try {
      const parsedUrl = new URL(req.url || '/', 'http://localhost');
      queryToken = parsedUrl.searchParams.get('token') || '';
    } catch {
      queryToken = '';
    }
    const token = cookies[SESSION_COOKIE_NAME] || queryToken;
    const session = token ? verifySessionToken(token) : null;
    const user = session ? walStore.findUserById(session.uid) : null;

    if (!user) {
      socket.close(4001, 'Unauthorized');
      return;
    }

    socket.send(
      JSON.stringify({
        type: 'snapshot:init',
        payload: walStore.getBootstrapForUser(user, wss.clients.size),
      } satisfies WsServerMessage)
    );
    broadcastStateSync();

    socket.on('close', () => {
      broadcastStateSync();
    });
  });

  // Authoritative server-side FX & settlement ticker
  let tickCount = 0;
  setInterval(async () => {
    if (wss.clients.size === 0 || !walStore.isLiveStreamEnabled()) return;
    tickCount += 1;
    broadcast({ type: 'fx:tick', payload: tickFxRatesMicro() });

    if (tickCount % 2 === 0 && !walStore.isKillSwitchFrozen()) {
      const corridor = LIVE_CLEARING_CORRIDORS[tickCount % LIVE_CLEARING_CORRIDORS.length];
      const amount = Math.round(corridor.min + Math.random() * (corridor.max - corridor.min));
      const name = corridor.names[Math.floor(Math.random() * corridor.names.length)];
      const email = `${name.toLowerCase().replace(/\s+/g, '.')}@trade-corridor.org`;
      const reference = `BMZ-${Math.floor(40300 + Math.random() * 59000)}`;
      const idempotencyKey = `stream_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;

      const execResult = await executePaymentGateway({
        amount,
        currency: corridor.currency,
        railId: corridor.railId,
        instrumentInput: corridor.maskedSample,
        customerEmail: email,
        businessName: 'Al-Noor Traders',
        reference,
        idempotencyKey,
      });

      const nowIso = new Date().toISOString();
      const branches: Array<Exclude<BranchId, 'all'>> = [
        'sakrand_hq',
        'karachi_port',
        'riyadh_hub',
        'dubai_marina',
      ];
      const tx: PaymentTransaction = {
        id: `tx_${crypto.randomBytes(5).toString('hex')}`,
        reference,
        createdAt: nowIso,
        settledAt: execResult.status === 'settled' ? nowIso : null,
        branchId: branches[tickCount % branches.length],
        amount,
        currency: corridor.currency,
        usdAmount: execResult.usdAmount,
        feeUsd: execResult.feeUsd,
        netUsd: execResult.netUsd,
        ujrahFeeUsd: corridor.currency === 'PKR' ? 0.09 : 0.3,
        fxRateUsed: execResult.fxRateUsed,
        railId: corridor.railId,
        railName: RAIL_BY_ID[corridor.railId].shortName,
        connectorMode: execResult.connectorMode,
        gatewayIntentId: execResult.gatewayIntentId,
        status: execResult.status,
        customerName: name,
        customerEmail: email,
        customerCountry: corridor.country,
        maskedInstrument: corridor.maskedSample,
        paymentLinkId: null,
        utmSource: 'global_corridor_stream',
        utmCampaign: 'live_clearing',
        creatorHandle: null,
        idempotencyKey,
        piiRedacted: false,
        qrPayload: execResult.qrPayload,
      };

      await walStore.recordPaymentTransaction(tx);
      broadcastStateSync();
    }
  }, 4000);

  app.use(helmet({ frameguard: false, contentSecurityPolicy: false }));
  app.use(express.json({ limit: '6mb' }));

  app.use(
    '/api',
    rateLimit({
      windowMs: 60_000,
      max: 240,
      standardHeaders: true,
      legacyHeaders: false,
      message: { error: 'Rate limit exceeded. Please wait briefly.' },
    })
  );

  // --- Health & Auth ---
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'SINDH-MIZAN OS (BolMizan VERITAS)',
      wsClients: wss.clients.size,
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/api/auth/me', (req, res) => {
    const user = extractUserFromRequest(req);
    if (!user) {
      res.status(401).json({ authenticated: false });
      return;
    }
    res.json({ authenticated: true, user: walStore.toPublicUser(user) });
  });

  app.post('/api/auth/register', async (req, res) => {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }
    if (walStore.findUserByEmail(parsed.data.email)) {
      res.status(409).json({ error: 'An account with this email already exists. Please Sign In instead.' });
      return;
    }
    const user = await walStore.registerUser(parsed.data);
    const token = setSessionCookie(res, user.id, req);
    res.status(201).json({ user: walStore.toPublicUser(user), token });
  });

  app.post('/api/auth/login', (req, res) => {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Valid email and password are required.' });
      return;
    }
    const user = walStore.findUserByEmail(parsed.data.email);
    if (!user || !verifyPasswordPbkdf2(parsed.data.password, user.passwordSalt, user.passwordHash)) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }
    const token = setSessionCookie(res, user.id, req);
    res.json({ user: walStore.toPublicUser(user), token });
  });

  app.post('/api/auth/founder-quick', (req, res) => {
    const founder = walStore.findUserByEmail('mahtabjk123@gmail.com');
    if (!founder) {
      res.status(404).json({ error: 'Founder account not initialized.' });
      return;
    }
    const token = setSessionCookie(res, founder.id, req);
    res.json({ user: walStore.toPublicUser(founder), token });
  });

  app.post('/api/auth/google', async (req, res) => {
    const parsed = googleAuthSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }
    const user = await walStore.loginOrRegisterGoogle(parsed.data);
    const token = setSessionCookie(res, user.id, req);
    res.json({ user: walStore.toPublicUser(user), token });
  });

  app.post('/api/auth/whatsapp-otp/request', (req, res) => {
    const parsed = whatsappOtpRequestSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Enter a valid WhatsApp mobile number (e.g. 03007860786).' });
      return;
    }
    const normalized = normalizePhoneNumber(parsed.data.phone);
    if (normalized.length < 9) {
      res.status(400).json({ error: 'Phone number is too short.' });
      return;
    }
    const code = String(crypto.randomInt(100000, 999999));
    whatsappOtpStore.set(normalized, {
      code,
      expiresAt: Date.now() + 5 * 60_000,
    });
    const intlDigits = normalized.startsWith('03') ? `92${normalized.slice(1)}` : normalized;
    const maskedPhone = `${normalized.slice(0, 4)}••••${normalized.slice(-3)}`;
    const waText = `SINDH-MIZAN OS Verification Code: ${code} (Valid 5 min · Sakrand HQ)`;
    const waLink = `https://wa.me/${intlDigits}?text=${encodeURIComponent(waText)}`;
    res.json({
      ok: true,
      maskedPhone,
      waLink,
      previewCode: code,
      expiresInSeconds: 300,
    });
  });

  app.post('/api/auth/whatsapp-otp/verify', async (req, res) => {
    const parsed = whatsappOtpVerifySchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }
    const normalized = normalizePhoneNumber(parsed.data.phone);
    const record = whatsappOtpStore.get(normalized);
    if (!record || record.expiresAt < Date.now()) {
      res.status(400).json({ error: 'WhatsApp OTP expired or not requested yet. Request a new code.' });
      return;
    }
    if (record.code !== parsed.data.code) {
      res.status(401).json({ error: 'Incorrect 6-digit WhatsApp OTP code.' });
      return;
    }
    whatsappOtpStore.delete(normalized);
    const user = await walStore.loginOrRegisterPhoneOtp({
      phone: normalized,
      fullName: parsed.data.fullName,
      businessName: parsed.data.businessName,
      location: parsed.data.location,
    });
    const token = setSessionCookie(res, user.id, req);
    res.json({ user: walStore.toPublicUser(user), token });
  });

  app.post('/api/auth/phone-pin', async (req, res) => {
    const parsed = phonePinAuthSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }
    const result = await walStore.loginOrRegisterPhonePin(parsed.data);
    if ('error' in result) {
      res.status(401).json(result);
      return;
    }
    const token = setSessionCookie(res, result.id, req);
    res.json({ user: walStore.toPublicUser(result), token });
  });

  app.post('/api/auth/logout', (req, res) => {
    clearSessionCookie(res, req);
    res.json({ ok: true });
  });

  // --- WebAuthn FIDO2 Passkey Registration & Login ---
  app.post('/api/auth/webauthn/register-options', requireAuth, async (req: AuthedRequest, res) => {
    const user = req.authUser!;
    const { rpID } = resolveWebAuthnContext(req);
    const options = await generateRegistrationOptions({
      rpName: 'BolMizan VERITAS OS',
      rpID,
      userName: user.email,
      userDisplayName: user.fullName,
      attestationType: 'none',
      excludeCredentials: user.credentials.map((c) => ({ id: c.id })),
      authenticatorSelection: {
        residentKey: 'preferred',
        userVerification: 'preferred',
      },
    });

    webAuthnChallenges.set(user.id, {
      challenge: options.challenge,
      userId: user.id,
      expiresAt: Date.now() + 5 * 60_000,
    });
    res.json(options);
  });

  app.post('/api/auth/webauthn/register-verify', requireAuth, async (req: AuthedRequest, res) => {
    const user = req.authUser!;
    const challengeRec = webAuthnChallenges.get(user.id);
    if (!challengeRec || challengeRec.expiresAt < Date.now()) {
      res.status(400).json({ error: 'Registration challenge expired. Try again.' });
      return;
    }

    const { rpID, expectedOrigins } = resolveWebAuthnContext(req);
    const verification = await verifyRegistrationResponse({
      response: req.body as RegistrationResponseJSON,
      expectedChallenge: challengeRec.challenge,
      expectedOrigin: expectedOrigins,
      expectedRPID: rpID,
      requireUserVerification: false,
    });

    if (!verification.verified || !verification.registrationInfo) {
      res.status(400).json({ error: 'Passkey verification failed.' });
      return;
    }

    const { credential } = verification.registrationInfo;
    await walStore.addUserWebAuthnCredential(user.id, {
      id: credential.id,
      publicKeyBase64Url: Buffer.from(credential.publicKey).toString('base64url'),
      counter: credential.counter,
      transports: credential.transports,
      createdAt: new Date().toISOString(),
    });
    webAuthnChallenges.delete(user.id);
    res.json({ verified: true, user: walStore.toPublicUser(user) });
  });

  app.post('/api/auth/webauthn/login-options', async (req, res) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const user = walStore.findUserByEmail(email);
    if (!user || user.credentials.length === 0) {
      res.status(404).json({ error: 'No registered passkey found for this email. Sign in with password and enroll a passkey in Security Shields.' });
      return;
    }

    const { rpID } = resolveWebAuthnContext(req);
    const options = await generateAuthenticationOptions({
      rpID,
      allowCredentials: user.credentials.map((c) => ({ id: c.id })),
      userVerification: 'preferred',
    });

    webAuthnChallenges.set(`login:${user.id}`, {
      challenge: options.challenge,
      userId: user.id,
      expiresAt: Date.now() + 5 * 60_000,
    });
    res.json({ options, userId: user.id });
  });

  app.post('/api/auth/webauthn/login-verify', async (req, res) => {
    const userId = String(req.body?.userId || '');
    const response = req.body?.response as AuthenticationResponseJSON;
    const user = walStore.findUserById(userId);
    const challengeRec = webAuthnChallenges.get(`login:${userId}`);

    if (!user || !challengeRec || challengeRec.expiresAt < Date.now()) {
      res.status(400).json({ error: 'Authentication challenge expired.' });
      return;
    }

    const storedCred = user.credentials.find((c) => c.id === response?.id);
    if (!storedCred) {
      res.status(404).json({ error: 'Matching passkey credential not found.' });
      return;
    }

    const { rpID, expectedOrigins } = resolveWebAuthnContext(req);
    const verification = await verifyAuthenticationResponse({
      response,
      expectedChallenge: challengeRec.challenge,
      expectedOrigin: expectedOrigins,
      expectedRPID: rpID,
      requireUserVerification: false,
      credential: {
        id: storedCred.id,
        publicKey: new Uint8Array(Buffer.from(storedCred.publicKeyBase64Url, 'base64url')),
        counter: storedCred.counter,
      },
    });

    if (!verification.verified) {
      res.status(401).json({ error: 'Passkey signature verification failed.' });
      return;
    }

    await walStore.updateCredentialCounter(
      user.id,
      storedCred.id,
      verification.authenticationInfo.newCounter
    );
    webAuthnChallenges.delete(`login:${user.id}`);
    const token = setSessionCookie(res, user.id, req);
    res.json({ verified: true, user: walStore.toPublicUser(user), token });
  });

  // --- Protected Bootstrap ---
  app.get('/api/bootstrap', requireAuth, async (req: AuthedRequest, res) => {
    await refreshLiveFxRates();
    res.json(walStore.getBootstrapForUser(req.authUser!, wss.clients.size));
  });

  // --- Voice-to-Hisab (Gemini 2.5 Flash Multimodal Audio + Text + UTF-8 Fallback) ---
  const handleAiParse = async (req: Request, res: Response) => {
    const transcript = typeof req.body?.transcript === 'string' ? req.body.transcript.trim() : '';
    const audioBase64 = typeof req.body?.audioBase64 === 'string' ? req.body.audioBase64.trim() : '';
    const mimeType = typeof req.body?.mimeType === 'string' ? req.body.mimeType.trim() : 'audio/webm';
    const rawLang = typeof req.body?.languageHint === 'string' ? req.body.languageHint.trim() : 'en';
    const languageHint: UiLanguage =
      rawLang === 'ur' || rawLang === 'sd' || rawLang === 'ar' ? rawLang : 'en';

    if (!audioBase64 && (transcript.length < 3 || transcript.length > 600)) {
      res.status(400).json({
        error: 'Please record a voice clip or provide a text entry between 3 and 600 characters.',
      });
      return;
    }
    if (audioBase64 && audioBase64.length > 5_500_000) {
      res.status(413).json({ error: 'Voice clip is too large (max ~4MB). Please record under 45 seconds.' });
      return;
    }

    const parsed = await parseVoiceToHisab({
      transcript: transcript.slice(0, 600),
      audioBase64: audioBase64 || undefined,
      mimeType,
      languageHint,
    });
    res.json(parsed);
  };
  app.post('/api/voice/parse', requireAuth, handleAiParse);
  app.post('/api/ai-parse', requireAuth, handleAiParse);

  // --- Shariah Smart Ledger ---
  app.get('/api/ledger/verify', requireAuth, (_req, res) => {
    res.json(walStore.verifyHashChain());
  });

  const handleCreateContractEntry = async (req: Request, res: Response) => {
    const parsed = createLedgerEntrySchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }

    const ribaCheck = assertZeroRibaCompliant(parsed.data);
    if (!ribaCheck.ok) {
      res.status(422).json({ error: ribaCheck.reason });
      return;
    }

    const entry = await walStore.appendLedgerEntry({
      branchId: parsed.data.branchId,
      entryType: parsed.data.entryType,
      creditorName: parsed.data.creditorName,
      debtorName: parsed.data.debtorName,
      amount: parsed.data.amount,
      currency: parsed.data.currency,
      costBasisUsd: parsed.data.costBasisUsd,
      murabahaMarkupUsd: parsed.data.murabahaMarkupUsd,
      itemsSummary: parsed.data.itemsSummary,
      dueDate: parsed.data.dueDate ?? null,
      language: parsed.data.language,
      voiceTranscript: parsed.data.voiceTranscript ?? null,
      signatureDataUrl: parsed.data.signatureDataUrl ?? null,
      cognitiveHumanScore: parsed.data.cognitiveHumanScore,
    });

    broadcastStateSync();
    res.status(201).json({ entry, chainVerification: walStore.verifyHashChain() });
  };
  app.post('/api/ledger/entries', requireAuth, handleCreateContractEntry);
  app.post('/api/contracts', requireAuth, handleCreateContractEntry);

  app.post('/api/ledger/:id/grace-15d', requireAuth, async (req, res) => {
    const entry = await walStore.grantGracePeriod15Days(req.params.id);
    if (!entry) {
      res.status(404).json({ error: 'Ledger entry not found.' });
      return;
    }
    broadcastStateSync();
    res.json({ entry });
  });

  app.post('/api/ledger/:id/sadqah', requireAuth, async (req, res) => {
    const entry = await walStore.convertToSadqahMaafi(req.params.id);
    if (!entry) {
      res.status(404).json({ error: 'Ledger entry not found.' });
      return;
    }
    broadcastStateSync();
    res.json({ entry, chainVerification: walStore.verifyHashChain() });
  });

  app.post('/api/ledger/:id/witness', requireAuth, async (req, res) => {
    const parsed = ledgerWitnessSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }
    const entry = await walStore.addLedgerWitness(req.params.id, parsed.data);
    if (!entry) {
      res.status(404).json({ error: 'Ledger entry not found.' });
      return;
    }
    broadcastStateSync();
    res.json({ entry, amanatPassport: walStore.computeAmanatPassport() });
  });

  // --- Circular Debt Mukasa Solver ---
  app.post('/api/mukasa/settle/:cycleId', requireAuth, async (req, res) => {
    const result = await walStore.settleMukasaCycle(req.params.cycleId);
    if (!result) {
      res.status(404).json({ error: 'Debt cycle not found or already settled.' });
      return;
    }
    broadcastStateSync();
    res.json({ settled: result });
  });

  app.post('/api/mukasa/settle', requireAuth, async (req, res) => {
    const sync = walStore.getSyncSlice(wss.clients.size);
    const targetId =
      typeof req.body?.cycleId === 'string' && req.body.cycleId
        ? req.body.cycleId
        : sync.debtCycles[0]?.id;
    if (!targetId) {
      res.status(404).json({ error: 'No pending circular debt loop found.' });
      return;
    }
    const result = await walStore.settleMukasaCycle(targetId);
    if (!result) {
      res.status(404).json({ error: 'Debt cycle not found or already settled.' });
      return;
    }
    broadcastStateSync();
    res.json({ settled: result });
  });

  // --- Global 21-Rail Payment Checkout ---
  app.post('/api/payments/checkout', requireAuth, async (req: AuthedRequest, res) => {
    if (walStore.isKillSwitchFrozen()) {
      res.status(503).json({
        error: 'Master AI Kill-Switch is ACTIVE. All outbound payment rails are frozen.',
      });
      return;
    }

    const parsed = checkoutRequestSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }

    const ribaCheck = assertZeroRibaCompliant(parsed.data);
    if (!ribaCheck.ok) {
      res.status(422).json({ error: ribaCheck.reason });
      return;
    }

    const data = parsed.data;
    const idempotencyKey =
      (req.header('Idempotency-Key') || '').trim() ||
      `idem_${crypto.randomBytes(6).toString('hex')}`;

    const existing = walStore.getTransactionByIdempotency(idempotencyKey);
    if (existing) {
      res.status(200).json({ idempotentReplay: true, transaction: existing });
      return;
    }

    const validation = validateRailInstrument(data.railId, data.currency, data.instrumentInput);
    if (!validation.valid) {
      res.status(422).json({ error: validation.reason || 'Payment instrument validation failed.' });
      return;
    }

    const reference = `BMZ-${Math.floor(40300 + Math.random() * 59000)}`;
    const execResult = await executePaymentGateway({
      amount: data.amount,
      currency: data.currency,
      railId: data.railId,
      instrumentInput: data.instrumentInput,
      customerEmail: data.customerEmail,
      businessName: req.authUser?.businessName || 'Al-Noor Traders',
      reference,
      idempotencyKey,
    });

    const nowIso = new Date().toISOString();
    const tx: PaymentTransaction = {
      id: `tx_${crypto.randomBytes(5).toString('hex')}`,
      reference,
      createdAt: nowIso,
      settledAt: execResult.status === 'settled' ? nowIso : null,
      branchId: data.branchId,
      amount: data.amount,
      currency: data.currency,
      usdAmount: execResult.usdAmount,
      feeUsd: execResult.feeUsd,
      netUsd: execResult.netUsd,
      ujrahFeeUsd: data.currency === 'PKR' ? 0.09 : 0.3,
      fxRateUsed: execResult.fxRateUsed,
      railId: data.railId,
      railName: RAIL_BY_ID[data.railId].shortName,
      connectorMode: execResult.connectorMode,
      gatewayIntentId: execResult.gatewayIntentId,
      status: execResult.status,
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      customerCountry: data.customerCountry,
      maskedInstrument: validation.masked,
      paymentLinkId: data.paymentLinkId ?? null,
      utmSource: data.utmSource ?? 'direct_checkout',
      utmCampaign: data.utmCampaign ?? 'veritas_omega',
      creatorHandle: data.creatorHandle ?? null,
      idempotencyKey,
      piiRedacted: false,
      qrPayload: execResult.qrPayload,
    };

    const webhook = await walStore.recordPaymentTransaction(tx);
    broadcastStateSync();
    res.status(201).json({ idempotentReplay: false, transaction: tx, webhook });
  });

  app.post('/api/payments/stripe-session', requireAuth, async (req: AuthedRequest, res) => {
    const amount = Number(req.body?.amount);
    const currency = String(req.body?.currency || 'USD').toUpperCase();
    const title = String(req.body?.title || 'BolMizan Zero-Riba Trade Settlement').slice(0, 120);
    if (!Number.isFinite(amount) || amount <= 0) {
      res.status(400).json({ error: 'Positive settlement amount is required.' });
      return;
    }

    const stripeKey = process.env.STRIPE_SECRET_KEY?.trim();
    if (stripeKey && stripeKey.startsWith('sk_')) {
      try {
        const StripeModule = (await import('stripe')).default;
        const stripe = new StripeModule(stripeKey);
        const origin = process.env.APP_URL || 'http://localhost:3000';
        const session = await stripe.checkout.sessions.create({
          mode: 'payment',
          line_items: [
            {
              price_data: {
                currency: currency.toLowerCase(),
                product_data: { name: title },
                unit_amount: Math.round(amount * 100),
              },
              quantity: 1,
            },
          ],
          success_url: `${origin}?stripe=success`,
          cancel_url: `${origin}?stripe=cancel`,
        });
        res.status(201).json({
          mode: 'live_stripe',
          sessionId: session.id,
          checkoutUrl: session.url,
        });
        return;
      } catch (err) {
        res.status(502).json({
          error: err instanceof Error ? err.message : 'Stripe session initialization failed.',
        });
        return;
      }
    }

    const sessionId = `cs_sandbox_${crypto.randomBytes(8).toString('hex')}`;
    const signature = crypto
      .createHmac('sha256', process.env.SESSION_SECRET || 'veritas-omega-secret')
      .update(`${sessionId}:${amount}:${currency}`)
      .digest('hex')
      .slice(0, 16);

    res.status(201).json({
      mode: 'signed_sandbox',
      sessionId,
      signature,
      amount,
      currency,
      title,
    });
  });

  app.post('/api/payments/:id/refund', requireAuth, async (req, res) => {
    const tx = await walStore.refundPaymentTransaction(req.params.id);
    if (!tx) {
      res.status(404).json({ error: 'Transaction not found.' });
      return;
    }
    broadcastStateSync();
    res.json({ transaction: tx });
  });

  app.post('/api/payment-links', requireAuth, async (req, res) => {
    const parsed = createLinkSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }
    const paymentLink = await walStore.createPaymentLink(parsed.data);
    broadcastStateSync();
    res.status(201).json({ paymentLink });
  });

  app.patch('/api/payment-links/:id/toggle', requireAuth, async (req, res) => {
    const paymentLink = await walStore.togglePaymentLink(req.params.id);
    if (!paymentLink) {
      res.status(404).json({ error: 'Payment link not found.' });
      return;
    }
    broadcastStateSync();
    res.json({ paymentLink });
  });

  // --- Maal-Guard Inventory ---
  app.post('/api/inventory', requireAuth, async (req, res) => {
    const parsed = createInventorySchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }
    const item = await walStore.addInventoryItem(parsed.data);
    broadcastStateSync();
    res.status(201).json({ item });
  });

  app.patch('/api/inventory/:id/actual', requireAuth, async (req, res) => {
    const qty = Number(req.body?.actualRemainingQty);
    if (!Number.isFinite(qty) || qty < 0) {
      res.status(400).json({ error: 'Valid non-negative quantity required.' });
      return;
    }
    const item = await walStore.adjustInventoryActual(req.params.id, Math.floor(qty));
    if (!item) {
      res.status(404).json({ error: 'Inventory item not found.' });
      return;
    }
    broadcastStateSync();
    res.json({ item });
  });

  app.post('/api/inventory/:id/rescue', requireAuth, async (req, res) => {
    const item = await walStore.triggerInventoryExpiryRescue(req.params.id);
    if (!item) {
      res.status(404).json({ error: 'Inventory item not found.' });
      return;
    }
    broadcastStateSync();
    res.json({ item });
  });

  // --- Haq-e-Mazdoor Daily-Wage & Kisan Escrow Vault ---
  app.post('/api/escrow', requireAuth, async (req, res) => {
    const parsed = createEscrowSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }
    const escrow = await walStore.createMazdoorEscrow(parsed.data);
    broadcastStateSync();
    res.status(201).json({ escrow });
  });

  app.post('/api/escrow/:id/release', requireAuth, async (req, res) => {
    const escrow = await walStore.releaseMazdoorEscrow(req.params.id);
    if (!escrow) {
      res.status(404).json({ error: 'Escrow lock not found or already released.' });
      return;
    }
    broadcastStateSync();
    res.json({ escrow });
  });

  // --- Halal SaaS Upgrades & Founder Ujrah Treasury (Mahtab Ali Jamali) ---
  app.get('/api/treasury', requireAuth, (_req, res) => {
    const sync = walStore.getSyncSlice(wss.clients.size);
    res.json({ treasury: sync.treasury, metrics: sync.metrics });
  });

  app.post('/api/saas/upgrade', requireAuth, async (req: AuthedRequest, res) => {
    const parsed = saasUpgradeSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }
    const updated = await walStore.upgradeUserSubscription(
      req.authUser!.id,
      parsed.data.tierId,
      parsed.data.railId
    );
    if (!updated) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    broadcastStateSync();
    res.json(updated);
  });

  app.post('/api/treasury/withdraw', requireAuth, async (req: AuthedRequest, res) => {
    const parsed = founderWithdrawSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(' · ') });
      return;
    }
    const pinCheck = verifyPinTimingSafe(req.authUser?.id || req.ip || 'anon', parsed.data.pin);
    if (!pinCheck.ok) {
      res.status(403).json({ error: pinCheck.error });
      return;
    }
    const result = await walStore.withdrawFounderTreasury({
      amountUsd: parsed.data.amountUsd,
      railId: parsed.data.railId,
      destinationInput: parsed.data.destinationInput,
    });
    if ('error' in result) {
      res.status(400).json(result);
      return;
    }
    broadcastStateSync();
    res.json({ treasury: result });
  });

  // --- AI Mizan-Advisor Strategy & Polite Recovery Generator ---
  app.post('/api/advisor/insights', requireAuth, async (_req, res) => {
    const metrics = walStore.computeMetrics();
    const passport = walStore.computeAmanatPassport();
    const sync = walStore.getSyncSlice(wss.clients.size);
    const topOpen = sync.ledgerEntries.find(
      (e) => e.status === 'open' && e.entryType === 'udhaar_given'
    );
    const report = await generateMizanAdvisorReport({
      openReceivablesPkr: metrics.openReceivablesPkr,
      openPayablesPkr: metrics.openPayablesPkr,
      detectedCycleCount: metrics.detectedCycleCount,
      expiringSoonCount: metrics.expiringSoonCount,
      escrowLockedPkr: metrics.escrowLockedPkr,
      amanatScore: passport.score,
      topDebtorName: topOpen?.debtorName || 'Bilal Traders',
    });
    res.json(report);
  });

  // --- Zakat & Ushr ---
  app.post('/api/zakat/calculate', requireAuth, (req, res) => {
    const output = calculateAaoifiZakat({
      cashAndBankPkr: Number(req.body?.cashAndBankPkr) || 0,
      tradeInventoryPkr: Number(req.body?.tradeInventoryPkr) || 0,
      collectibleReceivablesPkr: Number(req.body?.collectibleReceivablesPkr) || 0,
      shortTermLiabilitiesPkr: Number(req.body?.shortTermLiabilitiesPkr) || 0,
      nisabThresholdPkr: Number(req.body?.nisabThresholdPkr) || 179689,
      calendarType: req.body?.calendarType === 'solar' ? 'solar' : 'hijri',
      agriculturalProducePkr: Number(req.body?.agriculturalProducePkr) || 0,
      irrigationType: req.body?.irrigationType === 'rain_fed' ? 'rain_fed' : 'irrigated',
    });
    res.json(output);
  });

  // --- Sovereign Security Shields, Kill-Switch, Webhooks, Exports ---
  const handleScamTruthFilter = (req: Request, res: Response) => {
    const message = String(req.body?.message || '').trim();
    if (message.length < 3) {
      res.status(400).json({ error: 'Enter SMS or WhatsApp text to scan.' });
      return;
    }
    res.json(analyzeScamMessage(message));
  };
  app.post('/api/security/scam-scan', requireAuth, handleScamTruthFilter);
  app.post('/api/sovereign/truth-filter', requireAuth, handleScamTruthFilter);

  const handleKillSwitch = async (req: AuthedRequest, res: Response) => {
    const pin = String(req.body?.pin || '').trim();
    const freeze = Boolean(req.body?.freeze);
    const pinCheck = verifyPinTimingSafe(req.authUser?.id || req.ip || 'anon', pin);
    if (!pinCheck.ok) {
      res.status(403).json({ error: pinCheck.error });
      return;
    }
    const frozen = await walStore.setKillSwitchFrozen(freeze);
    broadcastStateSync();
    res.json({ killSwitchFrozen: frozen });
  };
  app.post('/api/security/kill-switch', requireAuth, handleKillSwitch);
  app.post('/api/sovereign/kill-switch', requireAuth, handleKillSwitch);

  app.post('/api/stream/toggle', requireAuth, async (req, res) => {
    const enabled = Boolean(req.body?.enabled);
    const liveStreamEnabled = await walStore.setLiveStreamEnabled(enabled);
    broadcastStateSync();
    res.json({ liveStreamEnabled });
  });

  app.post('/api/webhooks/verify', requireAuth, (req, res) => {
    const payloadJson = String(req.body?.payloadJson || '');
    const signatureHeader = String(req.body?.signatureHeader || '');
    res.json({ valid: verifyWebhookSignature(payloadJson, signatureHeader) });
  });

  app.post('/api/compliance/redact/:id', requireAuth, async (req, res) => {
    const tx = await walStore.redactPaymentPii(req.params.id);
    if (!tx) {
      res.status(404).json({ error: 'Transaction not found.' });
      return;
    }
    broadcastStateSync();
    res.json({ transaction: tx });
  });

  app.get('/api/compliance/export', requireAuth, (_req, res) => {
    res.setHeader('Content-Disposition', 'attachment; filename="bolmizan-veritas-gdpr-export.json"');
    res.json(walStore.getExportPackage());
  });

  app.get('/api/exports/iso20022', requireAuth, (req: AuthedRequest, res) => {
    const sync = walStore.getSyncSlice(wss.clients.size);
    const xml = buildIso20022Pain001Xml(
      sync.transactions,
      req.authUser?.businessName || 'BolMizan Merchant'
    );
    res.setHeader('Content-Type', 'application/xml; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="bolmizan-iso20022-pain001.xml"');
    res.send(xml);
  });

  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    const message = err instanceof Error ? err.message : 'Unexpected server error';
    res.status(500).json({ error: message });
  });

  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`BolMizan VERITAS OS running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start BolMizan VERITAS OS:', err);
  process.exit(1);
});
